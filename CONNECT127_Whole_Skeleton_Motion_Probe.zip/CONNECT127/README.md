# CONNECT-127 — Whole-skeleton rigid-bone motion probe

Extends CONNECT-126 with a non-destructive, reversible SVG transform applied to one selected source component at a time.

- All 211 source components preserved; 201 have field links and 10 remain dispositioned fragments.
- Select a bone using component search or the projections.
- Slider rotates the selected source-derived SVG projection about its projected bounding-box center in each view. This is a demonstration pivot, **not** a verified joint center or a 3D physical transform.
- Source OBJ, original triangle connectivity, and stored experimental material fields are untouched. Field linkage remains via source component ID, but the internal samples themselves do **not** move in this visualization.
- Future mechanics require source-space 3D rigid transforms, anatomical joint centers and parent-child frames, plus material sample transforms.
