@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (python "%~dp0apply_update.py") else (py -3 "%~dp0apply_update.py")
if errorlevel 1 (echo Update did not complete.) else (echo Verified project ready.)
pause
