Gentle 125 | Working deep finger flexor

Open ACE_WORKBENCH.cmd belly or R70/ui/Flexor_belly.html. The editable figure is R70/rig/Aurelia_R70_Deep_Flexor.blend.

The update requires the exact R69 full ZIP or its extracted project. On Windows, extract the update, place CLCE_ACE_M05C_R69_INDEX_FOREARM_HANDOFF.zip beside the extracted updater folder and run APPLY_WINDOWS.cmd from inside that folder. The updater creates and verifies a separate R70 folder. A complete R70 ZIP is also available for standalone restoration.
