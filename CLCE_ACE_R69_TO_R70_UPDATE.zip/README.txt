ACE incremental update

Keep your complete CLCE_ACE_M05C_R69 project. This ZIP contains only the changes needed for CLCE_ACE_M05C_R70.
The updater requires Python 3.8 or later and writes a NEW complete folder.
Allow enough free space for the complete restored tree.

Windows: Extract this small update to its own folder. Put the original CLCE_ACE_M05C_R69_INDEX_FOREARM_HANDOFF.zip
beside that folder. Double-click APPLY_WINDOWS.cmd inside the update.
macOS/Linux: Place the two ZIPs side by side. In their folder run:
  python3 "CLCE_ACE_R69_TO_R70_UPDATE.zip"

Alternatively use explicit paths:
  python3 apply_update.py --base "/path/to/original.zip" --output "/path/to/new/project"
On Windows the equivalent command starts with py -3.
An exact original extracted project folder also works with --base. If it contains
local edits, use the original ZIP as the baseline. Custom work stays where it is.
Successful restoration prints PASS after checking every project file against SHA-256.
A destination that already exists is preserved. To repeat a check, select a fresh output.
