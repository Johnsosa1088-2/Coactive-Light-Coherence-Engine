from apply_update import cli
import sys
sys.exit(cli())
