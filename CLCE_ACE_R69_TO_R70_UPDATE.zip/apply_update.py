"""Restore a complete ACE checkpoint using Python 3.8+ and the original full ZIP or folder."""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sys
import tempfile
import zipfile

CHUNK = 1024 * 1024
SHA = re.compile(r'[0-9a-f]{64}')
FORMAT = 'ACE_CHECKPOINT_UPDATE_1'

def check(ok, message):
    if not ok:
        raise ValueError(message)

def name(path):
    check(isinstance(path,str) and path, 'Invalid empty relative path')
    for part in path.split('/'):
        check(part not in ('', '.', '..') and part[-1] not in ' .' and
              not re.search(r'[<>:"\\|?*\x00-\x1f]',part) and
              not re.match(r'(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)',part,re.I),
              'Invalid project path: '+repr(path))
    return path

def single(path):
    check('/' not in name(path),'Expected a single path component')
    return path

def paths_ok(names):
    known={}
    for path in names:
        parts=name(path).split('/')
        for i in range(1,len(parts)+1):
            comp='/'.join(parts[:i]); entry=(comp,i==len(parts))
            check(known.setdefault(comp.casefold(),entry)==entry,'Conflicting project path: '+path)

def stream(source, out=None, digest=None, limit=None):
    left=limit
    while left is None or left:
        data=source.read(CHUNK if left is None else min(CHUNK,left))
        if not data:
            check(left is None,'Unexpected end of file')
            break
        if digest is not None: digest.update(data)
        if out is not None: out.write(data)
        if left is not None: left-=len(data)

def hashfile(path):
    h=hashlib.sha256()
    with path.open('rb') as f: stream(f,digest=h)
    return h.hexdigest()

def plain(path):
    st=path.lstat()
    check(not stat.S_ISLNK(st.st_mode) and not (getattr(st,'st_file_attributes',0)&1024),'Linked project path: '+str(path))

def inventory(root):
    plain(root); result=set()
    def fail(e): raise e
    for folder,dirs,files in os.walk(root,onerror=fail):
        for entry in dirs+files: plain(Path(folder)/entry)
        for entry in files:
            p=Path(folder)/entry
            check(p.is_file(),'Unexpected special file: '+str(p))
            result.add(p.relative_to(root).as_posix())
    paths_ok(result)
    return result

class Source:
    def __init__(self,path,root='',inspect=True):
        self.path=path; self.zip=None; self.names=set()
        self.prefix=root+'/' if root else ''
        if path.is_dir():
            if inspect: self.names=inventory(path)
            return
        self.zip=zipfile.ZipFile(path)
        try:
            for info in self.zip.infolist():
                full=info.filename.rstrip('/'); name(full)
                if info.is_dir(): continue
                check(full.startswith(self.prefix),'Unexpected archive root: '+full)
                check(stat.S_IFMT(info.external_attr>>16) in (0,stat.S_IFREG),'Special ZIP member: '+full)
                rel=full[len(self.prefix):]
                check(rel not in self.names,'Duplicate ZIP member: '+rel)
                self.names.add(rel)
            paths_ok(self.names)
        except BaseException:
            self.zip.close(); raise
    def open(self,rel):
        name(rel)
        if self.zip: return self.zip.open(self.prefix+rel)
        p=self.path
        for part in rel.split('/'):
            p=p/part; plain(p)
        check(p.is_file(),'Missing regular file: '+str(p))
        return p.open('rb')
    def close(self):
        if self.zip: self.zip.close()

def manifest(source,rel,pin,root):
    with source.open(rel) as f:
        raw=f.read(64*1024*1024+1)
    check(len(raw)<=64*1024*1024 and hashlib.sha256(raw).hexdigest()==pin,'Wrong or damaged manifest: '+rel)
    doc=json.loads(raw); self_name=single(doc['selfExcluded']); hashes=doc['sha256']
    check(self_name==rel.rsplit('/',1)[-1] and root==doc['archiveRoot'],'Wrong checkpoint identity')
    check(self_name not in hashes and len(hashes)==doc['fileCount'],'Invalid manifest file count')
    check(all(isinstance(v,str) and SHA.fullmatch(v) for v in hashes.values()),'Invalid file hash')
    hashes[self_name]=pin; paths_ok(hashes)
    return hashes

def reuse(before,after):
    choices={}
    for path in sorted(before): choices.setdefault(before[path],path)
    return {p:(p if before.get(p)==h else choices[h]) for p,h in after.items() if h in choices}

def publish(src,dst):
    # No-replace rename also protects an empty destination created concurrently.
    if os.name=='nt':
        os.rename(src,dst); return
    lib=ctypes.CDLL(None,use_errno=True)
    if sys.platform.startswith('linux') and hasattr(lib,'renameat2'):
        rc=lib.renameat2(-100,os.fsencode(src),-100,os.fsencode(dst),1)
    elif sys.platform=='darwin' and hasattr(lib,'renamex_np'):
        rc=lib.renamex_np(os.fsencode(src),os.fsencode(dst),4)
    else:
        raise OSError('Atomic publishing requires supported Linux, macOS or Windows.')
    if rc:
        errno=ctypes.get_errno()
        raise OSError(errno,os.strerror(errno),str(dst))

def read_index(update):
    with update.open('update.json') as f: raw=f.read(8*1024*1024+1)
    check(len(raw)<=8*1024*1024,'Update descriptor too large')
    doc=json.loads(raw)
    check(doc['format']==FORMAT,'Unsupported update format')
    for key in ('base','target'):
        item=doc[key]; single(item['root']); single(item['manifest'])
        check(SHA.fullmatch(item['manifestSHA256']),'Invalid manifest pin')
    check(doc['base']['root']!=doc['target']['root'],'Expected different checkpoint names')
    if 'archive' in doc['base']:
        single(doc['base']['archive']); check(SHA.fullmatch(doc['base']['archiveSHA256']),'Invalid original ZIP pin')
    return doc

def span(baseline,update,path,spec,before,out,h):
    source=name(spec['from']); start,length=spec['offset'],spec['length']
    check(source in before and type(start) is int and type(length) is int and start>=0 and length>0,'Invalid verified range')
    with update.open('spans/'+path+'.prefix') as f: stream(f,out,h)
    with baseline.open(source) as f:
        f.seek(start); stream(f,out,h,length)
    with update.open('spans/'+path+'.suffix') as f: stream(f,out,h)

def restore(update,doc,basepath,output):
    base,target=doc['base'],doc['target']
    check(not os.path.lexists(output),'Output already exists and will be preserved: '+str(output))
    check(output.parent.is_dir(),'The output parent directory must already exist')
    if basepath.is_dir():
        check(basepath.resolve()!=output.resolve() and basepath.resolve() not in output.resolve().parents,'Choose a destination outside the baseline')
    baseline=Source(basepath,base['root'])
    try:
        before=manifest(baseline,base['manifest'],base['manifestSHA256'],base['root'])
        check(set(before)==baseline.names,'Unexpected or missing baseline files')
        if baseline.zip and 'archiveSHA256' in base:
            check(hashfile(basepath)==base['archiveSHA256'],'Original baseline ZIP checksum mismatch')
        after=manifest(update,'payload/'+target['manifest'],target['manifestSHA256'],target['root'])
        reused=reuse(before,after); spans=doc.get('spans',{})
        check(isinstance(spans,dict) and set(spans)<=set(after)-set(reused),'Unexpected span recipe')
        same={n for n,s in reused.items() if n==s}
        with tempfile.TemporaryDirectory(prefix='.ace-restore-',dir=output.parent) as temp:
            stage=Path(temp)/'verified'; stage.mkdir()
            def destination(path):
                p=stage/path; p.parent.mkdir(parents=True,exist_ok=True)
                return p.open('xb')
            for path,expected in before.items():
                h=hashlib.sha256()
                with baseline.open(path) as f:
                    if path in same:
                        with destination(path) as out: stream(f,out,h)
                    else: stream(f,digest=h)
                check(h.hexdigest()==expected,'Damaged baseline file: '+path)
            for path in sorted(set(after)-same):
                h=hashlib.sha256()
                with destination(path) as out:
                    if path in spans: span(baseline,update,path,spans[path],before,out,h)
                    else:
                        src,rel=(baseline,reused[path]) if path in reused else (update,'payload/'+path)
                        with src.open(rel) as f: stream(f,out,h)
                check(h.hexdigest()==after[path],'Restored file checksum mismatch: '+path)
            check(inventory(stage)==set(after),'Restored inventory mismatch')
            for path,expected in after.items():
                check(hashfile(stage/path)==expected,'Restored on-disk checksum mismatch: '+path)
            publish(stage,output)
        return dict(status='PASS',baselineFilesVerified=len(before),targetFilesVerified=len(after),
                    wholeFilesReused=len(reused),spanRebuiltFiles=len(spans),targetManifestSHA256=target['manifestSHA256'],output=str(output))
    finally: baseline.close()

def find_base(doc,update):
    base=doc['base']; candidates=([base['archive']] if 'archive' in base else [])+[base['root']]
    parents=([update] if update.is_dir() else [])+[update.parent,Path.cwd()]
    for root in parents:
        for candidate in candidates:
            p=root/candidate
            if p.is_file() or p.is_dir(): return p
    raise ValueError('Place the original '+candidates[0]+' beside the update, or pass --base PATH.')

def main():
    own=Path(sys.argv[0]).resolve()
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--update',type=Path,default=own if own.suffix.lower()=='.zip' else Path(__file__).resolve().parent)
    p.add_argument('--base',type=Path,help='original ZIP or exact extracted project folder')
    p.add_argument('--output',type=Path,help='new full project folder, must not exist')
    args=p.parse_args(); u=args.update.resolve(); update=Source(u,inspect=False)
    try:
        doc=read_index(update); base=args.base or find_base(doc,u)
        output=args.output or u.parent/doc['target']['root']
        print('Verifying baseline and rebuilding '+doc['target']['root'],flush=True)
        print(json.dumps(restore(update,doc,base.resolve(),output.absolute()),indent=2))
    finally: update.close()

def cli():
    try: main()
    except (KeyError,TypeError,OSError,ValueError,RuntimeError,zipfile.BadZipFile) as exc:
        print('Update stopped:',exc,file=sys.stderr)
        return 1
    return 0

if __name__=='__main__':
    sys.exit(cli())
