'use strict';
globalThis.BellyPaint=(()=>{
  const {sub,dot,cross,unit}=HandStudy;
  const colors={muscle:'#e4a1a8',tendon:'#b7a9d9',surface:'#d9786a',lead:'#ffc477',patch:'#97e4ce',rim:'#b9c6b3',middle:'#70b9be',guide:'#79ced6',origin:'#ddc98d'};
  function plate(canvas,m,s,kind,opts={}){
    const {focus='muscle',view='oblique',bones=true,skin=true,overlay=false,markers=true,lead=true,site=true,origin=true}=opts;
    const cam=m.camera(view,focus,canvas.width,canvas.height,s.event),scene=Object.create(m.handoff.old.hand);
    scene.camera=()=>cam;if(!skin)scene.drawFaces=[];
    const hand=s.prior.prior.hand,stage={...hand,working:skin?hand.working:[],bones:bones?hand.bones:[]};
    HandPaint.plate(canvas,scene,stage,{view:'front',mode:bones?'bones':'fit',region:-1});
    const ctx=canvas.getContext('2d'),k=Math.max(.65,canvas.width/525);
    function line(vertices,ink,width=2.5,dashed=false){
      if(vertices.length<2)return;
      const pts=vertices.map(cam.point);ctx.save();ctx.beginPath();ctx.moveTo(pts[0][0],pts[0][1]);
      for(const p of pts.slice(1))ctx.lineTo(p[0],p[1]);
      ctx.lineJoin='round';ctx.lineCap='round';if(dashed)ctx.setLineDash([5*k,4*k]);
      ctx.strokeStyle='#1d2b2b';ctx.lineWidth=(width+2)*k;ctx.stroke();
      ctx.strokeStyle=ink;ctx.lineWidth=width*k;ctx.stroke();ctx.restore();
    }
    function dotAt(q,ink,r){
      const p=cam.point(q);ctx.beginPath();ctx.arc(p[0],p[1],r*k,0,Math.PI*2);
      ctx.fillStyle=ink;ctx.fill();ctx.lineWidth=1;ctx.strokeStyle='#203232';ctx.stroke();
    }
    function drawSource(){
      if(site){
        line(s.guide,colors.guide,1.1);
        for(const p of s.site)dotAt(p,colors.guide,1.35);
        line(s.face.concat([s.face[0]]),colors.guide,1.8);dotAt(s.witness,colors.guide,3.5);
      }
      line(s.muscle,colors.muscle,3.2);line(s.tendon,colors.tendon,2.1,true);
    }
    if(kind==='source'){drawSource();}
    else{
      // Posed envelope is shown as an inspection overlay on the muted anatomical context.
      const pts=s.vertices.map(cam.point),depth=m.work.faces.map((f,i)=>[i,(pts[f[0]][2]+pts[f[1]][2]+pts[f[2]][2])/3]);
      depth.sort((a,b)=>a[1]-b[1]);
      const light=unit(cam.axes[0].map((x,i)=>-.55*x+.56*cam.axes[1][i]+.7*cam.axes[2][i]));
      for(const [i] of depth){
        const [i0,i1,i2]=m.work.faces[i],p=pts[i0],q=pts[i1],r=pts[i2];
        const nd=cross(sub(s.vertices[i1],s.vertices[i0]),sub(s.vertices[i2],s.vertices[i0])),size=Math.hypot(...nd);
        const tone=.71+.29*dot(nd,light)*(dot(nd,cam.axes[2])<0?-1:1)/(size||1);
        const ink='rgb('+[222,121,103].map(v=>Math.max(0,Math.round(tone*v))).join(',')+')';
        ctx.beginPath();ctx.moveTo(p[0],p[1]);ctx.lineTo(q[0],q[1]);ctx.lineTo(r[0],r[1]);ctx.closePath();ctx.fillStyle=ink;ctx.fill();
        ctx.strokeStyle=ink;ctx.lineWidth=.6;ctx.stroke();
      }
      if(origin){line(s.originGuide,colors.origin,2.0,true);dotAt(s.originGuide[0],colors.origin,2.8);}
      if(overlay)drawSource();
      if(lead)line(s.prior.points,colors.lead,2.8);
      if(markers){
        for(const i of [1,2,3,4])line([s.nodes[0],s.nodes[i]],colors.patch,1.5);
        for(const p of s.nodes)dotAt(p,colors.patch,2.8);
        dotAt(s.prior.workingPatch.anchor,colors.lead,2.1);
      }
    }
    return cam;
  }
  function section(canvas,q,opts={}){
    const ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height;
    ctx.fillStyle='#102428';ctx.fillRect(0,0,w,h);
    const points=q.skin.flat().concat(q.bones.flat(),q.surface.flat(),q.originGuide,q.guide,q.muscle,q.tendon,q.lead);
    if(!points.length)return {span:0};
    const xs=points.map(p=>p[0]),ys=points.map(p=>p[1]),a=Math.min(...xs),b=Math.max(...xs),c=Math.min(...ys),d=Math.max(...ys);
    const scale=Math.min((w-42)/Math.max(3.5,b-a),(h-52)/Math.max(2.6,d-c));
    const x=p=>w/2+(p[0]-(a+b)*.5)*scale,y=p=>h*.46-(p[1]-(c+d)*.5)*scale;
    ctx.strokeStyle='#223c3d';ctx.lineWidth=.6;ctx.beginPath();
    for(let i=0;i<w;i+=scale){ctx.moveTo(i,0);ctx.lineTo(i,h);}for(let j=0;j<h;j+=scale){ctx.moveTo(0,j);ctx.lineTo(w,j);}ctx.stroke();
    for(const [arr,col,show,width] of [[q.skin,'#95b7aa',opts.skin!==false,1.8],[q.bones,colors.rim,opts.bones!==false,1.5],[q.surface,colors.surface,true,3.4]]){
      if(!show)continue;
      ctx.strokeStyle=col;ctx.lineWidth=width;ctx.lineCap='round';ctx.beginPath();
      for(const [u,v] of arr){ctx.moveTo(x(u),y(u));ctx.lineTo(x(v),y(v));}ctx.stroke();
    }
    for(const [pts,col] of [[opts.origin===false?[]:q.originGuide,colors.origin],[opts.site===false?[]:q.guide,colors.guide],[q.muscle,colors.muscle],[q.tendon,colors.tendon],[opts.lead===false?[]:q.lead,colors.lead]]){
      for(const p of pts){ctx.beginPath();ctx.arc(x(p),y(p),3,0,Math.PI*2);ctx.fillStyle=col;ctx.fill();ctx.strokeStyle='#132c2c';ctx.lineWidth=1;ctx.stroke();}
    }
    ctx.fillStyle='#dde6da';ctx.font='11px sans-serif';ctx.fillText('10 mm',12,h-11);ctx.fillRect(12,h-7,scale,1.4);
    const cuts=q.surface.flat().map(p=>p[0]);return {span:cuts.length?(Math.max(...cuts)-Math.min(...cuts))*10:0};
  }
  return {plate,section,colors};
})();
