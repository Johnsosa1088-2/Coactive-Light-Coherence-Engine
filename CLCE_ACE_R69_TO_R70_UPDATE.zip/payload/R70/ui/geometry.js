'use strict';
globalThis.Belly=(()=>{
  const {dot,cross,sub,add,unit,turn,apply,midpoint,limits}=HandStudy;
  function volume(vertices,faces){
    const pivot=vertices[0];let sum=0;
    for(const [i,j,k] of faces)sum+=dot(sub(vertices[i],pivot),cross(sub(vertices[j],pivot),sub(vertices[k],pivot)));
    return Math.abs(sum/6);
  }
  function intersect(a,b){
    if((a[2]>0)===(b[2]>0))return null;
    const t=a[2]/(a[2]-b[2]);return [a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t];
  }
  function contours(points,faces){
    const segments=[];
    for(const [i,j,k] of faces){
      const a=points[i],b=points[j],c=points[k];
      if((a[2]>0)===(b[2]>0)&&(a[2]>0)===(c[2]>0))continue;
      const hit=[intersect(a,b),intersect(b,c),intersect(c,a)].filter(Boolean);
      if(hit.length===2&&Math.hypot(hit[0][0]-hit[1][0],hit[0][1]-hit[1][1])>1e-10)segments.push(hit);
    }return segments;
  }
  function trackDots(points){return points.slice(1).map((b,i)=>intersect(points[i],b)).filter(Boolean);}
  function model(data){
    const handoff=Handoff.model(data),packet=data.belly,work=packet.working,source=packet.source;
    const neutral=handoff.state(0,0,0),tip=unit(data.hand.hand.directionCM),pivot=data.hand.hand.pivotCM;
    const midpointOf=id=>midpoint(neutral.prior.hand.bones.find(p=>p.component===id).vertices);
    const dy=sub(midpointOf(57),midpointOf(74)),u=unit(add(dy,tip,-dot(tip,dy))),v=unit(cross(tip,u));
    const originGuide=packet.originGuide.pointsCM,axis=data.response.axisCM;
    const patch=neutral.workingPatch.nodes;
    const levels=work.verticesCM.map(q=>10*dot(sub(q,pivot),tip)),stationMin=Math.min(...levels),stationMax=Math.max(...levels);
    const midStation=Math.round((stationMin+stationMax)*.5),patchStation=Math.round(10*dot(sub(neutral.workingPatch.anchor,pivot),tip));
    function state(knuckle=0,wrist=0,event=0,thickness=1,node=4,offset=0){
      const prior=handoff.state(knuckle,wrist,event,node,offset),T=data.hand.events[event].F;
      const local=work.verticesCM.map((q,i)=>add(add(q,work.thicknessDeltaCM[i],thickness-1),axis,offset*.1*work.editWeights[i][node]));
      const world=points=>points.map(p=>apply(p,T)),vertices=world(local),nodes=work.patchVertexIDs0.map(i=>vertices[i]);
      const gapMM=Math.max(...nodes.map((q,i)=>10*Math.hypot(...sub(q,prior.workingPatch.nodes[i]))));
      return {knuckle,wrist,event,thickness,node,offset,prior,vertices,local,nodes,gapMM,volumeCM3:volume(local,work.faces),
              muscle:world(source.muscleCM),tendon:world(source.tendonCM), site:world(data.named.siteDotsCM), guide:world(data.named.centerlineCM), witness:apply(data.named.ulnaWitnessCM,T), face:world(data.named.ulnaFaceCM),originGuide:world(originGuide),centerline:world(work.centerlineCM)};
    }
    function camera(view,focus,w,h,event=0){
      if(focus==='arm')return handoff.old.camera(view,'arm',w,h,event);
      const ref=handoff.old.camera(view,'whole',w,h,event),[R,U,D]=ref.axes;
      let points;
      if(focus==='patch'){
        const a=neutral.workingPatch.anchor;
        points=work.verticesCM.filter(p=>Math.hypot(...sub(p,a))<1.5).concat(neutral.points.slice(0,6),patch);
      }else if(focus==='ulna'){
        points=originGuide.concat(data.named.ulnaFaceCM,data.named.centerlineCM.slice(0,6),work.centerlineCM.slice(0,5));
      }else if(focus==='whole'){
        points=work.verticesCM.concat(data.named.centerlineCM,source.muscleCM,source.tendonCM,neutral.points,neutral.prior.adjacent);
      }else if(focus==='muscle'){
        points=work.verticesCM.concat(data.named.centerlineCM,data.named.ulnaFaceCM,source.muscleCM,source.tendonCM);
      }else throw Error('Unknown focus');
      const T=data.hand.events[event].F,frame=event?points.map(p=>apply(p,T)):points;
      const bx=limits(frame,R),by=limits(frame,U),pad=focus==='patch'?2.4:4;
      const scale=Math.min(w*.79/Math.max(pad,bx[1]-bx[0]),h*.84/Math.max(pad,by[1]-by[0]));
      const cx=(bx[0]+bx[1])/2,cy=(by[0]+by[1])/2;
      return {axes:[R,U,D],scale,point:p=>[(dot(p,R)-cx)*scale+w/2,h*.50-(dot(p,U)-cy)*scale,dot(p,D)]};
    }
    function section(s,station){
      const F=data.hand.events[s.event].F,n=unit(turn(tip,F)),r=unit(turn(u,F)),up=unit(turn(v,F));
      const origin=add(apply(pivot,F),n,station/10);
      function project(points){return points.map(q=>{const p=sub(q,origin);return [dot(p,r),dot(p,up),dot(p,n)];});}
      const hand=s.prior.prior.hand;
      return {skin:contours(project(hand.working),handoff.old.hand.drawFaces),
              bones:hand.bones.flatMap(b=>contours(project(b.vertices),b.faces)),
              surface:contours(project(s.vertices),work.faces),originGuide:trackDots(project(s.originGuide)),guide:trackDots(project(s.guide)),muscle:trackDots(project(s.muscle)),tendon:trackDots(project(s.tendon)),lead:trackDots(project(s.prior.points))};
    }
    return {data,work,source,handoff,state,camera,section,midStation,patchStation,stationMin:Math.floor(stationMin)-2,stationMax:Math.max(2,Math.ceil(stationMax)+2)};
  }
  return {model,volume,contours};
})();
