/** Create the plate and animation by rendering the local HTML's embedded meshes. */
import fs from 'node:fs';
import {createRequire} from 'node:module';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
const {createCanvas}=createRequire(import.meta.url)('@napi-rs/canvas');
const [file,still,gif]=process.argv.slice(2),html=fs.readFileSync(file,'utf8');
const script=id=>html.match(new RegExp('<script[^>]*id="'+id+'"[^>]*>([\\s\\S]*?)</script>'))[1];
for(const k of ['geometry','renderer'])new Function(script(k))();
const m=Belly.model(JSON.parse(script('data'))),s=m.state(),col=BellyPaint.colors;
const dark='#0a1d20',panel='#132b2e',line='#365455',paper='#f3eee2',muted='#afc5bc',mint='#a1d9c6';
function label(c,str,x,y,size,color=paper,font='sans-serif'){c.font=size+'px '+font;c.fillStyle=color;c.fillText(str,x,y);}
function canvas(w,h,color=dark){const v=createCanvas(w,h),c=v.getContext('2d');c.fillStyle=color;c.fillRect(0,0,w,h);return [v,c];}
function plate(c,x,y,w,h,s,kind,opts={}){const [can]=canvas(w,h);BellyPaint.plate(can,m,s,kind,opts);c.drawImage(can,x,y);c.strokeStyle=line;c.lineWidth=1;c.strokeRect(x+.5,y+.5,w-1,h-1);}
function slice(c,x,y,w,h,s){const [can]=canvas(w,h);const q=m.section(s,m.midStation),r=BellyPaint.section(can,q);c.drawImage(can,x,y);c.strokeStyle=line;c.strokeRect(x+.5,y+.5,w-1,h-1);return r.span;}
function swatch(c,x,y,color,name){c.fillStyle=color;c.fillRect(x,y-5,22,4);label(c,name,x+30,y,15,paper);}
const [png,c]=canvas(1230,772);
label(c,'CLCE / LIGHTBENCH',26,32,15,mint);label(c,'GENTLE 125     ·     R70',1002,32,15,muted);
label(c,'The deep flexor of the forearm',24,93,52,paper,'Georgia');label(c,'Flexor digitorum profundus  /  positive-X arm and index tendon',26,129,20,muted);
for(const [x,a,b] of [[26,'CONNECT387 + GOLD','Archived guides'],[425,'FITTED GEOMETRY','Muscle and lateral outlet'],[824,'TRANSVERSE PLANE','Inside the forearm']]){
 label(c,a,x,171,13,mint);label(c,b,x,199,24,paper,'Georgia');}
plate(c,26,215,382,344,s,'source');plate(c,425,215,382,344,s,'working');
c.fillStyle=panel;c.fillRect(824,215,380,344);
const span=slice(c,824,215,380,224,s);
label(c,Math.abs(m.midStation)+' mm toward the elbow',841,471,21,paper,'Georgia');
label(c,'Coral marks the mesh cut through the muscle.',841,502,14,muted);
label(c,'Lighter contours trace the fitted skin and bones.',841,527,14,muted);
c.strokeStyle=line;c.strokeRect(824.5,215.5,379,343);
swatch(c,27,594,col.guide,'Ulnar guide');swatch(c,189,594,col.muscle,'Gold muscle');swatch(c,358,594,col.tendon,'Gold tendon');swatch(c,522,594,col.origin,'Fitted origin');swatch(c,697,594,col.surface,'Envelope');swatch(c,836,594,col.lead,'Index route');swatch(c,1012,594,col.patch,'Shared nodes');
c.fillStyle=panel;c.fillRect(26,622,1178,92);c.strokeStyle=line;c.strokeRect(26.5,622.5,1177,91);
for(const [x,t,n,tint] of [[46,'Neutral fitted volume',s.volumeCM3.toFixed(3)+' cm³',col.surface],[435,'Transverse envelope span',span.toFixed(2)+' mm',mint],[834,'Shared index attachment',s.nodes.length+' mesh nodes',col.lead]]){
 label(c,t,x,649,15,muted);label(c,n,x,693,34,tint,'Georgia');}
label(c,'Source guides identify the region. Muscle dimensions and the lateral outlet are fitted engineering geometry.',26,748,16,muted);
fs.writeFileSync(still,png.toBuffer('image/png'));
if(gif){
 const W=900,H=508,[v,g]=canvas(W,H);
 const proc=spawn('ffmpeg',['-v','error','-y','-f','rawvideo','-pixel_format','rgba','-video_size',W+'x'+H,'-framerate','3','-i','pipe:0','-filter_threads','1','-filter_complex_threads','1','-filter_complex','[0:v]split[x][y];[x]palettegen[p];[y][p]paletteuse=dither=bayer:bayer_scale=4','-loop','0',gif],{stdio:['pipe','inherit','inherit']});
 const phases=[[1,0,0,0],[.8,0,0,0],[1,0,0,0],[1.2,0,0,0],[1,0,0,0],[1,4,0,0],[1,8,0,0],[1,12,0,0],[1,16,0,0],[1,0,.5,0],[1,0,0,0],[1,0,-.5,0],[1,0,0,0]];
 for(const [scale,event,offset,angle] of phases){
   const pose=m.state(angle,0,event,scale,4,offset);
   const focus=offset?'patch':'muscle';
   g.fillStyle=dark;g.fillRect(0,0,W,H);
   label(g,'Deep forearm flexor',16,41,33,paper,'Georgia');label(g,'LIGHTBENCH / R70',732,30,15,mint);
   label(g,event?'Recorded arm sample '+event:offset?'Index patch · node 4 offset '+(offset>0?'+':'')+offset+' mm':'Working thickness · '+scale.toFixed(2)+'×',16,75,19,muted);
   plate(g,16,92,414,302,pose,'working',{focus});
   if(offset){const [p]=canvas(425,245);HandoffPaint.patchDiagram(p,m.handoff.packet,pose.prior);g.drawImage(p,449,112);}
   else slice(g,449,92,435,302,pose);
   label(g,'Fitted surface and index outlet',17,424,18,col.surface);
   label(g,offset?'Five shared nodes · enlarged diagram':'True mesh section at '+Math.abs(m.midStation)+' mm from wrist',450,424,17,mint);
   label(g,'Shape volume  '+pose.volumeCM3.toFixed(3)+' cm³',16,475,19,paper);label(g,'Largest patch gap  '+pose.gapMM.toFixed(3)+' mm',450,475,18,paper);
   const rgba=Buffer.from(g.getImageData(0,0,W,H).data);
   for(let j=0;j<2;j++)if(!proc.stdin.write(rgba))await once(proc.stdin,'drain');
 }
 proc.stdin.end();const [status]=await once(proc,'exit');if(status)throw Error('ffmpeg '+status);
}
