'use strict';
(()=>{
  const el=id=>document.getElementById(id),m=Belly.model(JSON.parse(el('data').textContent));
  const signed=x=>(x>0?'+':'')+Number(x.toFixed(3)),mm=(x,d=2)=>x.toFixed(d)+' mm';
  function options(key,rows){const box=el(key);for(const [val,label] of rows){const o=document.createElement('option');o.value=String(val);o.textContent=label;box.appendChild(o);}}
  function set(key,val){el(key).value=String(val);}
  options('thick',m.work.thicknessStops.map(x=>[x,Number(x).toFixed(2)+'×']));
  options('node',m.data.response.nodeIDs.map(x=>[x,'Node '+x]));
  options('edit',m.data.response.offsetsMM.map(x=>[x,signed(x)+' mm']));
  options('arm',m.data.hand.events.map(e=>[e.index,'Sample '+e.index+' · elbow '+Number(e.elbowDeg.toFixed(1))+'°']));
  options('knuckle',m.handoff.old.angles('index').map(v=>[v,signed(v)+'°']));
  options('wrist',m.handoff.old.wrists.map(v=>[v,signed(v)+'°']));
  el('station').min=String(m.stationMin);el('station').max=String(m.stationMax);
  let current;
  const opt=()=>({view:el('camera').value,focus:el('focus').value,...Object.fromEntries(['bones','skin','markers','overlay','lead','site','origin'].map(k=>[k,el(k).checked]))});
  const val=k=>Number(el(k).value);
  function section(){
    const station=val('station'),q=m.section(current,station),measured=BellyPaint.section(el('slice'),q,opt());
    el('stationRead').textContent=signed(station)+' mm';
    el('sectionRead').textContent=q.surface.length?'The full envelope spans '+mm(measured.span)+' along the transverse display axis, including any gap between its contours.':'This plane is beyond the current muscle surface.';
  }
  function draw(){
    current=m.state(val('knuckle'),val('wrist'),val('arm'),val('thick'),val('node'),val('edit'));
    const s=current,o=opt();
    BellyPaint.plate(el('left'),m,s,'source',o);BellyPaint.plate(el('right'),m,s,'working',o);
    HandoffPaint.patchDiagram(el('patch'),m.handoff.packet,s.prior);
    el('frame').textContent='Index '+signed(s.knuckle)+'° · wrist '+signed(s.wrist)+'° · arm '+s.event;
    el('volume').textContent=s.volumeCM3.toFixed(3)+' cm³';el('length').textContent=mm(s.prior.length);el('gap').textContent=mm(s.gapMM,3);
    const weight=m.data.response.weights[s.node];
    el('response').textContent='Node '+s.node+' carries '+Math.round(100*weight)+'% of the index patch weight. At '+signed(s.offset)+' mm, the shared route origin moves '+mm(Math.abs(s.offset*weight),3)+'. The five mesh vertices follow their corresponding patch nodes.';
    section();
  }
  function preset(focus){
    for(const [k,v] of [['focus',focus],['camera','oblique'],['arm',focus==='arm'?8:0],['wrist',0],['knuckle',focus==='whole'?15:0],['thick',1],['node',4],['edit',0],['station',focus==='patch'?m.patchStation:m.midStation]])set(k,v);
    for(const k of ['skin','bones','markers','lead','site','origin'])el(k).checked=true;
    el('overlay').checked=false;draw();
  }
  for(const [key,focus] of [['overview','muscle'],['patchPreset','patch'],['ulnaPreset','ulna'],['handPreset','whole'],['armPreset','arm']])el(key).addEventListener('click',()=>preset(focus));
  for(const k of ['thick','node','edit','arm','knuckle','wrist','focus','camera','bones','skin','markers','overlay','lead','site','origin'])el(k).addEventListener('change',draw);
  el('station').addEventListener('input',section);
  el('neutral').addEventListener('click',()=>preset('muscle'));
  el('evidence').textContent='CONNECT387 supplies a named ulnar face and a 51-point guide covering the deep flexor in three dimensions. The Gold forearm workbench supplies separate muscle and index tendon tracks. Both panels use the same pose and camera. A fitted guide connects the witness on the ulna to the proximal muscle tip. The lateral outlet meets the five-point index patch.';
  const tests=m.data.belly.measurements.neutralPolylineAudits;
  el('sourceCrossings').textContent='In the neutral forearm, '+mm(tests.connect387Diagram.ulna.insideLengthMM)+' of the archived CONNECT387 centreline runs inside the ulna, and '+mm(tests.goldIndexTendon.radius.insideLengthMM)+' of the Gold index tendon runs inside the radius. The source view preserves both observations.';
  const guide=m.data.belly.originGuide;
  el('originNote').textContent='The '+mm(Fingers.lengthMM(guide.pointsCM))+' fitted origin guide starts at ulna vertex '+guide.sourceUlnaVertex0+' on face '+guide.sourceFace0+' (zero-based) and ends on the muscle tip. The line represents a proposed path. Its drawn width has no physical calibration.';
  const q=m.data.clearance;
  el('clearance').textContent=q?'Across the measured configurations, minimum surface clearance is '+mm(q.minSkinGapMM,3)+' to skin and '+mm(q.minBoneGapMM,3)+' to bone.':'Open the geometry receipt for envelope clearance measurements.';
  preset('muscle');
})();
