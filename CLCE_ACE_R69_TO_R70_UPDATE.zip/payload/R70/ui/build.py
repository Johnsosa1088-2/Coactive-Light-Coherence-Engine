"""Build the self-contained FDP envelope viewer using the R69 hand and arm runtime."""
import argparse
import hashlib
import json
import re
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build(root, packet_path, output, audit_path=None):
    here = Path(__file__).resolve().parent
    parent = root/'R69/ui/Forearm_handoff.html'
    html = parent.read_text()
    data = json.loads(re.search(r'<script[^>]*id="data"[^>]*>(.*?)</script>',html,re.S)[1])
    envelope = json.loads(packet_path.read_bytes())
    work = envelope['working']
    assert len(work['verticesCM']) == len(work['editWeights']) == len(work['thicknessDeltaCM'])
    assert len(work['patchVertexIDs0']) == 5
    origin=root/'R70/origins/R70_FDP_SOURCE_REGISTRATION.json'
    data['named'] = json.loads(origin.read_bytes())
    data['belly'] = envelope
    data['sha256'] = dict(parent=digest(parent),envelope=digest(packet_path), namedSite=digest(origin))
    data.pop('audit',None)
    data['clearance'] = None
    if audit_path:
        audit=json.loads(audit_path.read_bytes())
        assert audit['status']=='PASS'
        if audit['muscleSHA256'] != digest(packet_path):
            raise ValueError('Geometry receipt and envelope describe different files')
        data['clearance']=audit['summary']
        data['sha256']['audit']=digest(audit_path)
    fields={'DATA':json.dumps(data,ensure_ascii=False,separators=(',',':'),allow_nan=False).replace('<','\\u003c'),
            'STYLES':re.search(r'<style>(.*?)</style>',html,re.S)[1],
            'INTERFACE':(here/'interface.js').read_text()}
    for name in ('geometry','renderer'):
        inherited=re.search(r'<script[^>]*id="'+name+r'"[^>]*>(.*?)</script>',html,re.S)[1]
        fields[name.upper()]=inherited+'\n'+(here/(name+'.js')).read_text()
    result=(here/'study.html.in').read_text()
    for key,field in fields.items():
        token='@@'+key+'@@'
        assert result.count(token)==1 and '</script' not in field.lower()
        result=result.replace(token,field)
    output.write_text(result)
    print(output.name,output.stat().st_size,digest(output))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('project','packet','output'):p.add_argument(name,type=Path)
    p.add_argument('--audit',type=Path)
    a=p.parse_args()
    build(a.project,a.packet,a.output,a.audit)
