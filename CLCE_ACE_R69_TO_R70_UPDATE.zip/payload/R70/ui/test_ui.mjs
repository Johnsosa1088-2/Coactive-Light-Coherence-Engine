/** Independently replay the browser's poses, source geometry, attachment edits and section cuts. */
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
const {createCanvas}=createRequire(import.meta.url)('@napi-rs/canvas');
const [entry,result]=process.argv.slice(2),html=fs.readFileSync(entry,'utf8');
const extract=id=>html.match(new RegExp('<script[^>]*id="'+id+'"[^>]*>([\\s\\S]*?)</script>'))[1];
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
for(const k of ['geometry','renderer'])new Function(extract(k))();
assert(!/<script[^>]+src=|https?:\/\//.test(html));
const data=JSON.parse(extract('data')),m=Belly.model(data),work=data.belly.working,src=data.belly.source;
const project=(p,F)=>F.slice(0,3).map(r=>r[3]+r[0]*p[0]+r[1]*p[1]+r[2]*p[2]);
let maxCM=0,points=0,poses=0,localConfigurations=0,maxGap=0;
function compare(a,b){assert(a.every(Number.isFinite)&&b.every(Number.isFinite));maxCM=Math.max(maxCM,Math.hypot(...a.map((x,i)=>x-b[i])));points++;}
const vols=[],uniqueStates=new Set();
for(const scale of work.thicknessStops){
 const t=m.state(0,0,0,scale);vols.push(t.volumeCM3);
 for(let n=0;n<5;n++)for(const offset of data.response.offsetsMM){
   const s=m.state(0,0,0,scale,n,offset);maxGap=Math.max(maxGap,s.gapMM);
   work.verticesCM.forEach((p,i)=>{
     const wanted=p.map((v,k)=>v+(scale-1)*work.thicknessDeltaCM[i][k]+offset/10*work.editWeights[i][n]*data.response.axisCM[k]);compare(s.vertices[i],project(wanted,data.hand.events[0].F));
   });
   s.nodes.forEach((q,i)=>compare(q,s.prior.workingPatch.nodes[i]));compare(s.prior.workingPatch.anchor,s.prior.points[0]);
   uniqueStates.add(hash(JSON.stringify(s.local)));localConfigurations++;
 }
}
assert(vols[0]<vols[1]&&vols[1]<vols[2]);
for(const [ei,e] of data.hand.events.entries())for(const [wi,w] of m.handoff.old.wrists.entries())for(const [ki,k] of m.handoff.old.angles('index').entries()){
 const scale=work.thicknessStops[(ei+wi+ki)%3],n=(ei+wi+ki)%5,offset=data.response.offsetsMM[(ei+wi+ki)%3],s=m.state(k,w,e.index,scale,n,offset);
 for(let i=(wi+ki)%7;i<work.verticesCM.length;i+=13){
   const expected=work.verticesCM[i].map((v,k)=>v+(scale-1)*work.thicknessDeltaCM[i][k]+offset/10*work.editWeights[i][n]*data.response.axisCM[k]);compare(s.vertices[i],project(expected,e.F));
 }
 for(const [stored,world] of [[src.muscleCM,s.muscle],[src.tendonCM,s.tendon],[data.named.siteDotsCM,s.site],[data.named.ulnaFaceCM,s.face],[data.belly.originGuide.pointsCM,s.originGuide]]){
   stored.forEach((q,i)=>compare(world[i],project(q,e.F)));
 }
 compare(s.originGuide[0],s.witness);compare(s.originGuide[s.originGuide.length-1],s.centerline[0]);
 s.nodes.forEach((q,i)=>compare(q,s.prior.workingPatch.nodes[i]));maxGap=Math.max(maxGap,s.gapMM);poses++;
}
const audit=data.clearance;
if(audit){assert(Math.abs(audit.neutralVolumeCM3-vols[1])<1e-7);assert(audit.minBoneGapMM>0&&audit.minSkinGapMM>0);}
assert(maxCM<1e-7&&maxGap<1e-6);
const rest=m.state(),stops=[Math.round(m.stationMin),m.midStation,m.patchStation,Math.round(m.stationMax)];
const sections=stops.map(x=>m.section(rest,x));
assert(sections[1].surface.length>0&&sections[1].bones.length>0&&sections[1].skin.length>0);
assert.equal(sections[0].surface.length,0);assert.equal(sections[3].surface.length,0);
class Element{
  constructor(){this.children=[];this.events={};this.style={};this.checked=false;this.value='';this.textContent='';}
  appendChild(n){this.children.push(n);if(this.value==='')this.value=n.value;}
  addEventListener(k,fn){this.events[k]=fn;}
  emit(k){this.events[k]({target:this});}
}
const ids=Object.fromEntries([...html.matchAll(/\sid="([^"]+)"/g)].map(v=>[v[1],new Element()]));
for(const [k,w,h] of [['left',220,200],['right',220,200],['slice',240,154],['patch',250,127]])ids[k]=createCanvas(w,h);
ids.data.textContent=extract('data');globalThis.document={getElementById:k=>ids[k],createElement:()=>new Element()};
new Function(extract('interface'))();
const set=(k,v,event='change')=>{ids[k].value=String(v);ids[k].emit(event);};
const px=k=>{const c=ids[k];return hash(c.getContext('2d').getImageData(0,0,c.width,c.height).data);};
const source=px('left'),base=px('right');assert.notEqual(base,source);
const volumeStates=[];
for(const scale of work.thicknessStops){
 set('thick',scale);assert.equal(source,px('left'));volumeStates.push(px('right'));assert.equal(ids.volume.textContent,m.state(0,0,0,scale).volumeCM3.toFixed(3)+' cm³');
}
assert.equal(new Set(volumeStates).size,3);ids.patchPreset.emit('click');
for(let n=0;n<5;n++){
 set('node',n);const ref=px('patch');for(const off of [-.5,.5]){
   set('edit',off);assert.equal(ids.gap.textContent,'0.000 mm');assert.notEqual(px('patch'),ref);assert(ids.response.textContent.includes((.5*data.response.weights[n]).toFixed(3)+' mm'));
 }set('edit',0);assert.equal(px('patch'),ref);
}
ids.neutral.emit('click');assert.equal(px('right'),base);
const report={status:'PASS',htmlSHA256:hash(html),inputSHA256:data.sha256,armWristIndexPoses:poses,testedLocalControlCombinations:localConfigurations,distinctLocalGeometryStates:uniqueStates.size,
 independentlyProjectedPoints:points,maxCoordinateErrorCM:maxCM,largestPatchGapMM:maxGap,neutralPatchVolumeCM3:vols,
 sectionStationsMM:stops,midStationTriangleCuts:sections[1].surface.length,archiveGuideDots:data.named.siteDotsCM.length,
 independentClearanceReceiptEmbedded:Boolean(audit),rasterTests:'Three thickness levels and every patch node edit; independent native Canvas2D and simulated DOM. See R70_BROWSER_CHECK.json for actual local QtWebEngine.'};
fs.writeFileSync(result,JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
