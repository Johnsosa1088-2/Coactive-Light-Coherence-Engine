"""Certify the working forearm surface and origin guide through the inherited discrete arm and hand settings."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
from belly_collision import build_target, clearance_certificate, init


def read(p):
    return json.loads(p.read_bytes())


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def bbox_gap(lo, hi, other_lo, other_hi):
    return np.linalg.norm(np.maximum(np.maximum(lo-other_hi,other_lo-hi),0.),axis=-1)


def inspect(root, packet, neutral, dest, guide_override=None):
    init(root)
    from hand_model import HandModel, affine
    from segment_geometry import segment_triangles
    model=HandModel(root)
    data=read(packet)
    guide=np.array((data['originGuide'] if guide_override is None else read(guide_override))['pointsCM'])
    w=data['working']
    vertices,faces,radial,weights=(np.array(w[k]) for k in ('verticesCM','faces','thicknessDeltaCM','editWeights'))
    paths=['R65/geometry/R65_WRIST_FIT.json','R64/geometry/R64_ROUTE_RESPONSE.json','R63/geometry/R63_ISOLATED_HINGE.json',
           'R66/geometry/R66_HAND_JOIN.json','R69/attachment/R69_PATCH_RESPONSE.json','R70/origins/R70_FDP_SOURCE_REGISTRATION.json',
           'R66/motion/R66_DIGIT_MOTION.json','R66/motion/R66_DIGIT_WEIGHTS.json','R63/geometry/R63_ARM_BINDING.json','R65/hand/R65_WRIST_HAND.json']
    fit,tissue,hinge,join,patch,origin,motion,field,arm,hand=[read(root/k) for k in paths]
    axis=np.asarray(patch['axisCM'])
    shapes=np.stack([vertices+scale*radial+offset*weights[:,n,None]*axis for scale in (-.2,.2) for offset in (-.05,.05) for n in range(5)])
    bounds=np.linalg.norm(shapes-vertices,axis=-1).max(0)[faces].max(1)
    slo=shapes.min((0,1));shi=shapes.max((0,1))
    glo,ghi=guide.min(0),guide.max(0)
    def shell_bound(v,f):
        if not len(f):return .5
        tri=v[f]
        nearby=bbox_gap(slo,shi,tri.min(1),tri.max(1))<.050000001
        if not nearby.any():return .5
        target=build_target(v,f[nearby])
        value=clearance_certificate(vertices,faces,bounds,target)
        if value>1.e-8:return 10*value
        minimum=.05
        for n in range(5):
            for t in (-.1,.1):
                for e in (-.025,.025):
                    shifts=[a*radial+b*weights[:,n,None]*axis for a in (-.1,.1) for b in (-.025,.025)]
                    budget=np.linalg.norm(shifts,axis=-1).max(0)[faces].max(1)
                    minimum=min(minimum,clearance_certificate(vertices+t*radial+e*weights[:,n,None]*axis,faces,budget,target))
        return minimum*10
    def guide_gap(v,f):
        if not len(f):return 10.
        tri=v[f]
        near=bbox_gap(glo,ghi,tri.min(1),tri.max(1))<=1.0000000001
        tri=tri[near]
        a,b=guide[:-1],guide[1:]
        shortest=1.
        for group in np.array_split(tri,1+len(tri)//500):
            box=bbox_gap(np.minimum(a,b)[:,None],np.maximum(a,b)[:,None],group.min(1)[None],group.max(1)[None])
            i,j=np.nonzero(box<=shortest+1e-10)
            if len(i):
                ds,_=segment_triangles(a[i],b[i],group[j])
                shortest=min(shortest,float(np.sqrt(max(0.,np.min(ds)))))
        return 10*shortest
    local_receipt=read(neutral)
    assert local_receipt['status']=='PASS'
    if not guide_override:assert local_receipt['muscleSHA256']==sha(packet)
    cert=local_receipt['continuousClearance']
    rest,bones=model.pose(0,0)
    origin_contact=bones['ulna'].audit(guide)
    assert origin_contact['insideLengthMM']<1e-7 and origin_contact['touchingSegments']==[0]
    assert origin_contact['endpointContact']==[True,False]
    assert np.allclose(guide[0],origin['ulnaWitnessCM'],rtol=0,atol=1e-9)
    base_skin=rest.audit(guide)
    assert base_skin['outsideLengthMM']<1e-7
    radius=bones['radius'].audit(guide)
    assert radius['insideLengthMM']<1e-7
    result=dict(baseNeutralGuideSkinMM=base_skin['minGapMM'],guideRadiusMM=radius['minGapMM'],guideOriginUlnaContactSegments=origin_contact['touchingSegments'],
                maxWorldOriginErrorMM=0.,maxWorldCapErrorMM=0.,maxGuideLengthDriftMM=0.,
                minChangedSkinShellBoundMM=.5,minHumerusShellBoundMM=.5,minChangedSkinGuideMM=10.,minHumerusGuideMM=10.,
                minHandAndWristBoundMM=float('inf'),maxWristLocalArmDriftMM=0.)
    raw=model.used[model.faces]
    root_count=join['bodyVertexCount']
    body_faces=raw[np.all(raw<root_count,axis=1)]
    wrist_ids=np.array(hand['bodyVertexIDs0'])
    is_wrist=np.isin(raw,wrist_ids).any(1)
    distal_faces=is_wrist | (raw>=root_count).any(1)
    distal_vertices=np.unique(model.faces[distal_faces])
    wrist_body=np.unique(raw[distal_faces]);wrist_body=wrist_body[wrist_body<root_count]
    stable_faces=body_faces[~np.isin(body_faces,wrist_ids).any(1)]
    palm_lo=np.minimum(slo,glo);palm_hi=np.maximum(shi,ghi)
    weights_by_id={c['id']:c for c in field['channels']}
    channel={c['digit']:c for c in motion['channels']}
    settings=[('index',0)]+[(name,s['angleDeg']) for name in ('index','middle','ring') for s in channel[name]['states'] if s['angleDeg']]
    for name,angle in settings:
        model.index=channel[name];model.weights=weights_by_id[model.index['id']]
        for wrist in hand['states']:
            hand_skin,hard=model.pose(wrist['angleDeg'],angle)
            points=np.vstack([hand_skin.v[distal_vertices]]+[b.v for k,b in hard.items() if k not in ('radius','ulna','humerus')])
            dist=10*bbox_gap(palm_lo,palm_hi,points.min(0),points.max(0))
            result['minHandAndWristBoundMM']=min(result['minHandAndWristBoundMM'],float(dist))
    ri,wt=np.array(arm['bodyVertexIDs0']),np.array(arm['weights'])
    fi,delta=np.array(fit['bodyVertexIDs0']),np.array(fit['restDeltaCM'])
    base=model.body.copy();base[fi]-=delta
    upper=next(p for p in arm['parts'] if p['name']=='humerus')
    ulna=next(p for p in arm['parts'] if p['name']=='ulna')
    assert upper['owner']=='P' and ulna['owner']=='F'
    endpoint=np.array(ulna['vertices'])[origin['matchingWorkingVertex0']]
    r69=read(root/'R69/routes/R69_INDEX_PROXIMAL.json')
    cap=np.asarray(w['patchVertexIDs0']);old=np.array(r69['patches']['working']['nodesCM'])
    events=[(e,tissue['events'][i]) for i,e in enumerate(arm['events'])]+[(e,None) for e in hinge['samples']]
    rows=[]
    for event,source in events:
        F,P=np.array(event['F']),np.array(event['P'])
        inv=np.linalg.inv(F);rot=F[:3,:3]
        assert np.allclose(rot.T@rot,np.eye(3),atol=1e-11) and np.linalg.det(rot)>0
        cur=base.copy()
        for j,M in enumerate([P,F]):cur[ri]+=wt[:,j,None]*(affine(base[ri],M)-base[ri])
        cur[fi]+=delta@rot.T
        if source is not None:cur[tissue['bodyVertexIDs0']]+=np.array(source['muscleDeltaCM'])+np.array(source['tendonDeltaCM'])
        local=affine(cur,inv);drift=np.linalg.norm(local-model.body,axis=1)
        result['maxWristLocalArmDriftMM']=max(result['maxWristLocalArmDriftMM'],float(10*drift[wrist_body].max()))
        changed=stable_faces[np.any(drift[stable_faces]>1e-9,axis=1)]
        hum=affine(np.array(upper['vertices']),inv@P);hf=np.array(upper['faces'])
        values=dict(minChangedSkinShellBoundMM=shell_bound(local,changed),minHumerusShellBoundMM=shell_bound(hum,hf),
                    minChangedSkinGuideMM=guide_gap(local,changed),minHumerusGuideMM=guide_gap(hum,hf))
        for k,v in values.items():result[k]=min(result[k],v)
        world=affine(guide,F)
        result['maxWorldOriginErrorMM']=max(result['maxWorldOriginErrorMM'],float(10*np.linalg.norm(world[0]-affine(endpoint,F))))
        result['maxWorldCapErrorMM']=max(result['maxWorldCapErrorMM'],float(10*np.linalg.norm(affine(vertices[cap],F)-affine(old,F),axis=1).max()))
        length=lambda p:np.linalg.norm(np.diff(p,axis=0),axis=1).sum()
        result['maxGuideLengthDriftMM']=max(result['maxGuideLengthDriftMM'],float(10*abs(length(world)-length(guide))))
        rows.append(dict(pose0=len(rows),**values))
    result['minOverallShellSkinBoundMM']=min(cert['minSkinLowerBoundMM'],result['minChangedSkinShellBoundMM'],result['minHandAndWristBoundMM'])-1e-7
    result['minOverallShellBoneBoundMM']=min(cert['minBoneLowerBoundMM'],result['minHumerusShellBoundMM'],result['minHandAndWristBoundMM'])-1e-7
    result['minOverallGuideSkinBoundMM']=min(result['baseNeutralGuideSkinMM'],result['minChangedSkinGuideMM'],result['minHandAndWristBoundMM'])-1e-7
    result['armEvents']=len(arm['events']);result['isolatedElbowSamples']=len(hinge['samples'])
    result['distalStates']=len(settings)*len(hand['states'])
    result['combinations']=len(events)*result['distalStates']
    passed=(result['combinations']==2200 and result['minHumerusGuideMM']>0 and result['minOverallGuideSkinBoundMM']>0 and
            result['minOverallShellBoneBoundMM']>0 and result['minOverallShellSkinBoundMM']>0 and
            max(result[k] for k in ('maxWorldCapErrorMM','maxWorldOriginErrorMM','maxGuideLengthDriftMM','maxWristLocalArmDriftMM'))<1e-7)
    receipt=dict(status='PASS' if passed else 'HOLD',summary=result,rows=rows,
        sourceSHA256={k:sha(root/k) for k in paths+['R69/routes/R69_INDEX_PROXIMAL.json']},
        packetSHA256=sha(packet),neutralAuditSHA256=sha(neutral),
        scope='Rigid forearm replay of an authored closed proxy and a one-dimensional guide. Rechecks moving skin facets and humerus relative to the forearm. Source ulna witness contact at the first guide point is intentional. Distal hand and wrist checks use a conservative combined box. Continuous shape bound at each discrete motion setting, with one edited node at a time. Thin guide clearances are centreline distances. No muscle force or soft-skin coupling inferred.')
    dest.write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n')
    print(receipt['status'],json.dumps(result),flush=True)
    return passed

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('root','packet','neutral','dest'):parser.add_argument(name,type=Path)
    parser.add_argument('--guide-override',type=Path)
    args=parser.parse_args()
    sys.exit(0 if inspect(args.root.resolve(),args.packet,args.neutral,args.dest,args.guide_override) else 1)
