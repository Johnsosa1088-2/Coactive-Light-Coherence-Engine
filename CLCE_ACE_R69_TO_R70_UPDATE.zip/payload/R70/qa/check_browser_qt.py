"""Exercise the actual R70 page with Slicer's embedded QtWebEngine.

From the expanded project root, run with Slicer 5.12.4 or compatible:
  Slicer --no-splash --no-main-window --disable-cli-modules --disable-loadable-modules --disable-scripted-loadable-modules --testing --python-script R70/qa/check_browser_qt.py

For headless Linux set QT_QPA_PLATFORM=offscreen and QT_QUICK_BACKEND=software.
If Slicer has only the xcb platform, set QT_QPA_PLATFORM_PLUGIN_PATH to the
installed Qt 5 platform directory containing libqoffscreen.so.
The receipt defaults to ./R70_BROWSER_LOCAL.json. ACE_QT_RECEIPT and
ACE_QT_SCREENSHOT optionally select the output receipt and desktop PNG paths.
"""
import hashlib
import json
import os
from pathlib import Path

import qt
import slicer

# Slicer delegates --python-script to a Python console. Some versions provide
# __file__ relative to the caller, others expose only the current directory.
folder = Path(globals().get('__file__', '')).resolve().parent
if not (folder / 'live_controls.js').is_file():
    folder = Path('R70/qa').resolve()
entry = Path(os.environ.get('ACE_QT_ENTRY', folder.parent / 'ui' / 'Flexor_belly.html')).resolve()
receipt = Path(os.environ.get('ACE_QT_RECEIPT', 'R70_BROWSER_LOCAL.json'))
screenshot = os.environ.get('ACE_QT_SCREENSHOT')
loop = qt.QEventLoop()
view = slicer.qSlicerWebWidget()
view.javaScriptConsoleMessageLoggingEnabled = True
view.resize(1340, 960)
view.show()
report = dict(status='TIMEOUT', entry=entry.name, htmlSHA256=hashlib.sha256(entry.read_bytes()).hexdigest(),
              browser='QtWebEngine through Slicer qSlicerWebWidget',
              scope='Live Linux QtWebEngine, local HTML, DOM events, raster canvases and responsive layout. System Chromium desktop execution on this host and Windows execution remain unverified.')
query_size = '''JSON.stringify({width:innerWidth,height:innerHeight,contentWidth:document.documentElement.scrollWidth,plateWidth:document.getElementById("right").getBoundingClientRect().width})'''
phase = 'desktop'


def fail(message):
    report.update(status='FAIL', error=str(message))
    loop.quit()


def received(_js, text):
    global phase
    try:
        data = json.loads(text)
        if phase == 'controls':
            report.update(data)
            loop.quit()
            return
        if data['contentWidth'] > data['width'] or data['plateWidth'] <= 0:
            raise ValueError('Overflow or zero-sized plate')
        report[phase] = data
        if phase == 'desktop':
            if data['width'] != 1340:
                raise ValueError('Desktop viewport did not initialize')
            if screenshot and not view.grab().save(screenshot):
                raise OSError('Could not save screenshot')
            phase = 'narrow'
            view.resize(390, 844)
            qt.QTimer.singleShot(400, lambda: view.evalJS(query_size))
        else:
            if data['width'] != 390:
                raise ValueError('Narrow viewport did not initialize')
            phase = 'controls'
            view.resize(1340, 960)
            qt.QTimer.singleShot(400, lambda: view.evalJS((folder / 'live_controls.js').read_text()))
    except Exception as error:
        fail(error)


def loaded(ok):
    report['loadFinished'] = ok
    if not ok:
        fail('The local workbench failed to load')
        return
    qt.QTimer.singleShot(400, lambda: view.evalJS(query_size))


view.connect('loadFinished(bool)', loaded)
view.connect('evalResult(QString,QString)', received)
view.setUrl(qt.QUrl.fromLocalFile(str(entry)).toString())
qt.QTimer.singleShot(90000, loop.quit)
loop.exec_()
receipt.write_text(json.dumps(report, indent=2) + '\n')
print('R70 browser:', report['status'], report.get('error', ''), flush=True)
slicer.app.exit(int(report['status'] != 'PASS'))
