"""Triangle-pair clearance for the R70 shell. All caller coordinates in cm."""
import sys
import numpy as np
from scipy.spatial import cKDTree


def init(root):
    global segment_triangles
    source = str((root / 'R67/qa').resolve())
    if source not in sys.path:
        sys.path.insert(0, source)
    from segment_geometry import segment_triangles


class FaceTree:
    def __init__(self, vertices, faces):
        self.v = np.asarray(vertices, dtype=float)
        self.f = np.asarray(faces, dtype=int)
        self.tri = self.v[self.f]
        self.lo = self.tri.min(axis=1)
        self.hi = self.tri.max(axis=1)
        center = (self.lo + self.hi) * .5
        radius = np.linalg.norm(self.hi - center, axis=1)
        self.nearest = cKDTree(np.vstack((self.tri.reshape(-1, 3), self.tri.mean(axis=1))))
        self.buckets = []
        levels = np.floor(np.log2(np.maximum(radius, 1e-12))).astype(int)
        for level in np.unique(levels):
            ids = np.flatnonzero(levels == level)
            self.buckets.append((cKDTree(center[ids]), ids, radius[ids].max()))


def build_target(vertices, faces):
    return FaceTree(vertices, faces)


def _pairs(tri, tree, limit):
    lo, hi = tri.min(axis=1), tri.max(axis=1)
    center = (lo + hi) * .5
    radius = np.linalg.norm(hi - center, axis=1)
    for bucket, ids, max_radius in tree.buckets:
        matches = bucket.query_ball_point(center, radius + max_radius + limit + 1e-10)
        counts = np.fromiter((len(m) for m in matches), int, len(matches))
        if not counts.any():
            continue
        i = np.repeat(np.arange(len(tri)), counts)
        j = ids[np.concatenate([m for m in matches if len(m)])]
        delta = np.maximum(np.maximum(lo[i] - tree.hi[j], tree.lo[j] - hi[i]), 0.)
        keep = np.einsum('ij,ij->i', delta, delta) <= (limit + 1e-10)**2
        if keep.any():
            yield i[keep], j[keep]


def triangle_pair_squared(tri_a, tri_b):
    # Six directed edge/triangle tests include all face, edge and piercing minima.
    d = np.full(len(tri_a), np.inf)
    for a, b in ((tri_a, tri_b), (tri_b, tri_a)):
        for k in range(3):
            ds, _ = segment_triangles(a[:, k], a[:, (k+1)%3], b)
            d = np.minimum(d, ds)
    return d


def mesh_gap(vertices, faces, target, cutoff=None):
    tri = np.asarray(vertices)[faces]
    if cutoff is None:
        # Distances between known surface samples give a valid global upper bound.
        probes = np.vstack((vertices, tri.mean(axis=1)))
        limit = target.nearest.query(probes)[0].min() + 1e-9
    else:
        limit = float(cutoff)
    best = limit**2
    nearest = (-1, -1)
    for i, j in _pairs(tri, target, limit):
        # Split rare large candidate sets to bound memory.
        for k in range(0,len(i),16000):
            a, b = i[k:k+16000], j[k:k+16000]
            d = triangle_pair_squared(tri[a], target.tri[b])
            p = int(np.argmin(d))
            if d[p] <= best:
                best = d[p]
                nearest = (int(a[p]), int(b[p]))
    return (float(np.sqrt(max(0.,best))), *nearest)


def self_crossing(vertices, faces):
    faces = np.asarray(faces)
    tree = build_target(vertices, faces)
    for i,j in _pairs(tree.tri, tree, 1e-8):
        keep=(i<j) & ~np.any(faces[i,:,None]==faces[j,None,:],axis=(1,2))
        if not keep.any():
            continue
        i,j=i[keep],j[keep]
        d=triangle_pair_squared(tree.tri[i],tree.tri[j])
        hit=np.flatnonzero(d<1e-17)
        if len(hit):
            k=hit[0]
            return [int(i[k]),int(j[k])]
    return None


def winding(point, tri):
    a,b,c=np.moveaxis(tri-np.asarray(point),1,0)
    aa,bb,cc=(np.linalg.norm(v,axis=1) for v in (a,b,c))
    dot=lambda x,y:np.einsum('ij,ij->i',x,y)
    return float(np.arctan2(dot(a,np.cross(b,c)),aa*bb*cc+aa*dot(b,c)+bb*dot(c,a)+cc*dot(a,b)).sum()/(2*np.pi))


def clearance_certificate(vertices, faces, bounds, target):
    """Lower bound for clearance under a separate displacement budget per triangle.

    Barycentric interpolation bounds each triangle displacement by its largest
    vertex displacement. Candidate face pairs closer than budget+0.5mm receive
    exact Euclidean separation tests. The result is capped at that 0.5mm.
    """
    tri = vertices[faces]
    cap = .05
    floor = cap
    for i,j in _pairs(tri,target,float(np.max(bounds))+cap):
        lo,hi=tri[i].min(axis=1),tri[i].max(axis=1)
        aabb=np.linalg.norm(np.maximum(np.maximum(lo-target.hi[j],target.lo[j]-hi),0.),axis=1)
        near=aabb<=bounds[i]+cap+1e-10
        if near.any():
            a,b=i[near],j[near]
            ds=np.sqrt(np.maximum(0.,triangle_pair_squared(tri[a],target.tri[b])))
            floor=min(floor,float(np.min(ds-bounds[a])))
    return floor
