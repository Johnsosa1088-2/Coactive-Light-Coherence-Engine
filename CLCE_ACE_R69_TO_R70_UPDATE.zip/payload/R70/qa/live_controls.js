(function(){
  const result={status:'FAIL',userAgent:navigator.userAgent,fileURL:location.protocol==='file:'};
  try{
    const el=k=>document.getElementById(k),read=k=>el(k).textContent,val=k=>el(k).value;
    const check=(cond,msg)=>{if(!cond)throw Error(msg);};
    function choose(k,v,event='change'){
      el(k).value=String(v);check(val(k)===String(v),'Unavailable '+k+' '+v);el(k).dispatchEvent(new Event(event,{bubbles:true}));
    }
    function pixels(k){
      const c=el(k),v=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let h=2166136261,opaque=0;
      for(let i=0;i<v.length;i++){h=Math.imul(h^v[i],16777619);if(i%4===3&&v[i]>240)opaque++;}
      check(opaque>2000,'Empty canvas '+k);return h>>>0;
    }
    const packet=JSON.parse(read('data')),weights=packet.response.weights;
    const baseline={working:pixels('right'),source:pixels('left'),section:pixels('slice'),frame:read('frame'),volume:read('volume')};
    check(result.fileURL&&baseline.working!==baseline.source&&read('gap')==='0.000 mm','Failed opening state');
    check(el('arm').options.length===17&&el('thick').options.length===3&&el('node').options.length===5,'Missing control states');
    result.baseline=baseline;result.thickness=[];
    for(const scale of [.8,1,1.2]){
      choose('thick',scale);check(pixels('left')===baseline.source,'Thickness mutated source raster');
      result.thickness.push({scale,volumeCM3:parseFloat(read('volume')),working:pixels('right'),section:pixels('slice')});
    }
    for(const key of ['volumeCM3','working','section'])check(new Set(result.thickness.map(q=>q[key])).size===3,'Collapsed thickness '+key);
    if(packet.clearance)check(Math.abs(result.thickness[1].volumeCM3-packet.clearance.neutralVolumeCM3)<.00051,'Volume disagrees with independent surface receipt');
    check(result.thickness[0].volumeCM3<result.thickness[1].volumeCM3&&result.thickness[1].volumeCM3<result.thickness[2].volumeCM3,'Unexpected volume progression');
    el('patchPreset').click();
    const source=pixels('left');result.edits=[];
    for(let node=0;node<5;node++){
      choose('node',node);choose('edit',0);const ref=pixels('patch'),view=pixels('right');
      for(const off of [-.5,.5]){
        choose('edit',off);
        check(read('gap')==='0.000 mm'&&read('response').includes((weights[node]*.5).toFixed(3)+' mm'),'Shared attachment mismatch '+node);
        check(source===pixels('left')&&ref!==pixels('patch')&&view!==pixels('right'),'Node offset raster '+node);
        result.edits.push({node,offsetMM:off,patch:pixels('patch'),working:pixels('right'),maxGap:read('gap')});
      }
      choose('edit',0);check(ref===pixels('patch')&&view===pixels('right'),'Node offset failed reset');
    }
    el('handPreset').click();result.poses=[];
    for(const k of [0,5,10,15]){choose('knuckle',k);result.poses.push({k,working:pixels('right'),length:read('length')});}
    check(new Set(result.poses.map(q=>q.working)).size===4,'Identical index poses');
    result.selectors={};
    for(const key of ['wrist','arm','focus','camera']){
      el(key==='arm'?'armPreset':'handPreset').click();
      const options=key==='arm'?['0','4','8']:Array.from(el(key).options).map(x=>x.value);
      const states=options.map(v=>{choose(key,v);return pixels('right');});
      check(new Set(states).size===states.length,'Collapsed selector '+key);
      result.selectors[key]={options,pixels:states};
    }
    el('overview').click();result.layers={};
    for(const layer of ['skin','bones','lead','markers','overlay','site','origin']){
      const id=layer==='site'?'left':'right',a=pixels(id);el(layer).click();const b=pixels(id);
      check(a!==b,'Invisible layer '+layer);el(layer).click();check(pixels(id)===a,'Layer failed reset '+layer);result.layers[layer]=b;
    }
    const lo=Number(el('station').min),hi=Number(el('station').max);
    result.sections=Array.from({length:6},(_,i)=>{const mm=Math.round(lo+(hi-lo)*i/5);choose('station',mm,'input');return {mm,range:read('sectionRead'),pixels:pixels('slice')};});
    check(new Set(result.sections.map(s=>s.pixels)).size===6,'Plane slider failed');
    for(const [button,focus] of [['overview','muscle'],['patchPreset','patch'],['ulnaPreset','ulna'],['armPreset','arm'],['handPreset','whole']]){
      el(button).click();check(val('focus')===focus,'Preset failed '+button);
    }
    choose('wrist',2);choose('edit',.5);choose('arm',8);choose('thick',1.2);el('neutral').click();
    check(['knuckle','wrist','edit','arm'].every(k=>val(k)==='0')&&val('thick')==='1','Neutral controls failed');
    check(baseline.working===pixels('right')&&baseline.source===pixels('left')&&baseline.section===pixels('slice'),'Neutral rasters failed');
    result.status='PASS';
  }catch(e){result.error=String(e);}
  return JSON.stringify(result);
})()
