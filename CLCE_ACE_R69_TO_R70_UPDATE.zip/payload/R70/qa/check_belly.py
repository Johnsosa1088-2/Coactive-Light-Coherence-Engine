"""Audit the working R70 closed surface against actual forearm skin and bones.

Use `python -B R70/qa/check_belly.py PROJECT PACKET OUT`. Tests all supplied
thickness stops and each R69 node at both offset extremes. All geometry in cm.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components

from belly_collision import init, build_target, mesh_gap, self_crossing, winding, clearance_certificate


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def topology(points, faces):
    assert np.isfinite(points).all() and faces.ndim==2 and faces.shape[1]==3
    assert set(np.unique(faces))==set(range(len(points)))
    if len(np.unique(np.sort(faces,axis=1),axis=0))!=len(faces):
        raise ValueError('Duplicate triangles')
    oriented=Counter((int(a),int(b)) for face in faces for a,b in zip(face,np.roll(face,-1)))
    if any(a==b or count!=1 or oriented[b,a]!=1 for (a,b),count in oriented.items()):
        raise ValueError('The surface has an open, inconsistent or nonmanifold edge.')
    undirected=len(oriented)//2
    edge=np.array(list(oriented))
    graph=coo_matrix((np.ones(len(edge)),(edge[:,0],edge[:,1])),shape=(len(points),len(points)))
    components=connected_components(graph,directed=False)[0]
    assert components==1
    euler=len(points)-undirected+len(faces)
    assert euler==2
    return dict(vertices=len(points),triangles=len(faces),edges=undirected,eulerCharacteristic=euler,components=int(components),
                pairedReverseEdges=True)


def coords(base,radial,active,axis,thickness,node,mm):
    return base+(thickness-1.)*radial+active[:,node,None]*axis*mm/10.


def run(root,path,out):
    init(root)
    from hand_model import HandModel
    from segment_geometry import TriangleSurface
    patch_path=root/'R69/routes/R69_INDEX_PROXIMAL.json'
    response_path=root/'R69/attachment/R69_PATCH_RESPONSE.json'
    curves_path=root/'R69/qa/R69_GOLD_FOREARM.json'
    p=read(path)
    w=p['working']
    base,radial,active,faces=(np.array(w[k]) for k in ('verticesCM','thicknessDeltaCM','editWeights','faces'))
    patch_ids=np.asarray(w['patchVertexIDs0'])
    r69=read(patch_path)
    middle_path=root/'R68/routes/R68_MIDDLE_FLEXOR.json'
    digital=[np.array(s['pointsCM']['index-mtj-working'])[r69['join']['workingIndex0']:] for s in r69['states']]
    middle=[np.array(s['pointsCM']['middle-fdp-working']) for s in read(middle_path)['states']]
    distal=[(line,line[:-1].copy(),line[1:].copy()) for line in digital+middle]
    # Screen every distal segment against the entire envelope, with an exact
    # fallback if its lower bound falls below 0.5 mm.
    def distal_gap(shell):
        lo,hi=shell.v.min(0),shell.v.max(0)
        floor=.5
        for line,a,b in distal:
            d=10*np.linalg.norm(np.maximum(np.maximum(np.minimum(a,b)-hi,lo-np.maximum(a,b)),0.),axis=1).min()
            if d<floor:
                full=shell.audit(line)
                if full['insideLengthMM']>1e-8:
                    return 0.
                floor=min(floor,full['minGapMM'])
        return floor
    patch=np.asarray(r69['patches']['working']['nodesCM'])
    response=read(response_path)
    axis=np.asarray(response['axisCM'])
    weights=np.asarray(response['weights'])
    old_start=np.array(next(r for r in r69['routes'] if r['id']=='index-mtj-working')['restCM'][0])
    conn=np.array(next(r for r in r69['routes'] if r['id']=='index-mtj-working')['restCM'])[:response['joinIndex0']+1]
    assert active.shape==(len(base),5) and np.all(np.isfinite(active)) and np.min(active)>=-1e-10
    assert np.allclose(base[patch_ids],patch,rtol=0,atol=1e-9) and np.allclose(active[patch_ids],np.eye(5),rtol=0,atol=1e-10)
    assert np.max(np.abs(radial[patch_ids]))<1e-9
    topo=topology(base,faces)
    neutral_tri=base[faces]
    neutral_normals=np.cross(neutral_tri[:,1]-neutral_tri[:,0],neutral_tri[:,2]-neutral_tri[:,0])
    neutral_normals/=np.linalg.norm(neutral_normals,axis=1)[:,None]
    model=HandModel(root)
    skin,bones=model.pose(0,0)
    body=build_target(skin.v,skin.f)
    bone_points=[];bone_faces=[];owners=[];offset=0
    for name,b in bones.items():
        bone_points.append(b.v)
        bone_faces.append(b.f+offset)
        owners.extend([name]*len(b.f))
        offset+=len(b.v)
    hard=build_target(np.vstack(bone_points),np.vstack(bone_faces))
    gold=read(curves_path)['lines']
    raw={}
    for kind in ('muscle','tendon'):
        line=np.array(p['source'][kind+'CM'])
        matrix=np.array(p['source']['matrixLocalToCM'])
        original=np.asarray(gold[kind]['neutralPointsLocal'])
        expected=original@matrix[:3,:3].T+matrix[:3,3]
        assert np.allclose(line,expected,rtol=0,atol=1e-8)
        registration_error=float(10*np.linalg.norm(expected-line,axis=1).max())
        keep=np.r_[True,np.linalg.norm(np.diff(line,axis=0),axis=1)>1e-10]
        line=line[keep]
        s=skin.audit(line)
        b={key:bone.audit(line) for key,bone in bones.items() if key in ('radius','ulna','humerus')}
        raw[kind]=dict(verticesInArchivedDrawing=len(gold[kind]['neutralPointsLocal']),
                       registeredPointErrorMM=registration_error,lengthMM=s['routeLengthMM'],outsideSkinMM=s['outsideLengthMM'],
                       penetratingBonesMM={k:v['insideLengthMM'] for k,v in b.items()},
                       minSkinGapMM=s['minGapMM'])
    origin=p['originGuide']
    guide=np.array(origin['pointsCM'])
    source_path=root/'R70/origins/R70_FDP_SOURCE_REGISTRATION.json'
    witness=read(source_path)
    ulna=bones['ulna']
    face=int(origin['sourceFace0'])
    vertex=int(origin['sourceUlnaVertex0'])
    assert face==witness['currentUlnaFace0'] and vertex in ulna.f[face]
    assert np.allclose(ulna.v[ulna.f[face]],witness['ulnaFaceCM'],rtol=0,atol=1e-9)
    assert np.allclose(guide[0],witness['ulnaWitnessCM'],rtol=0,atol=1e-9)
    assert np.allclose(guide[0],ulna.v[vertex],rtol=0,atol=1e-9)
    assert np.allclose(guide[-1],base[0],rtol=0,atol=1e-9)
    gs=skin.audit(guide)
    guide_bones={k:b.audit(guide) for k,b in bones.items()}
    assert gs['outsideLengthMM']<1e-7 and gs['minGapMM']>1e-6
    assert guide_bones['ulna']['touchingSegments']==[0]
    assert all(b['insideLengthMM']<1e-7 and not b['surfaceCrossingDistancesMM'] for b in guide_bones.values())
    assert all(b['minGapMM']>1e-6 for k,b in guide_bones.items() if k!='ulna')
    guide_report=dict(points=len(guide),lengthMM=gs['routeLengthMM'],skinGapMM=gs['minGapMM'],
        ulnaTouchingSegments=guide_bones['ulna']['touchingSegments'],ulnaEndpointGapMM=guide_bones['ulna']['endpointGapsMM'][0],
        otherBoneGapsMM={k:b['minGapMM'] for k,b in guide_bones.items() if k!='ulna'},sourceFace0=face,sourceUlnaVertex0=vertex,
        scope='Authored zero-width path between an attributed ulna witness and the proximal working belly. Both endpoint contacts are intentional.')
    rows=[]
    issues=[]
    thickness_rows=[]
    # One neutral node state and ten distinct signed edits for each thickness.
    for thickness in w['thicknessStops']:
        for n,mm in [(0,0.)]+[(i,m) for i in range(5) for m in (-.5,.5)]:
            points=coords(base,radial,active,axis,thickness,n,mm)
            tri=points[faces]
            norm=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0])
            projected=np.einsum('ij,ij->i',norm,neutral_normals)*50.
            a,b,c=np.moveaxis(tri-points.mean(axis=0),1,0)
            volume=float(np.einsum('ij,ij->',a,np.cross(b,c))/6)
            g_skin,_,skin_id=mesh_gap(points,faces,body)
            g_hard,_,bone_id=mesh_gap(points,faces,hard)
            assert skin_id>=0 and bone_id>=0
            skin_inside=abs(winding(points[0],body.tri))>.5
            inside_bone=any(abs(winding(points[0],b.t))>.5 for b in bones.values())
            contains_bone=any(abs(winding(b.v[0],tri))>.5 for b in bones.values())
            actual_patch=points[patch_ids]
            desired=patch.copy();desired[n]+=axis*mm/10.
            tip=old_start+axis*(mm/10)*weights[n]
            node_err=float(np.linalg.norm(actual_patch-desired,axis=1).max()*10)
            seam_err=float(np.linalg.norm(weights@actual_patch-tip)*10)
            shell=TriangleSurface(points,faces)
            true_lead=conn+np.asarray(response['routeInfluences'][:len(conn)])[:,None]*axis*(mm/10)*weights[n]
            tendon=shell.audit(true_lead)
            proximal=shell.audit(guide)
            guide_root_gap=float(10*np.linalg.norm(points[0]-guide[-1]))
            distal_floor=distal_gap(shell)
            self_hit=self_crossing(points,faces)
            row=dict(scale=float(thickness),node=n,offsetMM=mm,volumeCM3=volume,minSkinGapMM=g_skin*10,
                     minBoneGapMM=g_hard*10,closestBone=owners[bone_id],minProjectedFaceAreaMM2=float(projected.min()),
                     inheritedDistalRouteClearanceLowerBoundMM=distal_floor,leadInsideEnvelopeMM=tendon['insideLengthMM'],
                     leadRootToCapMM=tendon['endpointGapsMM'][0],additionalLeadContactSegments=[i for i in tendon['touchingSegments'] if i>0],
                     guideProximalVertexGapMM=guide_root_gap,guideInsideBellyMM=proximal['insideLengthMM'],
                     guideTouchingBellySegments=proximal['touchingSegments'],patchErrorMM=node_err,weightedAnchorErrorMM=seam_err,insideSkin=bool(skin_inside),
                     overlapsBone=bool(inside_bone or contains_bone or g_hard<1e-8),nonAdjacentSelfCrossing=self_hit)
            if not(skin_inside and not row['overlapsBone'] and g_skin>1e-8 and volume>0 and projected.min()>1e-11
                    and self_hit is None and proximal['touchingSegments']==[len(guide)-2]
                    and max(guide_root_gap,proximal['insideLengthMM'])<1e-7 and max(node_err,seam_err,tendon['endpointGapsMM'][0],tendon['insideLengthMM'])<1e-7
                    and not row['additionalLeadContactSegments'] and distal_floor>1e-7):
                issues.append(row)
            rows.append(row)
            if mm==0:thickness_rows.append(dict(scale=float(thickness),volumeCM3=volume))
    # Bound the *entire* continuous authoring range, using each triangle's
    # individual affine motion budget over a rectangle of thickness and offset.
    # Self-intersection tests above concern the 33 sampled meshes.
    certified_skin=certified_bone=float('inf')
    certificates=0
    for node in range(5):
        for t0,t1 in ((.8,1.),(1.,1.2)):
            for e0,e1 in ((-.5,0.),(0.,.5)):
                cells=[(t0,t1,e0,e1,0)]
                while cells:
                    a,b,c,d,depth=cells.pop()
                    t,m=(a+b)*.5,(c+d)*.5
                    center=coords(base,radial,active,axis,t,node,m)
                    displacements=np.stack([coords(base,radial,active,axis,yt,node,ym)-center
                                            for yt in (a,b) for ym in (c,d)])
                    bounds=np.max(np.linalg.norm(displacements,axis=2),axis=0)[faces].max(axis=1)
                    gs=clearance_certificate(center,faces,bounds,body)
                    gb=clearance_certificate(center,faces,bounds,hard)
                    if min(gs,gb)<1e-8 and depth<4:
                        cells.extend((lo,hi,bot,top,depth+1) for lo,hi in ((a,t),(t,b))
                                     for bot,top in ((c,m),(m,d)))
                        continue
                    certified_skin=min(certified_skin,gs*10)
                    certified_bone=min(certified_bone,gb*10)
                    certificates+=1
                    if min(gs,gb)<=1e-8:
                        issues.append(dict(unresolvedContinuousCell=[node,a,b,c,d],skinBoundMM=gs*10,boneBoundMM=gb*10))
                        cells.clear()
                        break
    assert len(rows)==33
    vol=[r['volumeCM3'] for r in thickness_rows]
    increasing=all(a<b for a,b in zip(vol,vol[1:]))
    if not increasing:issues.append({'error':'Non-increasing volume across ordered thickness controls'})
    neutral=next(r for r in thickness_rows if r['scale']==1.)
    summary=dict(minSkinGapMM=min(r['minSkinGapMM'] for r in rows),minBoneGapMM=min(r['minBoneGapMM'] for r in rows),
                 minVolumeCM3=min(r['volumeCM3'] for r in rows),maxVolumeCM3=max(r['volumeCM3'] for r in rows),
                 neutralVolumeCM3=neutral['volumeCM3'],maxPatchNodeGapMM=max(r['patchErrorMM'] for r in rows),
                 maxWeightedAnchorGapMM=max(r['weightedAnchorErrorMM'] for r in rows),minProjectedFaceAreaMM2=min(r['minProjectedFaceAreaMM2'] for r in rows),
                 maxLeadReentryMM=max(r['leadInsideEnvelopeMM'] for r in rows),
                 maxOriginGuideReentryMM=max(r['guideInsideBellyMM'] for r in rows),
                 distalLinesLowerBoundMM=min(r['inheritedDistalRouteClearanceLowerBoundMM'] for r in rows),
                 vertices=len(base),faces=len(faces),localConfigurations=len(rows),boneObjects=len(bones),skinTriangles=len(skin.f))
    digest={n.relative_to(root).as_posix():sha(n) for n in [source_path,patch_path,middle_path,response_path,curves_path,root/'R63/geometry/R63_ARM_BINDING.json',root/'R65/geometry/R65_WRIST_FIT.json',root/'R66/geometry/R66_HAND_JOIN.json',root/'R66/geometry/R66_HAND_SURFACE.json',root/'R56/models/R56_WORKING_EXTERIOR.obj']}
    result=dict(status='PASS' if not issues else 'HOLD',sourceSHA256=digest,muscleSHA256=sha(path),summary=summary,
                continuousClearance=dict(certifiedCells=certificates,minSkinLowerBoundMM=certified_skin,minBoneLowerBoundMM=certified_bone,
                  scope='Neutral forearm. Covers any single selected node offset in [-0.5,0.5] mm and thickness scale in [0.8,1.2]. Separate per-triangle vertex-motion budgets bounded against exact surface distance. Reported lower bounds capped at 0.5 mm.'),
                topology=topo,originGuide=guide_report,thicknessRows=thickness_rows,rawRegistration=raw,rows=rows,issues=issues,
                scope='Neutral forearm in registered cm. Exact triangle-pair minima, enclosed-surface winding checks, every pair of nonincident shell triangles screened for contact, signed local face orientation and closed-mesh volume at every released web shape. Tested against all 30 bony surfaces and the R66 joined exterior. Other soft-tissue interaction, material forces, physiology and broad simultaneous command sweeps remain open.')
    out.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(result['status'],summary,issues[:1],flush=True)
    return not issues


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    for arg in ('root','packet','out'):parser.add_argument(arg,type=Path)
    args=parser.parse_args()
    sys.exit(0 if run(args.root.resolve(),args.packet,args.out) else 1)
