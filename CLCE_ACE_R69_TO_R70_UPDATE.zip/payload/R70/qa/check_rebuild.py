"""Rebuild the registered guide, working envelope, and standalone view in a fresh directory."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

root=Path(sys.argv[1]).resolve()
audit=root/'R70/qa/R70_BELLY_GEOMETRY.json'
jobs=[('R70/origins/R70_FDP_SOURCE_REGISTRATION.json','R70/origins/register_fdp_source.py'),
      ('R70/muscle/R70_FDP_ENVELOPE.json','R70/muscle/build_envelope.py'),
      ('R70/ui/Flexor_belly.html','R70/ui/build.py')]
receipt={}
with tempfile.TemporaryDirectory() as target:
    for idx,(name,program) in enumerate(jobs):
        produced=Path(target)/Path(name).name
        args=[root,produced] if idx<2 else [root,root/jobs[1][0],produced,'--audit',audit]
        subprocess.run([sys.executable,'-B',root/program,*args],check=True)
        content=produced.read_bytes()
        if content!=(root/name).read_bytes():raise ValueError('Rebuild differs for '+name)
        receipt[name]=hashlib.sha256(content).hexdigest()
Path(sys.argv[2]).write_text(json.dumps(dict(status='PASS',byteIdentical=receipt),indent=2)+'\n')
