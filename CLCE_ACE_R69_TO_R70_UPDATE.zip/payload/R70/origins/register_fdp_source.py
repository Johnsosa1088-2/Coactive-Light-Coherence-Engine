"""Replay the archived FDP family guide and identify the same ulnar face in the working skeleton."""
import csv
import hashlib
import json
import sys
from pathlib import Path
from zipfile import ZipFile
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from scipy.optimize import linear_sum_assignment
from scipy.spatial.distance import cdist

def build(root):
    pins={}
    def file(name):
        path=root/name
        pins[name]=hashlib.sha256(path.read_bytes()).hexdigest()
        return path
    def data(name):return json.loads(file(name).read_bytes())
    original='R70/origins/CONNECT216_original_skeleton.obj'
    with ZipFile(file('R70/origins/CONNECT387_Forearm_Muscle_Architecture.zip')) as z:
        assembly=json.loads(z.read('CONNECT387_forearm_architecture_guides.json'))
    record=next(r for r in assembly['families'] if r['id']=='FARM387-06-positive_x')
    lines=file(original).read_text().splitlines()
    assert pins[original]==assembly['source_obj_sha256']
    v=np.array([[float(x) for x in l.split()[1:4]] for l in lines if l.startswith('v ')])
    f=np.array([[int(x.split('/')[0])-1 for x in l.split()[1:4]] for l in lines if l.startswith('f ')])
    row=np.r_[f[:,0],f[:,1],f[:,2]]
    col=np.r_[f[:,1],f[:,2],f[:,0]]
    graph=coo_matrix((np.ones(len(row),dtype=bool),(row,col)),shape=(len(v),len(v))).tocsr()
    _,labels=connected_components(graph,directed=False)
    reg=list(csv.DictReader(file('reference/whole_skeleton_registry.csv').open()))
    arm=data('R63/geometry/R63_ARM_BINDING.json')
    matrix=np.array(arm['registration']['nativeToPresentationCM']); rotation=matrix[:3,:3]; origin=matrix[:3,3]
    meshes={}
    mappings=[]
    for historical,current in [('SRC-C066','ulna'),('SRC-C067','radius')]:
        r=next(row for row in reg if row['source_component']==historical)
        bounds=np.r_[json.loads(r['bbox_min']),json.loads(r['bbox_max'])]
        matches=[]
        for component in np.unique(labels[f[:,0]]):
            face_ids=np.flatnonzero(labels[f[:,0]]==component)
            if len(face_ids)!=int(r['source_triangles']):continue
            verts=np.unique(f[face_ids])
            pts=v[verts]
            if np.allclose(np.r_[pts.min(0),pts.max(0)],bounds,atol=1e-6,rtol=0):
                matches.append((pts,np.searchsorted(verts,f[face_ids]),verts,face_ids))
        assert len(matches)==1
        src,tri,src_vids,src_face=matches[0]
        part=next(x for x in arm['parts'] if x['name']==current)
        now_world=np.array(part['vertices']); now=(now_world-origin)@np.linalg.inv(rotation).T
        center=np.median(now,axis=0)-np.median(src,axis=0)
        i,j=linear_sum_assignment(cdist(src+center,now))
        assert np.array_equal(i,np.arange(len(src))) and len(set(j))==len(src)==len(now)
        by_face={tuple(sorted(t)):k for k,t in enumerate(part['faces'])}
        mapped=[by_face[tuple(sorted(t))] for t in j[tri]]
        assert len(set(mapped))==len(tri)==len(part['faces'])
        meshes[current]=(src,tri,src_vids,src_face,now_world,j,mapped)
        mappings.append(now[j]-src)
    shifts=np.vstack(mappings);shift=np.median(shifts,axis=0)
    place=lambda x:(x+shift)@rotation.T+origin
    residual=10*np.linalg.norm((shifts-shift)@rotation.T,axis=1)
    ulna,tri,global_ids,global_faces,world,j,face_map=meshes['ulna'];radius=meshes['radius'][0]
    def quantile_center(points,q,high):
        cutoff=np.quantile(points[:,1],q)
        return points[(points[:,1]>=cutoff) if high else (points[:,1]<=cutoff)].mean(0)
    drift=np.array([0.,0.,(5-9)*.007])
    start=quantile_center(ulna,.85,True)+drift
    end=(quantile_center(ulna,.15,False)+quantile_center(radius,.15,False))*.5+drift
    nearest=np.linalg.norm(ulna-start,axis=1).argmin()
    choices=np.flatnonzero(np.any(tri==nearest,axis=1))
    fid=choices[np.linalg.norm(ulna[tri[choices]].mean(1)-ulna[nearest],axis=1).argmin()]
    assert record['nearby_source_face_address']==f'SRC-C066:FACE:{fid:05d}'
    assert np.allclose(start,record['guide_origin_xyz'],rtol=0,atol=1e-8)
    assert np.allclose(end,record['guide_handoff_xyz'],rtol=0,atol=1e-8)
    dots=[]
    for dot in record['dots']:
        t=dot['station']/16
        p=start*(1-t)+end*t+np.array([(.012*(dot['lane']-1))*np.sin(np.pi*t),0.,0.])
        assert np.max(np.abs(p-dot['xyz']))<1.01e-8
        dots.append(place(np.array(dot['xyz'])).tolist())
    face=world[j[tri[fid]]]
    return dict(status='REGISTERED_SOURCE_GUIDE_AND_ULNAR_FACE',sourceSHA256=pins,sourceID=record['id'],sourceOBJHash=assembly['source_obj_sha256'],
            sourceLimit=record['status'],sourceOriginFormula='A centroid of proximal ulna vertices plus the archived diagram-offset value. The named face is a nearby witness.',
            matchedForearmVertices=len(shifts),matchedForearmTriangles=sum(len(q[1]) for q in meshes.values()),reconstructedDots=len(dots),
            forearmTranslationNative=shift.tolist(),medianResidualMM=float(np.median(residual)),maxResidualMM=float(residual.max()),
            sourceFaceAddress=record['nearby_source_face_address'],currentUlnaComponent=55,currentUlnaFace0=int(face_map[fid]),
            nearestSourceVertex0=int(nearest),matchingWorkingVertex0=int(j[nearest]),ulnaWitnessCM=world[j[nearest]].tolist(),
            ulnaFaceCM=face.tolist(),guideOriginCM=dots[1],guideHandoffCM=dots[-2],siteDotsCM=dots,centerlineCM=dots[1::3],
            sourceStations=17,sourceLanes=3,originalFaceGlobal0=int(global_faces[fid]),originalVertexGlobal0=int(global_ids[nearest]),
            scope='Corresponding bone triangle and original guide semantics are recovered. Anatomical insertion area, muscle contour and material mechanics are unmeasured.')
if __name__=='__main__':
    root,out=map(Path,sys.argv[1:])
    out.write_text(json.dumps(build(root),indent=2)+'\n')
