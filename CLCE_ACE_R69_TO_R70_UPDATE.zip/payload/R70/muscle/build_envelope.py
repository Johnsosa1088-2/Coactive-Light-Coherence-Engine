"""Register the original shared FDP and index tracks, then reconstruct the R70 working envelope."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
from scipy.interpolate import CubicSpline

from working_surface import build_surface


GOLD = 'R69/qa/R69_GOLD_FOREARM.json'
ARM = 'R63/geometry/R63_ARM_BINDING.json'
PATCH = 'R69/routes/R69_INDEX_PROXIMAL.json'
RESPONSE = 'R69/attachment/R69_PATCH_RESPONSE.json'
ORIGIN = 'R70/origins/R70_FDP_SOURCE_REGISTRATION.json'
FIT = [.7386544519803169, -.1798508816440413, 1.3165355116624153,
       .33180256763179905, .44030293350645533, .8402659061985994]


def unit(vector):
    return vector/np.linalg.norm(vector)


def midpoint_section_center(part, center, axis):
    """Average the unique edge intersections with the physical forearm midshaft plane."""
    tri = part.v[part.f]
    signs = (tri-center) @ axis
    points = []
    for a,b in ((0,1),(1,2),(2,0)):
        ids = np.flatnonzero(signs[:,a]*signs[:,b] < 0)
        t = signs[ids,a]/(signs[ids,a]-signs[ids,b])
        points.extend(tri[ids,a] + t[:,None]*(tri[ids,b]-tri[ids,a]))
    return np.unique(np.round(points,9), axis=0).mean(0)


def source_frame(arm, bones):
    elbow, wrist = [np.asarray(arm['landmarks'][k+'CM']) for k in ('elbow','wrist')]
    length = np.linalg.norm(wrist-elbow)
    axis = (wrist-elbow)/length
    rc, uc = [midpoint_section_center(bones[k], (elbow+wrist)/2, axis) for k in ('radius','ulna')]
    ulnar = unit((uc-rc) - np.dot(uc-rc,axis)*axis)
    forward = np.cross(axis,ulnar)
    # BASE.boneLength is 1.33. boneFrame's normalized elbow-to-wrist distance is .68*1.33.
    matrix = np.eye(4)
    matrix[:3,:3] = length/.9044*np.column_stack([forward,-axis,-ulnar])
    matrix[:3,3] = wrist-matrix[:3,:3]@np.array([0,.30,0])
    metadata = dict(elbowCM=elbow.tolist(),wristCM=wrist.tolist(),chordLengthMM=float(10*length),
                    radiusMidshaftSectionMeanCM=rc.tolist(),ulnaMidshaftSectionMeanCM=uc.tolist(),
                    localNormalizedElbow=[0,1.2044,0],localNormalizedWrist=[0,.3,0],
                    rollAssumption='Local minus-Z points from radius to ulna in the plane perpendicular to the R63 elbow-to-wrist axis at midshaft. This fixes a working roll convention.',
                    scaleAssumption='Uniform scaling aligns the two R63 endpoint landmarks. Original source stations use the nearest of 40 samples in the archived workbench.')
    return matrix, metadata


def fit_origin(arch, ulna, source_muscle, transverse, depth):
    """Replay the frozen clearance fit, respecting the exact source-addressed exit and working entry."""
    witness = np.asarray(arch['ulnaWitnessCM'])
    index = arch['matchingWorkingVertex0']
    assert np.allclose(ulna.v[index],witness,atol=1e-10,rtol=0)
    incident = ulna.f[np.any(ulna.f==index,axis=1)]
    normal = unit(np.cross(ulna.v[incident[:,1]]-ulna.v[incident[:,0]],
                           ulna.v[incident[:,2]]-ulna.v[incident[:,0]]).sum(0))
    if abs(ulna.winding([witness+.01*normal])[0]) > .5:
        normal *= -1
    start, distal = source_muscle[[0,-1]]
    knots = np.array([witness, witness+.45*normal, witness+(start-witness)*.20,
                      witness+(start-witness)*.45, witness+(start-witness)*.70,
                      start-(distal-start)*.05, start])
    for i,(x,y) in enumerate(np.asarray(FIT).reshape(-1,2)):
        knots[2+i] += x*transverse+y*depth
    t = [0,.09,.25,.48,.71,.88,1]
    spline = CubicSpline(t, knots, bc_type=((1,5*normal),(1,(distal-start)*.33)))
    points = spline(np.linspace(0,1,101))
    points[[0,-1]] = [witness,start]
    return dict(pointsCM=points.tolist(),sourceFace0=arch['currentUlnaFace0'],
                sourceFaceAddress=arch['sourceFaceAddress'],sourceUlnaVertex0=int(index),
                sourceUlnaComponent=arch['currentUlnaComponent'],workingPoleVertex0=0,
                directChordCM=[witness.tolist(),start.tolist()],
                fitKnotParameters=t,fitKnotsCM=knots.tolist(),exteriorIncidentNormal=normal.tolist(),
                fittedTransverseKnotOffsetsCM=FIT,
                method='Clamped cubic spline sampled at 101 values. Three interior knot pairs were fitted with SLSQP from a transverse seed of [1.3,0,1.7,0,1.3,0] cm. The fit balances length and second differences with 73 skin/bone clearance stations. Check the resulting full segments against the triangles.',
                scope='One-dimensional working guide from an archived nearby ulnar face witness to the proximal surface pole. Its path is fitted; attachment area, tissue identity and force transfer at the witness are unmeasured.')


def condensed_audit(surface, points):
    audit = surface.audit(points)
    return {k:audit[k] for k in ['routeLengthMM','minGapMM','insideLengthMM','outsideLengthMM',
                                  'surfaceCrossingDistancesMM','endpointGapsMM']}


def build(root):
    sys.path.insert(0,str(root/'R67/qa'))
    from hand_model import HandModel
    from segment_geometry import TriangleSurface
    def read(path):
        return json.loads((root/path).read_bytes())
    gold,arm,route,response,arch = map(read,(GOLD,ARM,PATCH,RESPONSE,ORIGIN))
    skin,bones = HandModel(root).pose(0,0)
    matrix,frame = source_frame(arm,bones)
    lines = {k:np.asarray(v['neutralPointsLocal'])@matrix[:3,:3].T+matrix[:3,3]
             for k,v in gold['lines'].items()}
    patch = np.asarray(route['patches']['working']['nodesCM'])
    center = patch[0]
    transverse,depth = unit(patch[2]-center), unit(patch[3]-center)
    proximal = unit(np.cross(transverse,depth))
    elbow,wrist = np.asarray(frame['elbowCM']),np.asarray(frame['wristCM'])
    if np.dot(proximal,elbow-wrist) < 0:
        proximal *= -1
    working = build_surface(lines['muscle'],lines['tendon'],patch,transverse,depth,proximal)
    guide = fit_origin(arch,bones['ulna'],lines['muscle'],transverse,depth)
    shell = TriangleSurface(working['verticesCM'],working['faces'])
    surfaces = {'skin':skin,**{k:bones[k] for k in ('radius','ulna','humerus')}}
    comparisons = {}
    for name,path in [('goldMuscle',lines['muscle']),('goldIndexTendon',lines['tendon']),
                      ('connect387Diagram',arch['centerlineCM']),('originDirectChord',guide['directChordCM']),
                      ('originFittedPolyline',guide['pointsCM'])]:
        comparisons[name] = {k:condensed_audit(s,path) for k,s in surfaces.items()}
    comparisons['originFittedPolyline']['workingEnvelope'] = condensed_audit(shell,guide['pointsCM'])
    working['patchOperator'] = dict(source=RESPONSE,axisCM=response['axisCM'],offsetsMM=response['offsetsMM'],
                                    nodeIDs=response['nodeIDs'],
                                    formula='restCM + (thicknessScale - 1) * thicknessDeltaCM + editWeights[node] * offsetMM / 10 * axisCM, before the common forearm transform')
    working['authoredDimensions'] = dict(maxTransverseSemiaxisMM=3.5,maxDepthSemiaxisMM=2.4,
             taperSinPower=.62,trunkIntervals=40,sectors=32,outletRings=25,
             distalTrunkBiasMM=2.2,distalTrunkSmoothStepRange=[.72,.94],
             outletControlExtentFractions=[.26,.27],outletMidDepthBiasMM=-1.3,
             reason='The distal trunk bias clears the existing index tendon. The branch leaves the shared body at the longitudinal station nearest the original index start and is routed to the R69 patch. These are working fit choices.')
    files = [GOLD,ARM,PATCH,RESPONSE,ORIGIN,'R56/models/R56_WORKING_EXTERIOR.obj',
             'R65/geometry/R65_WRIST_FIT.json','R65/hand/R65_WRIST_HAND.json','R66/geometry/R66_HAND_SURFACE.json',
             'R66/geometry/R66_HAND_JOIN.json','R66/motion/R66_DIGIT_MOTION.json','R66/motion/R66_DIGIT_WEIGHTS.json']
    hashes = {p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files}
    for path,expected in gold['sourceSHA256'].items():
        digest = hashlib.sha256((root/path).read_bytes()).hexdigest()
        assert digest == expected
        hashes[path] = digest
    return dict(schema='ACE.R70.FDP.envelope.v1',side='positive_X',units='cm',sourceSHA256=hashes,
                source=dict(muscleCM=lines['muscle'].tolist(),tendonCM=lines['tendon'].tolist(),
                            matrixLocalToCM=matrix.tolist(),frame=frame,
                            muscleID=gold['lines']['muscle']['id'],tendonID=gold['lines']['tendon']['id'],
                            muscleStationRange=gold['lines']['muscle']['stationRange'],
                            tendonStationRange=gold['lines']['tendon']['stationRange'],
                            architecturePacket=ORIGIN,architectureID=arch['sourceID']),
                working=working,originGuide=guide,
                measurements=dict(rawMuscleEndToR69CenterMM=float(np.linalg.norm(lines['muscle'][-1]-center)*10),
                                  R69CenterFractionElbowToWrist=float((center-elbow)@(wrist-elbow)/np.sum((wrist-elbow)**2)),
                                  neutralPolylineAudits=comparisons),
                scope='The separately archived shared FDP, index track and ulnar face address constrain a derived muscle envelope and a one-dimensional origin guide. The middle, ring and little finger outlets, an anatomical enthesis, material behavior, muscle force, and exterior skin deformation by this volume are outside this working study.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', nargs='?', type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument('output', nargs='?',type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    out = args.output or root/'R70/muscle/R70_FDP_ENVELOPE.json'
    out.write_text(json.dumps(build(root),separators=(',',':'),allow_nan=False)+'\n',encoding='utf-8')
