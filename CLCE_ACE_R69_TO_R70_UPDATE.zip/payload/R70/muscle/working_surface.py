"""Construct the closed shared forearm spindle and its continuous lateral index outlet."""
from collections import defaultdict
import numpy as np


def orient_outward(vertices, faces):
    incidence = defaultdict(list)
    for i, face in enumerate(faces):
        for a, b in zip(face, np.roll(face, -1)):
            incidence[tuple(sorted((a, b)))].append((i, 1 if a < b else -1))
    neighbors = [[] for _ in faces]
    for edge, adjacent in incidence.items():
        if len(adjacent) != 2:
            raise ValueError(f"Non-manifold edge {edge}")
        (i, a), (j, b) = adjacent
        neighbors[i].append((j, -a*b))
        neighbors[j].append((i, -a*b))
    orientation = {0: 1}
    pending = [0]
    while pending:
        i = pending.pop()
        for j, sign in neighbors[i]:
            wanted = orientation[i]*sign
            if j in orientation and orientation[j] != wanted:
                raise ValueError("Surface is not orientable")
            if j not in orientation:
                orientation[j] = wanted
                pending.append(j)
    if len(orientation) != len(faces):
        raise ValueError("Outlet and trunk must form a single component")
    faces = np.array([f if orientation[i] == 1 else f[::-1] for i, f in enumerate(faces)])
    tri = vertices[faces]
    six_volume = np.einsum('ij,ij->i', tri[:, 0]-vertices.mean(0),
                           np.cross(tri[:, 1]-tri[:, 0], tri[:, 2]-tri[:, 0])).sum()
    return faces if six_volume > 0 else faces[:, ::-1]


def build_surface(muscle, tendon, patch, transverse, depth, proximal):
    """Author a closed working envelope. Source drawing widths do not set these radii."""
    sectors, intervals = 32, 40
    stations = np.linspace(0, 1, intervals+1)
    centers = muscle[0] + stations[:, None]*(muscle[-1]-muscle[0])
    # The unshifted terminal tip intercepts the independently fitted R69 index lead.
    ramp = np.clip((stations-.72)/.22, 0, 1)
    centers += .22*(ramp*ramp*(3-2*ramp))[:, None]*transverse
    positions, width_delta, patch_weights, faces = [], [], [], []

    def add_vertex(point, width=None, weights=None):
        positions.append(point)
        width_delta.append(np.zeros(3) if width is None else width)
        patch_weights.append(np.zeros(5) if weights is None else weights)
        return len(positions)-1

    def connect(previous, current):
        for j, a in enumerate(previous):
            k = (j+1) % len(previous)
            faces.extend([(a, previous[k], current[k]), (a, current[k], current[j])])

    rings = []
    for i, (center, station) in enumerate(zip(centers, stations)):
        if i in (0, intervals):
            rings.append([add_vertex(center)])
            continue
        profile = np.sin(np.pi*station)**.62
        ring = []
        for angle in np.linspace(0, 2*np.pi, sectors, endpoint=False):
            offset = (.35*np.cos(angle)*transverse + .24*np.sin(angle)*depth)*profile
            ring.append(add_vertex(center+offset, offset))
        rings.append(ring)

    # Select the station from the axial height of the first original index-tendon sample.
    mid = int(np.argmin(abs((centers-tendon[0]) @ proximal)))
    low, high, half_width = mid-1, mid+1, 2

    def at(row, column):
        return rings[row][column % sectors]

    for i in range(intervals):
        for j in range(sectors):
            k = (j+1) % sectors
            if i == 0:
                faces.append((rings[0][0], at(1, k), at(1, j)))
            elif i == intervals-1:
                faces.append((rings[-1][0], at(i, j), at(i, k)))
            elif not (low <= i < high and (j < half_width or j >= sectors-half_width)):
                faces.extend([(at(i,j), at(i,k), at(i+1,k)), (at(i,j), at(i+1,k), at(i+1,j))])

    rim_indices = ([(low,k) for k in range(-half_width,half_width+1)] + [(mid,half_width)] +
                   [(high,k) for k in range(half_width,-half_width-1,-1)] + [(mid,-half_width)])
    rim = [at(i,j) for i,j in rim_indices]
    rim_xyz = np.asarray(positions)[rim]
    rim_width = np.asarray(width_delta)[rim]
    origin = rim_xyz.mean(0)
    end = patch[0]
    distance = np.linalg.norm(end-origin)
    first_control = origin + .26*distance*transverse
    last_control = end + .27*distance*proximal

    # Map the hole's rectangular perimeter to the R69 diamond, retaining its four exact corners.
    bary = []
    for row, sector in rim_indices:
        x, y = mid-row, sector/half_width
        weight = np.zeros(5)
        weight[2 if x>0 else 1] = abs(x)/(abs(x)+abs(y))
        weight[3 if y>0 else 4] = abs(y)/(abs(x)+abs(y))
        bary.append(weight)
    bary = np.asarray(bary)
    destination = bary @ patch
    relative = rim_xyz-origin
    scale_u, scale_v, scale_a = relative@proximal, relative@depth, relative@transverse
    dest_u, dest_v = (destination-end)@transverse, (destination-end)@depth
    outlet_centers, outlet_rings = [], []
    previous = rim
    for row, u in enumerate(np.linspace(0, 1, 25)):
        center = ((1-u)**3*origin + 3*(1-u)**2*u*first_control +
                  3*(1-u)*u**2*last_control + u**3*end)
        center += -.13*np.sin(np.pi*u)**2*depth
        outlet_centers.append(center)
        if row == 0:
            outlet_rings.append(rim)
            continue
        blend = u*u*(3-2*u)
        angle = .5*np.pi*blend
        u_basis = np.cos(angle)*proximal + np.sin(angle)*transverse
        a_basis = np.cos(angle)*transverse - np.sin(angle)*proximal
        u_span = scale_u*(1-blend) + dest_u*blend
        v_span = scale_v*(1-blend) + dest_v*blend
        ring = []
        for j, weights in enumerate(bary):
            point = center + u_span[j]*u_basis + v_span[j]*depth + scale_a[j]*(1-blend)*a_basis
            ring.append(add_vertex(point, (1-blend)*rim_width[j], blend*weights))
        connect(previous, ring)
        previous = ring
        outlet_rings.append(ring)

    patch_ids = [None]*5
    patch_ids[0] = add_vertex(end, weights=np.eye(5)[0])
    for j, weights in enumerate(bary):
        if np.max(weights) > .99999:
            patch_ids[int(np.argmax(weights))] = previous[j]
        faces.append((previous[j], previous[(j+1)%len(previous)], patch_ids[0]))

    faces = np.asarray(faces)
    used = np.unique(faces)
    remap = np.full(len(positions), -1)
    remap[used] = np.arange(len(used))
    vertices = np.asarray(positions)[used]
    width = np.asarray(width_delta)[used]
    weights = np.asarray(patch_weights)[used]
    shared_ids = remap[patch_ids]
    vertices[shared_ids] = patch
    faces = orient_outward(vertices, remap[faces])
    return dict(verticesCM=vertices.tolist(), thicknessDeltaCM=width.tolist(),
                editWeights=weights.tolist(), faces=faces.tolist(), patchVertexIDs0=shared_ids.tolist(),
                centerlineCM=centers.tolist(), outletCenterlineCM=np.asarray(outlet_centers).tolist(),
                thicknessStops=[.8,1.,1.2], rings=[remap[r].tolist() for r in rings],
                outletRings=[remap[r].tolist() for r in outlet_rings])
