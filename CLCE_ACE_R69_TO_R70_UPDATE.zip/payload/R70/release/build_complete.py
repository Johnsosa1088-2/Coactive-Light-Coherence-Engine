"""Build a normal DEFLATE ZIP with independent member-by-member verification.

With --cache, member streams may be prepared from an earlier checkpoint using
--prepare. Every stream is verified against original bytes before publication.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import ctypes
import ctypes.util
import hashlib
import json
import os
from pathlib import Path
import stat
import struct
import tempfile
import zipfile
import zlib

def sha(data):
    return hashlib.sha256(data).hexdigest()

def compressor():
    library=ctypes.util.find_library('deflate')
    if not library:
        def compress(data):
            obj=zlib.compressobj(9,zlib.DEFLATED,-15)
            return obj.compress(data)+obj.flush()
        return compress
    lib=ctypes.CDLL(library)
    ptr,size=ctypes.c_void_p,ctypes.c_size_t
    alloc=lib.libdeflate_alloc_compressor
    alloc.argtypes=[ctypes.c_int];alloc.restype=ptr
    bound=lib.libdeflate_deflate_compress_bound
    bound.argtypes=[ptr,size];bound.restype=size
    run=lib.libdeflate_deflate_compress
    run.argtypes=[ptr,ptr,size,ptr,size];run.restype=size
    free=lib.libdeflate_free_compressor
    free.argtypes=[ptr];free.restype=None
    def compress(data):
        handle=alloc(10)
        if not handle:raise MemoryError('Could not allocate DEFLATE compressor')
        try:
            room=bound(handle,len(data))
            output=ctypes.create_string_buffer(room)
            n=run(handle,data,len(data),output,room)
            if n==0:raise ValueError('DEFLATE returned no stream')
            return output.raw[:n]
        finally:
            free(handle)
    return compress

def pack(root,out,cache,prepare):
    tag=root.name.rsplit('_',1)[-1]
    index=root/(tag+'_FILE_SHA256.json')
    hashes=json.loads(index.read_bytes())['sha256']
    hashes[index.name]=sha(index.read_bytes())
    cache.mkdir(parents=True,exist_ok=True)
    unique={h:rel for rel,h in hashes.items()}
    compress=compressor()
    def one(item):
        h,rel=item
        key=cache/(h+'.deflate')
        if key.exists():return
        raw=(root/rel).read_bytes()
        if sha(raw)!=h:raise ValueError('Source checksum mismatch for '+rel)
        enc=compress(raw)
        partial=key.with_suffix('.part')
        partial.write_bytes(enc)
        os.replace(partial,key)
    with ThreadPoolExecutor(max_workers=4) as pool:
        for _ in pool.map(one, unique.items()):pass
    if prepare:
        print(json.dumps(dict(cachedMembers=len(unique),compressedBytes=sum((cache/(v+'.deflate')).stat().st_size for v in hashes.values()))))
        return
    if out is None or out.exists():raise ValueError('A fresh output path is required')
    temp=out.with_suffix('.partial')
    records=[]
    with temp.open('wb') as stream:
        for rel,h in sorted(hashes.items()):
            data=(root/rel).read_bytes()
            packed=(cache/(h+'.deflate')).read_bytes()
            if sha(data)!=h or zlib.decompress(packed,-15)!=data:
                raise ValueError('Member validation failed for '+rel)
            name=(root.name+'/'+rel).encode('utf-8')
            offset=stream.tell()
            # All names use UTF-8. Fixed DOS date Jan 1, 1980. Standard method 8.
            args=(20,0x800,8,0,33,zlib.crc32(data),len(packed),len(data),len(name),0)
            stream.write(struct.pack('<I5H3I2H',0x04034b50,*args))
            stream.write(name);stream.write(packed)
            rec=struct.pack('<I6H3I5H2I',0x02014b50,(3<<8)|20,*args,0,0,0,(stat.S_IFREG|0o644)<<16,offset)+name
            records.append(rec)
        start=stream.tell()
        for rec in records:stream.write(rec)
        length=stream.tell()-start
        stream.write(struct.pack('<I4H2IH',0x06054b50,0,0,len(records),len(records),length,start,0))
    with zipfile.ZipFile(temp) as check:
        assert len(check.namelist())==len(set(check.namelist()))==len(hashes)
        for rel,h in hashes.items():
            if sha(check.read(root.name+'/'+rel))!=h:raise ValueError(rel)
    os.replace(temp,out)
    with out.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
    print(json.dumps(dict(status='PASS',files=len(hashes),fullArchiveBytes=out.stat().st_size,sha256=digest,
                         sourceMemberSHA256AndCRCsChecked=True,format='Standard single-root DEFLATE ZIP')))
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('root',type=Path);p.add_argument('output',nargs='?',type=Path)
    p.add_argument('--prepare',action='store_true');p.add_argument('--cache',type=Path)
    opt=p.parse_args()
    if opt.cache:pack(opt.root,opt.output,opt.cache,opt.prepare)
    else:
        with tempfile.TemporaryDirectory() as folder:pack(opt.root,opt.output,Path(folder),opt.prepare)
