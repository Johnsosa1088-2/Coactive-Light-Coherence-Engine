"""Verify source provenance, continuity, audits and integration before indexing this release."""
import hashlib
import json
import sys
from pathlib import Path

def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def freeze(root):
    parent_index='R69_FILE_SHA256.json'
    parent_sha='a409fa5e0926cd6ff626d3a25ea60652b7c9039c699b4a31ad9a23a5b1c0c644'
    index='R70_FILE_SHA256.json'
    root_files={index,'manifest_R70.json','R70_VERIFICATION.json','README_R70.md','START_HERE_R70.txt'}
    def read(path):return json.loads((root/path).read_bytes())
    def write(path,data):(root/path).write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
    def check(path,h):
        if sha(root/path)!=h:raise ValueError('Checksum mismatch for '+str(path))
    check(parent_index,parent_sha)
    inherited=dict(read(parent_index)['sha256']);inherited[parent_index]=parent_sha
    assert len(inherited)==1951
    relocated={name:'R70/previous/'+name for name in ('ACE_WORKBENCH.html','ACE_WORKBENCH.cmd')}
    for name,h in inherited.items():check(relocated.get(name,name),h)
    for p in root.rglob('*'):
        if p.is_file():
            n=p.relative_to(root).as_posix()
            assert n in inherited or n.startswith('R70/') or n in root_files,n
            if n.startswith('R70/'):assert '__pycache__' not in n and not n.endswith(('.pyc','.blend1','.log','.partial')),n
    registration='R70/origins/R70_FDP_SOURCE_REGISTRATION.json'
    packet='R70/muscle/R70_FDP_ENVELOPE.json'
    study='R70/ui/Flexor_belly.html'
    blender='R70/rig/Aurelia_R70_Deep_Flexor.blend'
    parent_blender='R69/rig/Aurelia_R69_Index_Handoff.blend'
    qa=lambda key:'R70/qa/R70_'+key+'.json'
    keys=['BELLY_GEOMETRY','BELLY_ARM','BLENDER_CHECK','STUDIO_CHECK','BROWSER_CHECK','REBUILD','LAUNCHER_CHECK']
    geom,arm,rig,ui,browser,rebuild,launcher=[read(qa(key)) for key in keys]
    assert all(q['status']=='PASS' for q in [geom,arm,rig,ui,browser,rebuild,launcher])
    reg=read(registration)
    assert reg['currentUlnaFace0']==833 and reg['matchingWorkingVertex0']==418 and reg['reconstructedDots']==51
    assert reg['matchedForearmVertices']==832 and reg['matchedForearmTriangles']==1656
    p=read(packet)
    for group in [p['sourceSHA256'],reg['sourceSHA256'],geom['sourceSHA256'],arm['sourceSHA256'],rebuild['byteIdentical']]:
        for name,h in group.items():check(name,h)
    for h in [geom['muscleSHA256'],arm['packetSHA256'],rig['muscleSHA256'],ui['inputSHA256']['envelope']]:check(packet,h)
    for h in [arm['neutralAuditSHA256'],ui['inputSHA256']['audit']]:check(qa('BELLY_GEOMETRY'),h)
    check(registration,ui['inputSHA256']['namedSite']);check('R69/ui/Forearm_handoff.html',ui['inputSHA256']['parent'])
    for h in [ui['htmlSHA256'],browser['htmlSHA256'],launcher['actualLoopbackBellyPageSHA256']]:check(study,h)
    check(blender,rig['blendSHA256']);check(parent_blender,rig['parentSHA256'])
    assert geom['summary']['localConfigurations']==33 and not geom['issues'] and geom['topology']['components']==1
    assert geom['summary']['maxLeadReentryMM']<1e-7 and geom['summary']['maxOriginGuideReentryMM']<1e-7
    assert arm['summary']['combinations']==2200 and min(arm['summary']['minOverallShellSkinBoundMM'],arm['summary']['minOverallShellBoneBoundMM'])>0
    assert rig['allInheritedPositionsExactlyEqual'] and rig['settings']==387 and rig['maximumCapToR69PatchGapMM']==0
    assert ui['independentClearanceReceiptEmbedded'] and ui['armWristIndexPoses']==340 and browser['loadFinished'] and browser['narrow']['width']==390
    assert launcher['offlineRoutesChecked']==20
    write('R70_VERIFICATION.json',dict(checkpoint='M05C-R70',parent='M05C-R69',parentIndexSHA256=parent_sha,
        inheritedFiles=len(inherited),relocatedPriorEntries=relocated,sourceRegistration=registration,model=packet,
        study=study,editableFigure=blender,reports={qa(key):sha(root/qa(key)) for key in keys},
        scope='A source-registered ulnar witness, authored one-dimensional origin guide and closed adjustable FDP muscle with an index outlet. Physics, other digital outlets and a measured anatomical attachment footprint remain open.'))
    write('manifest_R70.json',dict(checkpoint='M05C-R70',parent='M05C-R69',title='Gentle 125 | Working deep finger flexor',entrypoint='ACE_WORKBENCH.html',
        launcher='ACE_WORKBENCH.cmd',belly=study,figure=blender,guide='README_R70.md',start='START_HERE_R70.txt'))
    hashes={p.relative_to(root).as_posix():sha(p) for p in sorted(root.rglob('*')) if p.is_file() and p!=root/index}
    write(index,dict(schema='CLCE_ACE_R70_FILE_SHA256_V1',archiveRoot=root.name,selfExcluded=index,fileCount=len(hashes),sha256=hashes))
    print(f'Frozen {len(hashes)+1} files; {len(inherited)} inherited files verified.')
if __name__=='__main__':freeze(Path(sys.argv[1]))
