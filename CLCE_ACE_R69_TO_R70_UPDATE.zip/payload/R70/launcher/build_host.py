"""Add the deep flexor muscle workbench to the existing offline host and Windows launcher."""
from pathlib import Path
import sys
root=Path(sys.argv[1]);previous=root/'R70/previous'
host=(previous/'ACE_WORKBENCH.html').read_bytes()
anchor=b'<a href="R69/ui/Forearm_handoff.html"'
assert host.count(anchor)==1
route=b'<script>if(location.hash==="#belly")location.replace("R70/ui/Flexor_belly.html")</script>'
link=b'<a href="R70/ui/Flexor_belly.html" style="color:var(--gold);font-weight:600;padding:10px">Deep finger flexor</a>'
(root/'ACE_WORKBENCH.html').write_bytes(host.replace(anchor,route+link+anchor))
cmd=(previous/'ACE_WORKBENCH.cmd').read_bytes()
cmd=cmd.replace(b'R69\\launcher',b'R70\\launcher')
test=b'if /i "%~1"=="handoff" goto handoff'
assert cmd.count(test)==1
cmd=cmd.replace(test,b'if /i "%~1"=="belly" goto belly\r\n'+test)
entry=b'\r\n:handoff\r\n'
assert cmd.count(entry)==1
cmd=cmd.replace(entry,b'\r\n:belly\r\nstart "" "%~dp0R70\\ui\\Flexor_belly.html"\r\nexit /b 0'+entry)
(root/'ACE_WORKBENCH.cmd').write_bytes(cmd)
