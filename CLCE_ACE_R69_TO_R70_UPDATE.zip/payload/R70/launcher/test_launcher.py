"""Check R70 routes and the file served by the actual local launcher."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import atexit
import subprocess
import sys
from unittest.mock import patch
from urllib.request import urlopen

def test(root):
    module = root/'R70/launcher/ace_workbench.py'
    spec=importlib.util.spec_from_file_location('ace_workbench',module)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    urls=[]
    for view in mod.VIEWS:
        with patch.object(sys,'argv',['ace_workbench.py',view,'--root',str(root)]),patch.object(mod,'ThreadingHTTPServer',side_effect=OSError()),patch.object(mod.webbrowser,'open',side_effect=urls.append):
            assert mod.main()==0
        paths={'belly':'R70/ui/Flexor_belly.html','handoff':'R69/ui/Forearm_handoff.html','fingers':'R68/ui/Finger_flexors.html','flexor':'R67/ui/Index_flexor.html','hand':'R66/ui/Hand_study.html','wrist':'R65/ui/Wrist_study.html','tissue':'R64/ui/Arm_tissue.html','elbow':'R63/ui/Elbow_study.html','jaw':'R62/ui/Mouth_alignment.html','mouth':'R62/ui/Mouth_alignment.html'}
        expected=(root/paths[view]).as_uri() if view in paths else (root/'ACE_WORKBENCH.html').as_uri()+'#'+view
        assert urls[-1]==expected
    batch=(root/'ACE_WORKBENCH.cmd').read_bytes()
    assert b'R70\\launcher\\ace_workbench.py' in batch and b'R62\\ui\\Mouth_alignment.html' in batch
    host=(root/'ACE_WORKBENCH.html').read_text(encoding='utf-8')
    assert '<a href="R62/ui/Mouth_alignment.html"' in host and ('R62/ui/Mouth_alignment.html' in host)
    assert 'R63/ui/Elbow_study.html' in host and b'R63\\ui\\Elbow_study.html' in batch
    assert 'R64/ui/Arm_tissue.html' in host and b'R64\\ui\\Arm_tissue.html' in batch
    assert 'R65/ui/Wrist_study.html' in host and b'R65\\ui\\Wrist_study.html' in batch
    assert 'R66/ui/Hand_study.html' in host and b'R66\\ui\\Hand_study.html' in batch
    assert 'R67/ui/Index_flexor.html' in host and b'R67\\ui\\Index_flexor.html' in batch
    assert 'R68/ui/Finger_flexors.html' in host and b'R68\\ui\\Finger_flexors.html' in batch
    assert 'R69/ui/Forearm_handoff.html' in host and b'R69\\ui\\Forearm_handoff.html' in batch
    assert 'R70/ui/Flexor_belly.html' in host and b'R70\\ui\\Flexor_belly.html' in batch
    import os
    proc=subprocess.Popen([sys.executable,'-B',str(module),'belly','--root',str(root)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env=dict(os.environ,BROWSER='true'))
    try:
        msg=proc.stdout.readline()
        assert 'ACE is running' in msg,msg
        url=proc.stdout.readline().strip()
        assert url.startswith('http://127.0.0.1:') and url.endswith('/R70/ui/Flexor_belly.html')
        with urlopen(url,timeout=6) as f:data=f.read()
        assert data==(root/'R70/ui/Flexor_belly.html').read_bytes()
    finally:
        proc.terminate()
        proc.wait(timeout=6)
    return dict(status='PASS',offlineRoutesChecked=len(urls),actualLoopbackBellyPageSHA256=hashlib.sha256(data).hexdigest(),
                batchTextChecked=True,nativeWindowsRunVerified=False)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('root',type=Path);p.add_argument('output',type=Path)
    a=p.parse_args();a.output.write_text(json.dumps(test(a.root.resolve()),indent=2)+'\n')
