"""Use the shared ACE launcher with the R70 deep-flexor muscle study or an existing body view."""
from pathlib import Path
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from functools import partial
import argparse
import hashlib
import json
import sys
import webbrowser

VIEWS=('full-body','belly','handoff','fingers','flexor','hand','wrist','tissue','elbow','jaw','mouth','arm','cuff','exterior','surface','materials','registry','hera','zeus','hieros-gamos')

def check(root):
    index=root/'R70_FILE_SHA256.json'
    hashes=json.loads(index.read_text(encoding='utf-8'))['sha256']
    for name,expected in hashes.items():
        h=hashlib.sha256()
        with (root/name).open('rb') as f:
            for block in iter(lambda:f.read(1<<20),b''):h.update(block)
        if h.hexdigest()!=expected:
            raise ValueError('Checksum mismatch for '+name)
    print('PASS. Verified '+str(len(hashes))+' project files against '+index.name+'.')
    return 0

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('view',choices=VIEWS,default='full-body',nargs='?')
    parser.add_argument('--root',type=Path)
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args()
    root=(args.root or Path(__file__).resolve().parents[2]).resolve()
    if args.check:return check(root)
    standalone={'belly':'R70/ui/Flexor_belly.html','handoff':'R69/ui/Forearm_handoff.html','fingers':'R68/ui/Finger_flexors.html','flexor':'R67/ui/Index_flexor.html','hand':'R66/ui/Hand_study.html','wrist':'R65/ui/Wrist_study.html','tissue':'R64/ui/Arm_tissue.html','jaw':'R62/ui/Mouth_alignment.html','mouth':'R62/ui/Mouth_alignment.html','elbow':'R63/ui/Elbow_study.html'}
    relative=standalone.get(args.view,'ACE_WORKBENCH.html')
    suffix='' if args.view in standalone else '#'+args.view
    if not (root/relative).is_file():parser.error('Could not locate '+relative+' in the extracted project.')
    handler=partial(SimpleHTTPRequestHandler,directory=str(root))
    try: server=ThreadingHTTPServer(('127.0.0.1',0),handler)
    except OSError:
        url=(root/relative).as_uri()+suffix
        webbrowser.open(url)
        print('Opened the offline workbench at '+url)
        return 0
    with server:
        url='http://127.0.0.1:'+str(server.server_port)+'/'+relative+suffix
        print('ACE is running on this computer. Close this window or press Ctrl+C to stop.\n'+url,flush=True)
        webbrowser.open(url)
        try:server.serve_forever()
        except KeyboardInterrupt:pass
    return 0

if __name__=='__main__':
    try:sys.exit(main())
    except (ValueError,OSError) as e:print('ACE: '+str(e),file=sys.stderr);sys.exit(1)
