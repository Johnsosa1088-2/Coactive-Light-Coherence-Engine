"""Extend the R69 blend. Run Blender with PROJECT OUTPUT.blend following --."""
import json
import sys
from pathlib import Path
import bpy
import numpy as np

root,output=map(Path,sys.argv[sys.argv.index('--')+1:])
data=json.loads((root/'R70/muscle/R70_FDP_ENVELOPE.json').read_bytes())
working=data['working']
vertices=np.asarray(working['verticesCM'])
faces=np.asarray(working['faces'])
r69=json.loads((root/'R69/attachment/R69_PATCH_RESPONSE.json').read_bytes())
axis=np.asarray(r69['axisCM'])
edit=np.asarray(working['editWeights'])
radial=np.asarray(working['thicknessDeltaCM'])
scale=np.array([-.01,-.01,.01])
ctrl=bpy.data.objects['Elbow study control']
fore=bpy.data.objects['R63 | positive-X armature']
group=bpy.data.collections.new('12 | Deep finger flexor')
bpy.context.scene.collection.children.link(group)
key='FDP working thickness'
ctrl[key]=1.0
ctrl.id_properties_ui(key).update(min=.8,max=1.2,soft_min=.8,soft_max=1.2,
    description='Authored cross-sectional scale. The distal five-node interface stays registered.')
show='Show working FDP surface'
ctrl[show]=True
ctrl.id_properties_ui(show).update(description='Show the fitted working muscle surface through the figure.')
name='R70 | Working FDP envelope'
mesh=bpy.data.meshes.new(name)
mesh.from_pydata((vertices*scale).tolist(),[],faces.tolist())
mesh.update()
obj=bpy.data.objects.new(name,mesh)
group.objects.link(obj)
obj.show_in_front=True
obj.color=(.79,.25,.29,1.)
mat=bpy.data.materials.new('R70 | Working muscle')
mat.diffuse_color=obj.color
mesh.materials.append(mat)
obj['Evidence']='Source track guided working envelope in the positive-X forearm. Surface width and volume are modeling parameters.'
obj['R69 patch vertex IDs']=working['patchVertexIDs0']
def driver(fc,expr,props):
    d=fc.driver
    d.type='SCRIPTED'
    d.expression=expr
    for variable,prop in props.items():
        v=d.variables.new()
        v.name=variable
        v.type='SINGLE_PROP'
        v.targets[0].id=ctrl
        v.targets[0].data_path='["'+prop+'"]'
for prop in ('hide_render','hide_viewport'):
    driver(obj.driver_add(prop),'not visible',{'visible':show})
obj.shape_key_add(name='Rest')
def shape(name,delta,expr,props):
    k=obj.shape_key_add(name=name)
    k.slider_min=-1.
    k.data.foreach_set('co',np.ascontiguousarray((vertices+delta)*scale,dtype=np.float32).ravel())
    driver(k.driver_add('value'),expr,props)
shape('Working thickness displacement',radial,'max(-0.2,min(0.2,t-1))',{'t':key})
for i in range(5):
    shape('R69 attachment edit '+str(i),edit[:,i,None]*axis*.1,
          'max(-0.5,min(0.5,x)) if n=='+str(i)+' else 0',
          {'x':'Index MTJ node offset (mm)','n':'Index MTJ working node'})
def attach_forearm(mesh_object):
    attachment=mesh_object.vertex_groups.new(name='Forearm | positive X')
    attachment.add(list(range(len(mesh_object.data.vertices))),1.,'REPLACE')
    modifier=mesh_object.modifiers.new('R70 | common forearm parent','ARMATURE')
    modifier.object=fore

attach_forearm(obj)
origin=data['originGuide']
points=np.asarray(origin['pointsCM'])
name='R70 | Ulnar witness to working flexor'
guide_data=bpy.data.meshes.new(name)
guide_data.from_pydata((points*scale).tolist(),[(i,i+1) for i in range(len(points)-1)],[])
guide_data.update()
guide=bpy.data.objects.new(name,guide_data)
group.objects.link(guide)
guide.show_in_front=True
guide.color=(.37,.74,.67,1.)
guide_mat=bpy.data.materials.new('R70 | Authored origin guide')
guide_mat.diffuse_color=guide.color
guide_data.materials.append(guide_mat)
guide['Evidence']='Authored path from an archived ulnar face witness to the working belly. Display thickness is illustrative.'
guide['Ulna vertex (zero based)']=int(origin['sourceUlnaVertex0'])
guide['Ulna face (zero based)']=int(origin['sourceFace0'])
show_guide='Show FDP origin guide'
ctrl[show_guide]=True
ctrl.id_properties_ui(show_guide).update(description='Show the candidate path connecting the named ulnar witness to the proximal belly.')
for prop in ('hide_render','hide_viewport'):
    driver(guide.driver_add(prop),'not visible',{'visible':show_guide})
attach_forearm(guide)
source_tree=bpy.data.objects['R69 | Index proximal lead'].modifiers['R69 | illustrative diameter'].node_group
tree=source_tree.copy()
tree.name='R70 | Origin guide display'
for component in tree.nodes:
    if component.bl_idname=='GeometryNodeSetMaterial':
        component.inputs['Material'].default_value=guide_mat
    elif component.bl_idname=='GeometryNodeCurvePrimitiveCircle':
        component.inputs['Radius'].default_value=.00018
display=guide.modifiers.new('R70 | illustrative diameter','NODES')
display.node_group=tree
notes=bpy.data.texts.new('R70 | Deep flexor controls')
notes.write('Select Elbow study control. FDP working thickness adjusts the authored muscle envelope between 0.8 and 1.2. The R69 Index MTJ working node and Index MTJ node offset (mm) also drive its distal cap. The index tendon lead and digital route keep their existing controls. Show FDP origin guide reveals the authored path from the archived ulnar face witness to the proximal working belly. Its line thickness is illustrative. The geometry study does not measure muscle tension or local skin response.\n')
bpy.context.preferences.filepaths.save_version=0
bpy.context.view_layer.update()
bpy.ops.wm.save_as_mainfile(filepath=str(output.resolve()),compress=True)
