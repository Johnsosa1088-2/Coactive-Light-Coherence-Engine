"""Verify the saved R70 Blender model against registered coordinates and the R69 master."""
import hashlib
import json
import sys
from pathlib import Path

import bpy
import numpy as np

root,out=map(Path,sys.argv[sys.argv.index('--')+1:])
master=Path(bpy.data.filepath)
parent=root/'R69/rig/Aurelia_R69_Index_Handoff.blend'
packet_path=root/'R70/muscle/R70_FDP_ENVELOPE.json'
read=lambda p:json.loads(p.read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
packet=read(packet_path)
w=packet['working']
guide=np.array(packet['originGuide']['pointsCM'])
ulna_node=int(packet['originGuide']['sourceUlnaVertex0'])
guide_name='R70 | Ulnar witness to working flexor'
base=np.array(w['verticesCM'])
faces=np.array(w['faces'])
delta=np.array(w['thicknessDeltaCM'])
gain=np.array(w['editWeights'])
patch_ids=np.array(w['patchVertexIDs0'])
field=read(root/'R69/attachment/R69_PATCH_RESPONSE.json')
axis=np.array(field['axisCM'])
weights=np.array(field['weights'])
arm=read(root/'R63/geometry/R63_ARM_BINDING.json')
hinges=read(root/'R63/geometry/R63_ISOLATED_HINGE.json')['samples']
scale=np.array([-.01,-.01,.01])
muscle_name='R70 | Working FDP envelope'
patch_name='R69 | Working five-node patch'
lead_name='R69 | Index proximal lead'
def setup():
    ctrl=bpy.data.objects['Elbow study control']
    jaw=bpy.data.objects['Jaw opening control']
    for obj in (ctrl,jaw):
        if obj.animation_data:
            obj.animation_data.action=None
    return ctrl,jaw

def pose(c,jaw,event,wrist,channel,sample,node,amount,thickness,manual=None):
    values={'Recorded arm event':event,'Isolate elbow flexion':manual is not None,'Elbow flexion (degrees)':float(manual or 0),
        'Wrist pilot (degrees)':wrist,'Digit channel':channel,'Digit sample':sample,
        'Exterior follows arm':True,'Show fitted hand':True,'Show index MTJ handoff':True,
        'Show archived index MTJ':True,'Index MTJ working node':node,'Index MTJ node offset (mm)':float(amount),
        'Muscle surface response':.84 if event==8 else 1.,'Biceps guide edit (mm)':1.2 if event==8 else 0.}
    if 'FDP working thickness' in c:
        values['FDP working thickness']=float(thickness)
        values['Show working FDP surface']=True
        values['Show FDP origin guide']=True
    for k,value in values.items():
        c[k]=value
    jaw['Jaw opening (degrees)']=20 if event==8 else 0
    for obj in [c,jaw]:
        obj.update_tag()
    bpy.context.view_layer.update()

def coords(name):
    obj=bpy.data.objects[name].evaluated_get(bpy.context.evaluated_depsgraph_get())
    mesh=obj.to_mesh()
    try:
        v=np.empty((len(mesh.vertices),3),dtype=np.float32)
        mesh.vertices.foreach_get('co',v.ravel())
        matrix=np.asarray(obj.matrix_world)
        return v@matrix[:3,:3].T+matrix[:3,3]
    finally:
        obj.to_mesh_clear()

def finger_print(names):
    h=hashlib.sha256()
    for name in names:
        h.update(name.encode())
        h.update(coords(name).tobytes())
    return h.hexdigest()

def volume(v):
    a,b,c=np.moveaxis((v-v.mean(axis=0))[faces],1,0)
    return float(np.einsum('ij,ij->',a,np.cross(b,c))/6.)

cases=[]
for k,event in enumerate(range(len(arm['events']))):
    for j,(channel,sample) in enumerate([(0,0),(1,1),(1,3),(2,2),(3,1)]):
        for t in [.8,1.,1.2]:
            cases.append((event,(k+j)%5-2,channel,sample,(k+j)%5,[-.5,0.,.5][(k+j+1)%3],t,None))
for node in range(5):
    for offset in (-.5,-.23,0.,.31,.5):
        for t in (.8,.91,1.,1.09,1.2):
            cases.append((8,1,1,2,node,offset,t,None))
# Include isolated source hinges (same control used for the earlier arm replay).
for h in hinges[::6]:
    degrees=h['angleDeg']
    cases.append((0,-1,1,1,4,.5,1.2,degrees))
selected=cases[::max(1,len(cases)//13)]+[cases[-1]]
bpy.ops.wm.open_mainfile(filepath=str(parent.resolve()))
ctrl,jaw=setup()
old_names=sorted(x.name for x in bpy.context.scene.objects if x.type=='MESH')
old=[]
for args in selected:
    pose(ctrl,jaw,*args)
    old.append(finger_print(old_names))
bpy.ops.wm.open_mainfile(filepath=str(master.resolve()))
ctrl,jaw=setup()
new_names={x.name for x in bpy.context.scene.objects if x.type=='MESH'}
assert set(old_names)<=new_names and {muscle_name,guide_name}<=new_names
assert len(bpy.data.objects[muscle_name].data.polygons)==len(faces)
for args,expected in zip(selected,old):
    pose(ctrl,jaw,*args)
    assert finger_print(old_names)==expected
for name in (patch_name,lead_name):
    bpy.data.objects[name].modifiers['R69 | illustrative diameter'].show_viewport=False
bpy.data.objects[guide_name].modifiers['R70 | illustrative diameter'].show_viewport=False
max_error=max_patch=max_anchor=max_volume=max_guide=max_ulna=max_root=0.
for args in cases:
    e,wrist,channel,sample,n,x,thick,manual=args
    pose(ctrl,jaw,*args)
    event=arm['events'][e] if manual is None else next(h for h in hinges if h['angleDeg']==manual)
    F=np.asarray(event['F'])
    local=base+delta*(thick-1)+gain[:,n,None]*x/10*axis
    expected=(local@F[:3,:3].T+F[:3,3])*scale
    actual=coords(muscle_name)
    route=coords(guide_name)
    expected_route=(guide@F[:3,:3].T+F[:3,3])*scale
    max_guide=max(max_guide,float(1000*np.linalg.norm(expected_route-route,axis=1).max()))
    max_ulna=max(max_ulna,float(1000*np.linalg.norm(route[0]-coords('R63 | ulna')[ulna_node])))
    max_root=max(max_root,float(1000*np.linalg.norm(route[-1]-actual[0])))
    assert actual.shape==expected.shape and np.isfinite(actual).all()
    this=float(1000*np.linalg.norm(actual-expected,axis=1).max())
    max_error=max(max_error,this)
    max_patch=max(max_patch,float(1000*np.linalg.norm(actual[patch_ids]-coords(patch_name),axis=1).max()))
    max_anchor=max(max_anchor,float(1000*np.linalg.norm(weights@actual[patch_ids]-coords(lead_name)[0])))
    max_volume=max(max_volume,abs(volume(actual)*1e6-volume(local)))
    if this>=.001:
        raise ValueError((args,this))
assert max(max_guide,max_ulna,max_root)<.001
assert max_patch<.001 and max_anchor<.001 and max_volume<.002
result=dict(status='PASS',blender=bpy.app.version_string,blendSHA256=sha(master),parentSHA256=sha(parent),muscleSHA256=sha(packet_path),
    inheritedMeshes=len(old_names),wholeFigureComparisons=len(selected),allInheritedPositionsExactlyEqual=True,
    settings=len(cases),newVerticesCompared=len(cases)*len(base),maximumVertexErrorMM=max_error,
    maximumCapToR69PatchGapMM=max_patch,maximumWeightedAnchorToIndexStartMM=max_anchor,maximumVolumeErrorCM3=max_volume,
    originGuideVerticesCompared=len(cases)*len(guide),maximumOriginGuideErrorMM=max_guide,
    maximumOriginGuideUlnaGapMM=max_ulna,maximumOriginGuideBellyGapMM=max_root,
    scope='Saved R70 master reopened, evaluated with the inherited arm, wrist, digit and node controls and a new shape width. Compares all vertices to independent world evaluation and verifies both the cap and tendon start against live prior meshes. Display-only widths disabled for point extraction; disk contents retained.')
out.write_text(json.dumps(result,indent=2)+'\n')
print(result)
