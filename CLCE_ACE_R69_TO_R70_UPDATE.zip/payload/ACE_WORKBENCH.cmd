@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 goto runpy
where python >nul 2>nul
if not errorlevel 1 goto runpython
if /i "%~1"=="--check" goto needpython
echo Python is unavailable. Opening the self-contained workbench.
if /i "%~1"=="belly" goto belly
if /i "%~1"=="handoff" goto handoff
if /i "%~1"=="fingers" goto fingers
if /i "%~1"=="flexor" goto flexor
if /i "%~1"=="hand" goto hand
if /i "%~1"=="wrist" goto wrist
if /i "%~1"=="tissue" goto tissue
if /i "%~1"=="elbow" goto elbow
if /i "%~1"=="mouth" goto mouth
if /i "%~1"=="jaw" goto mouth
start "" "%~dp0ACE_WORKBENCH.html"
exit /b 0
:belly
start "" "%~dp0R70\ui\Flexor_belly.html"
exit /b 0
:handoff
start "" "%~dp0R69\ui\Forearm_handoff.html"
exit /b 0
:fingers
start "" "%~dp0R68\ui\Finger_flexors.html"
exit /b 0
:flexor
start "" "%~dp0R67\ui\Index_flexor.html"
exit /b 0
:hand
start "" "%~dp0R66\ui\Hand_study.html"
exit /b 0
:wrist
start "" "%~dp0R65\ui\Wrist_study.html"
exit /b 0
:tissue
start "" "%~dp0R64\ui\Arm_tissue.html"
exit /b 0
:elbow
start "" "%~dp0R63\ui\Elbow_study.html"
exit /b 0
:mouth
  start "" "%~dp0R62\ui\Mouth_alignment.html"
exit /b 0
:runpy
py -3 "%~dp0R70\launcher\ace_workbench.py" %*
goto finished
:runpython
python "%~dp0R70\launcher\ace_workbench.py" %*
goto finished
:needpython
echo Full release verification requires Python 3.8 or later.
pause
exit /b 1
:finished
set "ACE_RESULT=%errorlevel%"
if not "%ACE_RESULT%"=="0" pause
exit /b %ACE_RESULT%
