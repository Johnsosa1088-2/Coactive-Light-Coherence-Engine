# Gentle 125 · Working deep finger flexor

R70 adds a closed, editable model of the positive-X flexor digitorum profundus (FDP) to the complete R69 figure. The new model has one fitted index outlet. At the proximal end a one-dimensional curve connects a specific ulna vertex to the working muscle. At the distal end five shared positions meet the R69 index attachment. The original skeleton, forearm research sources, skin and prior workbench implementations are preserved.

## Open the study

Open `R70/ui/Flexor_belly.html` directly in a browser. In the full project use `ACE_WORKBENCH.cmd belly` on Windows or `python R70/launcher/ace_workbench.py belly`. The shared host also offers the earlier body and research workbenches.

1. Select **Inspect the ulna**. Look for the start of the working origin guide, then follow it to the proximal pole of the muscle. The opposing view shows the historical forearm record and its named ulna site.
2. Select **Inspect the junction**, **Node 4** and **+0.5 mm**. The inherited 0.24 weight produces 0.120 mm of index tendon origin motion. The shared positions remain coincident.
3. Select **Compare the muscle** and change **Working thickness** from **0.80×** to **1.20×**. The transverse section shows the model inside the fitted skin and between the bones. Return to neutral and use the motion controls to follow the index route through the wrist.
4. Open `R70/rig/Aurelia_R70_Deep_Flexor.blend` for the editable full figure. The *Elbow study control* object has the working thickness and display properties alongside the inherited controls.

## Evidence and fit

The archive’s forearm Gold drawing supplies a shared FDP muscle track and an index tendon track. CONNECT387 independently supplies the positive-X deep-flexor family, a named ulna face, and a diagram with 51 points. The matching original skeleton in CONNECT216 establishes the bone correspondence. All 832 vertices and 1,656 faces of the two forearm bones were mapped bijectively by component. Bone revision differences reach 2.328 mm at individual vertices. The named face maps to face 833 on component 55 of the current ulna. Vertex 418 on that face is the proximal working reference. Indices here are zero-based.

The direct segment from vertex 418 to the working muscle pole would place 33.376 mm of the 40.458 mm segment inside the ulna. A fitted 62.433 mm guide leaves the ulna at that vertex and meets the muscle at its pole. The fitted curve has author-defined steering points. Its manufacturing cross-section and anatomical attachment footprint are unmeasured.

The working belly is a single closed surface with 1,536 vertices and 3,068 triangles. Its nominal volume is 1.940 cm³. The authored dimensions and the 2.2 mm distal correction are recorded in the packet. With node offsets neutral, the three thickness controls produce approximately 1.299, 1.940 and 2.717 cm³. At each setting the interface preserves the R69 five-node attachment. Future middle, ring and little finger outlets need their own registration. The inherited middle-finger guide remains available in its earlier workbench.

## Verification and limits

The geometry audit checks 33 sampled meshes for foldovers, intersections, enclosure and guide contact, with no secondary index tendon penetration. At the neutral forearm the lowest measured separations are 0.358 mm from working skin and 0.268 mm from the closest bone. A separate bound covers the continuous thickness range and one signed node offset at a time. In 2,200 tested combinations of released arm and hand states, the conservative lower bounds are 0.295 mm to skin and 0.246 mm to bones. Those numbers refer to this dataset and idealized working geometry. The zero-width origin guide makes intentional contact at its two endpoints.

The reopened Blender master is compared to R69 under matching parent controls. Blender uses finite precision. The reports record measured tolerances and include an explicit comparison of all inherited mesh positions. The R70 additions follow the forearm and respond to their own shape controls. Activation, tendon force, physiological volume conservation, muscle-driven skin bulging and material contact remain open. Canonical source observations and authored fit decisions are recorded separately.

| Item | Project file |
| --- | --- |
| Registered source and original assets | `R70/origins/` |
| Mesh, deformation fields, origin guide and reproducible builders | `R70/muscle/` |
| Local surface and guide checks | `R70/qa/R70_BELLY_GEOMETRY.json` |
| Arm, hand and wrist combinations | `R70/qa/R70_BELLY_ARM.json` |
| Blender scene replay | `R70/qa/R70_BLENDER_CHECK.json` |
| Offline viewer and browser replay | `R70/qa/R70_STUDIO_CHECK.json`, `R70/qa/R70_BROWSER_CHECK.json` |
| Provenance, inherited file checks and reproducibility | `R70_VERIFICATION.json`, `R70_FILE_SHA256.json`, `R70/qa/R70_REBUILD.json` |

The viewer runs from a local file. The Python launcher also supports loopback serving. Desktop and narrow-window rendering were exercised in QtWebEngine. Windows batch commands were checked as text. The R70 standalone HTML, PNG and GIF are all derived from the working packet.

## Restore

The complete ZIP extracts to `CLCE_ACE_M05C_R70` and requires no earlier release. The smaller update uses the exact full R69 ZIP (`CLCE_ACE_M05C_R69_INDEX_FOREARM_HANDOFF.zip`, SHA-256 `d904744164b973dc7ba9fcf50442ffbe557e99ad3c8929eea9fb103e07f5b91a`) or its intact extracted folder. On Windows, extract the update, place the R69 ZIP beside the extracted updater folder and launch `APPLY_WINDOWS.cmd` in that folder. With Python, run `python CLCE_ACE_R69_TO_R70_UPDATE.zip --base CLCE_ACE_M05C_R69_INDEX_FOREARM_HANDOFF.zip --output CLCE_ACE_M05C_R70` in a directory where the output folder does not exist. Allow roughly 1 GiB for the extracted project. `python R70/launcher/ace_workbench.py --check` verifies the restored file inventory.

All 1,951 files from the frozen R69 checkpoint are retained. The original R69 launcher pair is preserved byte-for-byte in `R70/previous/`. At the root the updated launcher provides the new study.
