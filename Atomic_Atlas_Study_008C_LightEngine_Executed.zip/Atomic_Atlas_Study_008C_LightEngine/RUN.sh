#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
python3 src/transport.py
python3 src/independent_audit.py
python3 -m unittest discover -s tests -v
python3 src/build_viewer.py
printf 'Ready: Aurelia_The_Dragons_First_Motion.html\n'
