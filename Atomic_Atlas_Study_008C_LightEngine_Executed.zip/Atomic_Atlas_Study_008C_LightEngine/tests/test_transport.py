import copy,json,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from transport import build,step,CONTRACT,run_scenario
from independent_audit import audit_all,audit_scenario

class SevenGateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.runs=build()
        cls.by_id={s['scenario_id']:s for s in cls.runs['scenarios']}

    def test_frozen_contract_sha(self):
        from hashlib import sha256
        self.assertEqual(self.runs['frozen_contract_sha256'],sha256((ROOT/'CONTRACT_FROZEN.json').read_bytes()).hexdigest())
    def test_six_predeclared_scenarios(self):
        self.assertEqual(set(self.by_id),{f'G{i}' for i in range(1,7)})
    def test_all_360_frames(self):
        self.assertEqual(sum(len(s['frames']) for s in self.by_id.values()),360)
    def test_all_predeclared_checks(self):
        for s in self.by_id.values():
            self.assertEqual(s['outcome'],'PASS_PREDECLARED_CHECKS',s['scenario_id'])
    def test_exact_closed_balance(self):
        for s in self.by_id.values():
            self.assertTrue(all(r['total_before']==r['total_after']==s['initial_total'] for r in s['frames']))
    def test_all_bounds(self):
        for s in self.by_id.values():
            self.assertTrue(all(all(0<=v<=c for v,c in zip(r['states_after'],s['capacities'])) for r in s['frames']))
    def test_no_closed_valve_transfer(self):
        for s in self.by_id.values():
            self.assertTrue(all(r['accepted']['24']==0 for r in s['frames'] if not r['gates_open']['24']))
    def test_latent_is_quiet(self):
        self.assertEqual(self.by_id['G1']['summary']['total_accepted'],0)
    def test_emergence_prospectively_onsets(self):
        r=self.by_id['G2']['frames']
        self.assertEqual(sum(k['accepted']['12'] for k in r[:5]),0)
        self.assertGreater(sum(k['accepted']['12'] for k in r[5:]),0)
    def test_organization_has_transport(self):
        self.assertGreater(self.by_id['G3']['summary']['total_accepted'],0)
    def test_gate24_status_matches_real_gate(self):
        for scenario in self.by_id.values():
            for f in scenario['frames']:
                self.assertEqual(f['gate24_state'] in ('OPEN','OPEN_GUARDED'),f['gates_open']['24'])
    def test_threshold_explicit_closure(self):
        f=self.by_id['G4']['frames']
        self.assertTrue(all(not r['gates_open']['24'] and r['accepted']['24']==0 for r in f[18:36]))
    def test_threshold_guarded_reopen(self):
        f=self.by_id['G4']['frames']
        self.assertTrue(f[36]['gates_open']['24'])
        self.assertTrue(all(f[36]['gate24_guard'].values()))
        self.assertGreater(f[36]['accepted']['24'],0)
    def test_sustained_circulation_storage_unchanged(self):
        s=self.by_id['G5']
        self.assertEqual(s['summary']['total_accepted'],480)
        self.assertTrue(all(f['states_after']==[25]*4 for f in s['frames']))
    def test_overextended_requests_clipped(self):
        s=self.by_id['G6']
        self.assertGreater(s['summary']['total_withheld'],0)
        self.assertEqual(s['frames'][0]['requested']['12'],90)
        self.assertEqual(s['frames'][0]['accepted']['12'],25)
        self.assertEqual(s['frames'][0]['accepted']['14'],50)
    def test_independent_audit_passes(self):
        self.assertEqual(audit_all(self.runs)['result'],'PASS_INDEPENDENT_AUDIT')
    def test_audit_rejects_fabricated_inventory(self):
        x=copy.deepcopy(self.by_id['G3'])
        x['frames'][0]['states_after'][0]+=1
        self.assertEqual(audit_scenario(x)['outcome'],'FAIL')
    def test_audit_rejects_closed_gate_flow(self):
        x=copy.deepcopy(self.by_id['G4'])
        x['frames'][20]['accepted']['24']=1
        self.assertEqual(audit_scenario(x)['outcome'],'FAIL')
    def test_audit_rejects_faked_gating(self):
        x=copy.deepcopy(self.by_id['G4'])
        x['frames'][36]['gate24_guard']['receiver_capacity']=False
        self.assertEqual(audit_scenario(x)['outcome'],'FAIL')
    def test_audit_rejects_source_overspend(self):
        x=copy.deepcopy(self.by_id['G6'])
        x['frames'][0]['accepted']['14']=900
        self.assertEqual(audit_scenario(x)['outcome'],'FAIL')
    def test_replay_determinism(self):
        self.assertEqual(self.runs,build())

if __name__=='__main__':unittest.main()
