# Atomic Atlas — Study 008-C: The Dragon's First Motion

**Private, offline, interactive 60-frame HTML/SVG LightEngine prototype.**

## OPEN THE VIEWER (NO INSTALL REQUIRED)

Double-click **`Aurelia_The_Dragons_First_Motion.html`** and open it with Chrome, Firefox or Edge. Everything, including Aurelia's image, the simulation records and the JavaScript interaction, is embedded in this one file. No network, hosting, downloaded dependencies or Python is required merely to view it.

- Choose a scenario **G1–G6** in the menu. G7 is an independent audit, not a seventh physical/transport scenario.
- Press **Play**, change playback speed, or scrub frames **1–60** with the slider. The viewer is deliberately paused on opening.
- Toggle **Blue attire routing** to show/hide the SVG lighting laid over the preserved Aurelia portrait.
- Inspect reservoir levels, accepted transfer quantities, constrained/blocked transfer records, and stored-quantity plots.
- Start with **G4 — At the Threshold**: frames **19–36** hold Gate 24 closed (0 accepted), and frame **37** is the first candidate guarded reopening. The prerecorded model permits and transfers one quantum at that frame.
- Try **G6 — Overextension**: frame 1 requests 90 on each of two outputs from R1, accepts 25 to R2 and 50 to R4, and explicitly clips the excess 65+40; the model does not overfill storage or spend more than is available.

This is an **animated viewer**, not a pre-rendered video. It is frame-synchronous: visuals are functions of recorded accepted transfers and reservoir states. The portrait does not physically deform; only separately drawn vector routing/indicators respond to the simulation. Source imagery stays byte-for-byte unchanged.

## REPRODUCE THE MODEL AND AUDIT

Requires **Python 3.9+ standard library only**. From inside the extracted directory, run:

```powershell
python src/transport.py
python src/independent_audit.py
python -m unittest discover -s tests -v
python src/build_viewer.py
```

A convenience `RUN.cmd` does all four on Windows (when `python` is on PATH). A `RUN.sh` equivalent is available for Linux/macOS.

The frozen contract `CONTRACT_FROZEN.json` was hashed **before** the simulation was executed. Its fixed `sha256` is recorded in `CONTRACT_SHA256.txt`. There are six prepared transport trials and a **G7 cross-scenario audit**. Every trial has 60 frames, for 360 independently audited event receipts. Automated tests include deliberate corruption detection. All tests passed in the handoff producer's Python runtime; rerun locally for independent reproduction.

### What the arithmetic proves (within the declared discrete model)

For a transfer of `n` internal integer quanta, the same `n` is debited from the source and credited to the destination. For simultaneous transfers, each request is evaluated using the **pre-frame state**, and source/destination allocation is bounded in a fixed priority order before applying all changes atomically.

At every frame:

- `0 <= R_i <= C_i`
- `Σ R_i(frame) = Σ R_i(initial)` with **exact integer equality** (closed system, no source/sink terms)
- closed links accept `0`
- accepted outgoing from a reservoir cannot exceed its pre-step inventory
- accepted incoming cannot exceed the pre-step destination free capacity

We intentionally use this discrete integer-quantum model instead of pretending to have a physical fluid-transport solver. The more general continuous notation is a model-motivation equation, not the actual numerical implementation. The viewer shows the discrete update:

`R_i[n+1] = R_i[n] + accepted_in[n] - accepted_out[n]`.

## RESULT SUMMARY

| Scenario | Declared purpose | Observed result |
| --- | --- | --- |
| G1 Hidden Dragon | No unsupported transfer | 0 accepted, unchanged reservoirs |
| G2 Dragon Appears | Delayed-onset transfer | Source-to-path transport begins after frame 5 |
| G3 Diligent Motion | Bounded directed organization | Positive accepted internal transfers |
| G4 At the Threshold | Gate 24 held then guarded reopening | Closed frames 19–36; transfer resumes frame 37 under guards |
| G5 Flying Dragon | Sustained bounded circulation | 480 accepted cumulative quanta in 60 frames; levels unchanged because inflow equals outflow |
| G6 Overextended Dragon | Capacity/dual-output contention | 105 requested quanta clipped; no negative/over-capacity state |
| G7 Use Nine | Independently audit G1–G6 | PASS, 360/360 audited frames, 0 discovered violations |

All **21 automated tests pass**. An audit-failure result is deliberately tested by injecting false state changes, fabricated closed-gate transfer, invalid gate guards, and overspending, each of which is detected.

**Important:** G5 cumulative transfer count measures repeated throughput, not created material; stored total remains constant. G6 deliberately requests beyond capacity, and the limiter does its job. Successful rejection is an intended result.

## VISUAL CANON AND PRIVACY

`assets/Aurelia_Study008A_Approved_Reference.png` preserves the previously approved source image **byte-for-byte**, SHA-256:

`777e5693361fbd50caffa04eb64ae1ef40f258b9049f7f2edf27f37dc1ff69b5`

`assets/Aurelia_Portrait_Crop.jpg` is a derivative presentation crop. The viewer embeds **only the crop** with semitransparent vector overlays. The garment's original ivory, gold and sapphire design stays unchanged. The SVG paths are artistic correspondence to transfer directions, not exact atlas/raster registration, measured photon flow, anatomical anatomy evidence, or real wearable electronics.

The entire package is **private project material**. No uploads/publication/third-party sharing are authorized by this package.

## EVIDENCE FIREWALL

- Study 007 recovery verdicts remain a **different mathematical model**, not proof of fluid containment or structural durability.
- Study 008-C is a normalized, deterministic, quantity-conserving **discrete toy transport model**.
- No actual fluid, hydrogel, garment heat-transfer, optical signaling, 400 MHz timing, silicon, or physical experiment was executed here.
- The classical Azure Dragon and Black Tortoise stories are creative metaphors for controlled transport and constraints; this model is not empirical solar prediction.
- The HTML viewer is driven by computed record data, but drawing choices such as the intensity of garment light are *presentation mappings*, not physical results.

Files: `CONTRACT_FROZEN.json` · `CONTRACT_SHA256.txt` · `src/transport.py` · `src/independent_audit.py` · `src/build_viewer.py` · `data/simulated_transport.json` · `data/independent_audit.json` · `tests/test_transport.py` · `docs/` visual receipts · `MANIFEST_SHA256.json`.
