# Study 008-C — Execution Report

Status: **PASS FOR PREPARED DISCRETE TRANSPORT SCENARIOS AND INDEPENDENT DATA AUDIT**

- Frozen contract SHA-256: `82d86ee0f6ef40814dc215d21a3ec5d0131c368f7335ec4aa8b28d427c1bb3fd`.
- Frozen reference original SHA-256: `777e5693361fbd50caffa04eb64ae1ef40f258b9049f7f2edf27f37dc1ff69b5`.
- Six deterministic scenario executions, each 60 frames.
- All six scenario-specific checks passed; G7 independent audit examined **360 event receipts** and reported no violations.
- Automated tests: **21 passed**, including intentionally corrupted evidence that the independent checker rejected.
- All closed-system totals conserved **exactly**, in integer units.
- G4: Gate 24 closed for zero-based frames 18–35 (user-visible 19–36); the declared guarded reopen begins on frame 37, the first resumed positive transfer.
- G6: Initial frame requests 90 for R1→R2 and 90 for R1→R4, accepts 25 and 50, and explicitly clips 65 and 40. All stores remain bounded.
- G5: 2 quanta circulate on each of four ring links per frame; 480 cumulative accepted transfers in 60 frames with unchanged node occupancies.
- The offline viewer was exercised in Chromium, including scenario switching, frame scrubbing, played frames, closed-to-reopened gate state, correct ledgers, and mobile responsive dimensions. No JavaScript page errors were observed.

**Do not promote** these normalized-model passes into measured liquid flow, physically characterized materials, photonic computation, or any physical claim. The source portrait is a user-approved creative asset, not a physical Aurelia body.
