#!/usr/bin/env python3
"""Build standalone viewer with embedded data and preserved derivative portrait.
No external fonts, scripts, network requests, or runtime file loading.
"""
from pathlib import Path
import json, base64, hashlib
ROOT=Path(__file__).resolve().parents[1]
STANDALONE=ROOT/'Aurelia_The_Dragons_First_Motion.html'
img=ROOT/'assets'/'Aurelia_Portrait_Crop.jpg'
data=json.loads((ROOT/'data'/'simulated_transport.json').read_text(encoding='utf-8'))
audit=json.loads((ROOT/'data'/'independent_audit.json').read_text(encoding='utf-8'))
assert audit['result']=='PASS_INDEPENDENT_AUDIT'
assert all(x['outcome']=='PASS_PREDECLARED_CHECKS' for x in data['scenarios'])
image_src='data:image/jpeg;base64,'+base64.b64encode(img.read_bytes()).decode('ascii')
js_data=json.dumps(data,separators=(',',':')).replace('</','<\\/')
html=r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="color-scheme" content="dark" />
<title>The Dragon's First Motion · Atomic Atlas 008-C</title>
<style>
:root{--ink:#e9eef9;--muted:#aab9d0;--dim:#7286a5;--cyan:#70ceff;--gold:#f5c878;--violet:#a78fff;--edge:#364e72;--paper:#08111f;--blue:#132842}
*{box-sizing:border-box}html{background:#060d18}body{margin:0;color:var(--ink);background:radial-gradient(ellipse at 10% 0%,#192c45 0%,transparent 35%),radial-gradient(ellipse at 88% 25%,#071d39 0%,transparent 33%),#060d18;font-family:Inter,ui-sans-serif,system-ui,-apple-system,'Segoe UI',sans-serif}button,select,input{font:inherit}button{cursor:pointer}button:focus-visible,select:focus-visible,input:focus-visible{outline:2px solid #7ecfff;outline-offset:3px}button:disabled{opacity:.4;cursor:not-allowed}
.wrap{width:min(1550px,calc(100vw - 48px));margin:auto;padding:28px 0 36px}.topline{display:flex;align-items:center;justify-content:space-between;gap:20px;flex-wrap:wrap;margin-bottom:16px}.id{font-size:11px;letter-spacing:.24em;text-transform:uppercase;color:#9db9d2}.sig{font-size:12px;color:#d5b475;font-family:Georgia,serif;font-style:italic}.header{display:flex;align-items:end;gap:22px;justify-content:space-between;margin-bottom:26px;flex-wrap:wrap}.header h1{font-family:Georgia,'Times New Roman',serif;font-weight:500;letter-spacing:.012em;font-size:clamp(34px,4.2vw,62px);line-height:1.05;margin:0 0 10px;color:#f4dfba}.header p{margin:0;color:#b7c9e0;max-width:750px;line-height:1.55;font-size:14px}.badge{border:1px solid #526c78;border-radius:99px;padding:8px 13px;color:#baf1d5;background:#11342d;font-size:11px;letter-spacing:.08em;white-space:nowrap}.stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin-bottom:18px}.stat{border:1px solid #28405e;background:#0f1c2ccf;border-radius:13px;padding:14px 17px}.stat strong{display:block;font-family:Georgia,serif;font-size:24px;color:#e5edf9;font-weight:500}.stat small{font-size:10px;line-height:1.5;letter-spacing:.085em;text-transform:uppercase;color:#96acc9}
.grid{display:grid;grid-template-columns:minmax(310px,.85fr) minmax(510px,1.2fr);gap:16px;align-items:start}.panel{border:1px solid #335074;border-radius:17px;background:linear-gradient(145deg,rgba(15,33,54,.96),rgba(8,18,33,.93));box-shadow:0 24px 80px rgba(0,0,0,.25);overflow:hidden}.scene{position:relative;border:1px solid #394d67;border-radius:17px;overflow:hidden;background:#101b2a;min-height:500px;box-shadow:0 18px 48px #0005}.scene img{display:block;width:100%;height:auto;aspect-ratio:730/1024;object-fit:cover}.scene:after{position:absolute;content:'';inset:0;background:linear-gradient(0deg,rgba(3,11,20,.77),transparent 22%,transparent 77%,rgba(2,6,12,.28));pointer-events:none}.scene-mark{position:absolute;z-index:3;bottom:16px;left:18px;right:18px;display:flex;align-items:flex-end;gap:16px;justify-content:space-between}.scene-mark b{font-family:Georgia,serif;font-size:20px;font-weight:500;color:#ffe6b6;display:block}.scene-mark span{font-size:10px;color:#cee4fa;letter-spacing:.075em;text-transform:uppercase}.tag{border:1px solid #a6b9d17c;background:#061324c5;border-radius:30px;padding:6px 10px;font-size:10px;color:#d2e1f7;white-space:nowrap}.overlay{position:absolute;inset:0;width:100%;height:100%;pointer-events:none;z-index:2;filter:drop-shadow(0 0 9px #71c7fa)}.routing-line{fill:none;stroke:#9be0ff;stroke-linecap:round;stroke-width:2.5;stroke-dasharray:9 12;opacity:0;filter:drop-shadow(0 0 6px #77bcff);transition:opacity .15s}.spark-point{fill:#b9eaff;filter:drop-shadow(0 0 7px #6bcaff);opacity:0;transition:opacity .15s}.scene-tech{position:absolute;top:12px;right:12px;z-index:3;background:#091b2ccb;padding:8px 11px;border:1px solid #83b8dc91;border-radius:10px;font-size:10px;color:#cbe7ff;letter-spacing:.055em}
.dash{padding:21px;display:grid;gap:13px}.panel-title{display:flex;align-items:center;justify-content:space-between;gap:12px}.eyebrow{font-size:11px;text-transform:uppercase;letter-spacing:.18em;color:#e2bb73}.panel-title h2{font-family:Georgia,serif;font-size:27px;font-weight:500;margin:3px 0;color:#edf2fc}.panel-title .chip{border-radius:7px;padding:7px 9px;border:1px solid #385d73;background:#102943;color:#93d7f7;font-size:11px;font-weight:700;letter-spacing:.08em}.model{position:relative;background:radial-gradient(ellipse at 40% 50%,#122f4e,transparent 68%),#091525;border:1px solid #284262;border-radius:13px;overflow:hidden}.model svg{display:block;width:100%;max-height:440px}.tube{stroke:#295d87;stroke-width:17;opacity:.55;fill:none;stroke-linecap:round}.tube-light{stroke:#7ecfff;stroke-width:4.3;opacity:.2;fill:none;stroke-linecap:round;filter:drop-shadow(0 0 5px #4bc2ff)}.edge-14{stroke:#d7aa5d;stroke-width:2;stroke-dasharray:5 8;opacity:0;fill:none}.flow-particle{fill:#ffdf9e;filter:drop-shadow(0 0 7px #6fc7f7);opacity:0}.tank{fill:#132c44;stroke:#75bae9;stroke-width:1.5}.tank-fill{fill:#368cd2;opacity:.52}.tank-glow{fill:none;stroke:#d5b27b;stroke-width:1.8;stroke-dasharray:4 5;opacity:.72}.tank-name{fill:#eff5ff;font-size:23px;font-family:Georgia,serif}.tank-level{fill:#a7c9e3;font-size:12px}.model-label{font-family:Georgia,serif;font-size:14px;fill:#e3d3b5}.gate-disc{stroke:#73cfff;stroke-width:2.1;fill:#0a2135;filter:drop-shadow(0 0 11px #3f9fff)}.gate-closed{stroke:#e8a783;filter:drop-shadow(0 0 7px #e49368)}.gate-icon{fill:#b5ebff;font-size:22px;font-weight:700}.gate-closed-text{fill:#f1ad89}.flux-note{font-size:11px;fill:#9eb9d2}.status-strip{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}.valve-status{font-weight:700;color:#9de0ff;letter-spacing:.07em}.valve-status.held{color:#ffc79a}.sub{color:#a8bcd2;font-size:11px;line-height:1.55}.control{border:1px solid #294363;border-radius:13px;background:#0d1e32;padding:16px}.controltop{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:12px;flex-wrap:wrap}.controltop label{font-size:11px;color:#b1c4dc;text-transform:uppercase;letter-spacing:.08em}.controltop select{background:#132d49;border:1px solid #497297;border-radius:8px;color:#e7f4ff;padding:8px 10px;max-width:290px;font-size:12px}.scrubline{display:flex;align-items:center;justify-content:space-between;font-size:12px;color:#c4d5eb;margin-bottom:4px}.scrubline strong{font-family:ui-monospace,SFMono-Regular,monospace;color:#f4d398}.timeline{width:100%;accent-color:#7acbfc;margin:8px 0 10px;cursor:pointer}.controls{display:flex;align-items:center;gap:10px;flex-wrap:wrap}.btn{background:#183754;border:1px solid #4d7190;border-radius:10px;color:#e8f5ff;padding:9px 14px;font-size:12px;font-weight:600}.btn.play{background:linear-gradient(135deg,#b07b37,#e5c282);border-color:#f2cf97;color:#102034}.btn.square{padding:9px 12px}.controls label{font-size:12px;color:#afc2db;display:flex;align-items:center;gap:6px;white-space:nowrap}.controls input[type=checkbox]{accent-color:#72c5fa}.controls select{background:#12263c;border:1px solid #44658a;color:#d9eafb;border-radius:8px;padding:8px}.phase{display:flex;gap:8px;align-items:center;font-size:12px;color:#efd5a0;padding:10px 12px;border:1px solid #6d5539;background:#3929143d;border-radius:9px;margin-top:11px}.phase span{color:#cadaec}.bottom{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:17px}.info{padding:19px}.info h3{font-family:Georgia,serif;font-size:22px;font-weight:500;color:#ead3a3;margin:0 0 14px}.metric-list{display:grid;gap:9px}.metric{display:flex;justify-content:space-between;gap:14px;align-items:center;font-size:12px;color:#9fb3cf}.metric strong{color:#e1f0ff;font-family:ui-monospace,monospace;font-weight:500;font-size:12px}.metric .good{color:#a3edca}.metric .warn{color:#ffcaa3}.edges{width:100%;border-collapse:collapse;font-size:11px;table-layout:fixed}.edges th{font-weight:600;text-align:right;color:#92a9c9;border-bottom:1px solid #315072;padding:10px 6px}.edges td{text-align:right;color:#d0e0f4;padding:9px 6px;border-bottom:1px solid #213652;font-family:ui-monospace,monospace}.edges th:first-child,.edges td:first-child{text-align:left}.edges .still{color:#7d90a8}.edges .active{color:#8adfff}.edges .blocked{color:#fec9a0}.charts{padding:19px}.charts h3{margin:0 0 8px;color:#e9d3a9;font-family:Georgia,serif;font-weight:500;font-size:20px}.charts svg{width:100%;height:170px;display:block}.chart-legend{display:flex;gap:12px;font-size:10px;color:#afc1d8;flex-wrap:wrap}.dot{display:inline-block;height:8px;width:8px;border-radius:50%;margin-right:5px}.notes{color:#9eb5d0;font-size:12px;line-height:1.65;margin:10px 0 0}.notes b{color:#dcd1b4}.footer{display:flex;gap:16px;justify-content:space-between;align-items:center;border-top:1px solid #24415c;padding-top:20px;margin-top:23px;color:#819fba;font-size:11px;line-height:1.6}.footer strong{color:#d5ba8d;font-weight:500}.footer a{color:#8ed4fa;text-decoration:none}.footer a:hover{text-decoration:underline}
@media(max-width:1080px){.grid{grid-template-columns:1fr}.scene{max-width:620px;margin:0 auto;width:100%}.bottom{grid-template-columns:1fr 1fr}.topline{margin-top:0}}@media(max-width:700px){.wrap{width:min(100% - 24px,620px);padding:18px 0}.stats{grid-template-columns:1fr 1fr}.header h1{font-size:37px}.bottom{grid-template-columns:1fr}.dash{padding:13px}.model-label{font-size:12px}.scene-mark b{font-size:17px}.footer{flex-direction:column;align-items:flex-start}.control{padding:12px}}
@media (prefers-reduced-motion:reduce){*{scroll-behavior:auto!important;animation:none!important;transition:none!important}}
</style>
</head>
<body>
<div class="wrap">
  <div class="topline"><span class="id">ATOMIC ATLAS / STUDY 008-C / LIGHTENGINE</span><span class="sig">The boundary remains. The current begins.</span></div>
  <header class="header"><div><h1>The Dragon's First Motion</h1><p>Sixty recorded frames of a bounded four-reservoir transport model, mapped onto Aurelia's preserved visual anchor. The blue is computed data made visible—not a claim of physical fluid or fabric activity.</p></div><span class="badge">✓ EXECUTED MODEL · AUDIT PASSED</span></header>
  <section class="stats" aria-label="Verified model summary">
    <div class="stat"><strong>6 / 6</strong><small>Predeclared scenario checks satisfied</small></div>
    <div class="stat"><strong>360</strong><small>Independent frame receipts audited</small></div>
    <div class="stat"><strong>21 / 21</strong><small>Automated tests passed</small></div>
    <div class="stat"><strong>0</strong><small>Quantity lost to unexplained transfers</small></div>
  </section>
  <main class="grid">
   <div><figure class="scene" aria-label="Aurelia reference with simulation-derived light overlay" style="margin:0"><img src="__PORTRAIT__" alt="Preserved adult Aurelia visual reference with auburn ponytail and ivory gold blue signal attire" />
       <div class="scene-tech">STUDY 008-A · ORIGINAL APPEARANCE PRESERVED</div>
       <svg class="overlay" viewBox="0 0 730 1024" preserveAspectRatio="xMidYMid meet" aria-hidden="true">
         <path class="routing-line" id="route12" d="M415 352 C455 386 461 450 490 490 C528 535 540 580 586 618"/>
         <path class="routing-line" id="route24" d="M449 635 C473 685 486 719 514 775 C542 811 570 873 604 929"/>
         <path class="routing-line" id="route43" d="M415 661 C360 695 308 739 287 794 C272 820 264 864 232 907"/>
         <path class="routing-line" id="route31" d="M238 894 C288 850 318 804 335 745 C349 697 348 650 364 620"/>
         <circle class="spark-point" id="spark12" r="6" cx="415" cy="352"/>
         <circle class="spark-point" id="spark24" r="6" cx="449" cy="635"/>
         <circle class="spark-point" id="spark43" r="6" cx="415" cy="661"/>
         <circle class="spark-point" id="spark31" r="6" cx="238" cy="894"/>
       </svg>
       <div class="scene-mark"><div><b>Aurelia</b><span>Portrait unchanged · Light pathways are vector overlays</span></div><div class="tag">SAPPHIRE ROUTING</div></div>
     </figure>
     <p class="notes" style="margin:11px 6px 0">The portrait is a crop of the existing approved illustration. Routing curves are <b>artistic SVG mappings</b> onto the garment; their brightness and motion are controlled by the accepted transfers recorded in the mathematical model.</p>
   </div>
   <section class="panel dash" aria-label="Transport model playback">
     <div class="panel-title"><div><div class="eyebrow">TRANSPORT SIMULATION · FOUR STORES</div><h2>Watch the current</h2></div><div class="chip" id="scenarioBadge">G4 · THRESHOLD</div></div>
     <div class="status-strip"><div id="gateBanner" class="valve-status">GATE 24 · OPEN</div><span id="energyBanner" class="sub">Internal quantity conserved exactly</span></div>
     <div class="model">
       <svg id="network" viewBox="0 0 680 435" role="img" aria-label="Four storage reservoirs and dynamically illuminated connecting links">
         <defs><linearGradient id="tankShade" x1="0" x2="0" y1="0" y2="1"><stop stop-color="#1f4769"/><stop offset="1" stop-color="#091c30"/></linearGradient><filter id="halo"><feGaussianBlur stdDeviation="4.5" /></filter><linearGradient id="fillGrad" x1="0" x2="0" y1="0" y2="1"><stop stop-color="#55c2ff" stop-opacity=".6"/><stop offset="1" stop-color="#1b5bbb" stop-opacity=".4"/></linearGradient></defs>
         <g opacity=".23" stroke="#6584a2" stroke-width=".65">
          <path d="M0 50H680M0 100H680M0 150H680M0 200H680M0 250H680M0 300H680M0 350H680M0 400H680M70 0V435M140 0V435M210 0V435M280 0V435M350 0V435M420 0V435M490 0V435M560 0V435M630 0V435"/>
         </g>
         <g id="lines">
          <path class="tube" d="M232 102H452"/><path class="tube-light" id="edge12" d="M232 102H452"/>
          <path class="tube" d="M528 160V276"/><path class="tube-light" id="edge24" d="M528 160V276"/>
          <path class="tube" d="M452 335H232"/><path class="tube-light" id="edge43" d="M452 335H232"/>
          <path class="tube" d="M156 276V160"/><path class="tube-light" id="edge31" d="M156 276V160"/>
          <path class="edge-14" id="edge14" d="M210 147Q340 214 472 292"/>
         </g>
         <g id="tanks">
           <g transform="translate(80 46)"><rect class="tank" rx="14" width="152" height="115" fill="url(#tankShade)"/><rect id="fill1" class="tank-fill" x="7" y="74" width="138" height="33" rx="8"/><rect class="tank-glow" x="9" y="7" width="134" height="101" rx="12"/><text class="tank-name" x="76" y="33" text-anchor="middle">R₁</text><text class="tank-level" id="lev1" x="76" y="57" text-anchor="middle">0 / 120</text></g>
           <g transform="translate(452 46)"><rect class="tank" rx="14" width="152" height="115" fill="url(#tankShade)"/><rect id="fill2" class="tank-fill" x="7" y="74" width="138" height="33" rx="8"/><rect class="tank-glow" x="9" y="7" width="134" height="101" rx="12"/><text class="tank-name" x="76" y="33" text-anchor="middle">R₂</text><text class="tank-level" id="lev2" x="76" y="57" text-anchor="middle">0 / 100</text></g>
           <g transform="translate(80 276)"><rect class="tank" rx="14" width="152" height="115" fill="url(#tankShade)"/><rect id="fill3" class="tank-fill" x="7" y="74" width="138" height="33" rx="8"/><rect class="tank-glow" x="9" y="7" width="134" height="101" rx="12"/><text class="tank-name" x="76" y="33" text-anchor="middle">R₃</text><text class="tank-level" id="lev3" x="76" y="57" text-anchor="middle">0 / 90</text></g>
           <g transform="translate(452 276)"><rect class="tank" rx="14" width="152" height="115" fill="url(#tankShade)"/><rect id="fill4" class="tank-fill" x="7" y="74" width="138" height="33" rx="8"/><rect class="tank-glow" x="9" y="7" width="134" height="101" rx="12"/><text class="tank-name" x="76" y="33" text-anchor="middle">R₄</text><text class="tank-level" id="lev4" x="76" y="57" text-anchor="middle">0 / 110</text></g>
         </g>
         <g id="gate24"><circle class="gate-disc" id="gateDisc" cx="528" cy="215" r="25"/><text class="gate-icon" id="gateSymbol" x="528" y="223" text-anchor="middle">✓</text><text class="model-label" x="573" y="213">GATE</text><text class="model-label" x="579" y="232">24</text></g>
         <g><circle cx="342" cy="218" r="62" fill="#0d2339" stroke="#d5b06a" stroke-width="1.5" stroke-dasharray="5 6"/><text class="model-label" x="342" y="205" text-anchor="middle">BOUNDARY</text><text class="model-label" x="342" y="225" text-anchor="middle">AUDIT</text><text class="flux-note" x="342" y="247" text-anchor="middle" id="totalFigure">TOTAL 100</text></g>
         <g id="moving"><circle id="particle12" r="7" class="flow-particle"/><circle id="particle24" r="7" class="flow-particle"/><circle id="particle43" r="7" class="flow-particle"/><circle id="particle31" r="7" class="flow-particle"/><circle id="particle14" r="7" class="flow-particle"/></g>
         <text x="342" y="420" fill="#95c2de" font-size="11" text-anchor="middle">EXACT INTEGER QUANTA · ATOMIC FRAME TRANSFERS</text>
       </svg>
     </div>
     <div class="status-strip" style="padding:0px 6px;font-family:ui-monospace,SFMono-Regular,monospace;font-size:11px;color:#b2d0e8"><span>Rᵢ[n+1] = Rᵢ[n] + accepted_in − accepted_out</span><span>ΣRᵢ[n] = ΣRᵢ[0]</span></div>
     <div class="control">
       <div class="controltop"><label for="scenarioSelect">Select the trial</label><select id="scenarioSelect" aria-label="Choose one of six scenarios"></select></div>
       <div class="scrubline"><span id="trialCaption">At the Threshold · Gate 24</span><strong id="frameText">01 / 60</strong></div>
       <input id="timeline" class="timeline" aria-label="Inspect recorded frames" type="range" min="0" max="59" step="1" value="0" />
       <div class="controls"><button class="btn play" id="play" aria-label="Play or pause">▶ Play</button><button class="btn square" id="back" title="Previous frame" aria-label="Previous frame">❮</button><button class="btn square" id="forward" title="Next frame" aria-label="Next frame">❯</button><label><input type="checkbox" id="routingToggle" checked /> Blue attire routing</label><label><input type="checkbox" id="loopToggle" checked /> Loop</label><select id="speed" aria-label="Playback speed"><option value="240">Slow</option><option value="140" selected>1×</option><option value="70">2×</option></select></div>
       <div class="phase"><span id="phaseIcon">◉</span><div><b id="phaseTitle">Current awaiting authorization</b><span id="phaseDescription" style="display:block">Select a frame to examine the modeled transfer.</span></div></div>
     </div>
   </section>
  </main>
  <section class="bottom" aria-label="Verification details">
    <div class="panel info"><h3>What this frame proves</h3>
      <div class="metric-list">
       <div class="metric"><span>Gate 24 state</span><strong id="m_gate">—</strong></div>
       <div class="metric"><span>Accepted transfer R₂ → R₄</span><strong id="m_flow24">—</strong></div>
       <div class="metric"><span>Blocked potential demand at Gate 24</span><strong id="m_blocked">—</strong></div>
       <div class="metric"><span>Total storage</span><strong id="m_total" class="good">—</strong></div>
       <div class="metric"><span>Mass-balance error for this frame</span><strong id="m_error" class="good">—</strong></div>
       <div class="metric"><span>Capacity violated?</span><strong id="m_capacity" class="good">NO</strong></div>
       <div class="metric"><span>Independent G7 audit</span><strong class="good">PASS · 360 FRAMES</strong></div>
      </div>
      <p id="outcomeNote" class="notes"></p>
    </div>
    <div class="panel info"><h3>Transaction ledger · This frame</h3>
      <table class="edges"><thead><tr><th>Route</th><th>Commanded</th><th>Accepted</th><th>Clipped</th><th>State</th></tr></thead><tbody id="edgesTable"></tbody></table>
      <p class="notes">A closed route has <b>zero attempted and accepted flow</b>. Clipping is separately recorded for open routes whose requests exceed source inventory or receiver capacity. The auxiliary R₁→R₄ stress route appears only in G6.</p>
    </div>
    <div class="panel charts"><h3>Recorded reservoir histories</h3><svg viewBox="0 0 600 185" aria-label="Model trajectories for all four reservoirs" id="history" role="img"><g stroke="#35516c" stroke-width="1" opacity=".7"><path d="M42 15H575 M42 57H575 M42 99H575 M42 141H575 M42 15V150 M575 15V150"/></g><g id="seriesLines"></g><line id="cursor" x1="42" x2="42" y1="15" y2="150" stroke="#f1d18d" stroke-width="2"/><text fill="#a0b8d4" font-size="11" x="42" y="175">FRAME 1</text><text fill="#a0b8d4" font-size="11" x="540" y="175">FRAME 60</text></svg><div class="chart-legend"><span><i class="dot" style="background:#59caff"></i>R₁</span><span><i class="dot" style="background:#d2b173"></i>R₂</span><span><i class="dot" style="background:#8f82f2"></i>R₃</span><span><i class="dot" style="background:#8fdaa8"></i>R₄</span></div></div>
    <div class="panel info"><h3>Interpretation boundaries</h3><p class="notes" style="margin-top:0">The four-reservoir model is <b>executed and independently audited</b>. Its stored quantities are unitless integers, not water volumes; every accepted internal transfer debits one source and credits one destination in the same frame.</p><p class="notes">The six scenarios are <b>different controlled trials</b>, not six sequential solar transitions. The seventh principle audits all six. The photographed garment is a <b>reference fixture</b>; the luminous routing is an illustrative mapping to the measured-by-model variables, not real electroluminescent clothing.</p><p class="notes">The passage shown when Gate 24 opens is a verified <b>numerical transfer under frozen model rules</b>, not real hydraulic, optical, electrical, or physical validation.</p></div>
  </section>
  <footer class="footer"><div><strong>Atomic Atlas · Study 008-C</strong> — Frozen seven-gate contract; original reference preserved; six scenarios × 60 frames; G7 cross-scenario audit PASS.</div><div>All simulations and graphics stay local. No external requests or dependencies.</div></footer>
</div>
<script id="embeddedData" type="application/json">__DATA__</script>
<script>
(()=>{
 'use strict';
 const DATA=JSON.parse(document.getElementById('embeddedData').textContent);
 const scenarioSelect=document.getElementById('scenarioSelect');
 const timeline=document.getElementById('timeline');
 const play=document.getElementById('play');
 const speed=document.getElementById('speed');
 const routingToggle=document.getElementById('routingToggle');
 const loopToggle=document.getElementById('loopToggle');
 const NS='http://www.w3.org/2000/svg';
 let scenario=DATA.scenarios.find(s=>s.scenario_id==='G4') || DATA.scenarios[0];
 let idx=0, timer=null;
 const edgeIds=['12','24','43','31','14'];
 const colors=['#59caff','#d2b173','#8f82f2','#8fdaa8'];
 const g=(id)=>document.getElementById(id);
 const coords={'12':[232,102,452,102],'24':[528,160,528,276],'43':[452,335,232,335],'31':[156,276,156,160],'14':[210,147,472,292]};
 DATA.scenarios.forEach((s)=>{const opt=document.createElement('option');opt.value=s.scenario_id;opt.textContent=s.scenario_id+' · '+s.scenario_name;scenarioSelect.appendChild(opt)});
 scenarioSelect.value=scenario.scenario_id;
 function setText(id,value){g(id).textContent=value}
 function setVisibleOpacity(el,opacity){el.style.opacity=String(Math.max(0,Math.min(1,opacity)))}
 function render(){
   const f=scenario.frames[idx];
   setText('scenarioBadge',scenario.scenario_id+' · '+(scenario.scenario_name.split(' · ')[0]).toUpperCase());
   setText('trialCaption',scenario.scenario_name);
   setText('frameText',String(idx+1).padStart(2,'0')+' / 60');
   timeline.value=idx;
   const gs=f.gate24_state,held=(gs==='HELD'||gs==='CLOSED'||gs==='REJECTED');
   setText('gateBanner','GATE 24 · '+gs.replace('_',' '));g('gateBanner').classList.toggle('held',held);
   setText('energyBanner','Total '+f.total_after+' · balance '+f.step_balance_error);
   g('gateDisc').classList.toggle('gate-closed',held);
   setText('gateSymbol',held?'×':'✓');g('gateSymbol').classList.toggle('gate-closed-text',held);
   setText('m_gate',gs.replace('_',' '));setText('m_flow24',String(f.accepted['24'])+' quanta');
   setText('m_blocked',String(f.blocked_demand['24'])+' potential quanta');
   setText('m_total',String(f.total_after)+' / '+String(scenario.initial_total));
   setText('m_error',String(f.step_balance_error));
   setText('m_capacity',f.states_after.some((v,i)=>v>scenario.capacities[i]||v<0)?'YES · ERROR':'NO');
   for(let i=0;i<4;i++){
     const max=scenario.capacities[i],qty=f.states_after[i],fillHeight=Math.round(65*qty/max);
     const rect=g('fill'+(i+1));rect.setAttribute('y',String(107-fillHeight));rect.setAttribute('height',String(fillHeight));
     setText('lev'+(i+1),qty+' / '+max);
   }
   setText('totalFigure','TOTAL '+f.total_after+' · EXACT');
   let content='';
   for(const id of edgeIds){
     const open=f.gates_open[id],num=f.accepted[id],clipped=f.withheld[id];
     const state=open?(clipped>0?'LIMITED':num>0?'FLOW':'IDLE'):'CLOSED';
     const clazz=!open?'blocked':num>0?'active':'still';
     content+='<tr><td>R'+id[0]+' → R'+id[1]+'</td><td>'+f.requested[id]+'</td><td>'+num+'</td><td>'+clipped+'</td><td class="'+clazz+'">'+state+'</td></tr>';
     const p=g('edge'+id),particle=g('particle'+id);
     const maxRef=id==='14'?90:id==='12'?18:id==='24'?12:id==='43'?11:10;
     const intensity=Math.min(1,num/maxRef);
     if(p){setVisibleOpacity(p, num>0?.35+.65*intensity:.12);p.setAttribute('stroke',!open?'#cd866b':num>0?'#7ecfff':'#50799d');}
     if(particle){
       const pos=coords[id],alpha= num>0? .65+.35*intensity:0;
       const phase=((idx*1.7)+(id==='24'?3:id==='43'?5:id==='31'?7:0))%11/11;
       const xx=pos[0]+(pos[2]-pos[0])*phase, yy=pos[1]+(pos[3]-pos[1])*phase;
       particle.setAttribute('cx',xx.toFixed(2));particle.setAttribute('cy',yy.toFixed(2));setVisibleOpacity(particle,alpha);
     }
     const route=g('route'+id),spark=g('spark'+id);
     if(route)route.style.opacity=String(routingToggle.checked && num>0 ?Math.min(.85,.18+num/maxRef*.58):0);
     if(spark)spark.style.opacity=String(routingToggle.checked && num>0 ?.95:0);
     if(spark && route && num>0){
       try{const len=route.getTotalLength(),pt=route.getPointAtLength(len*((idx%14)/14));spark.setAttribute('cx',pt.x);spark.setAttribute('cy',pt.y)}catch(e){}
     }
   }
   g('edge14').style.opacity=scenario.scenario_id==='G6' ? String(.15+(f.accepted['14']>0?.9:0)):'0';
   g('edgesTable').innerHTML=content;
   let title='',desc='',symbol='◉';
   if(scenario.scenario_id==='G4'){
      if(idx<18){title='First current · gate open';desc='The ring permits G24 flow while inventory and destination capacity allow it.';symbol='↗';}
      else if(idx<=35){title='Boundary holds · Gate 24 closed';desc='Accepted transfer is exactly zero through G24; other routes can still move.';symbol='⏸';}
      else{title=f.gates_open['24']?'Guard passed · reopening permitted':'Guard rejected · gate remains closed';desc=f.gates_open['24']?'Source, receiver and directed-gradient checks are satisfied. Any admitted transfer is debited and credited atomically.':'The predeclared guards do not allow transfer. The route remains dark.';symbol=f.gates_open['24']?'✓':'×';}
   }else if(scenario.scenario_id==='G1'){title='Hidden Dragon · no transport';desc='All routes closed; stored quantities and mass balance remain unchanged.';}
   else if(scenario.scenario_id==='G2'){title=idx<5?'Latent before the onset':'Emergence · permitted pathways';desc=idx<5?'The first accepted transfer cannot occur before frame 6.':'The onsets and transfers are controlled by the declared gate schedule.';}
   else if(scenario.scenario_id==='G3'){title='Diligent motion · organized transfers';desc='A bounded gradient drives transfers along the declared ring.';}
   else if(scenario.scenario_id==='G5'){title='Flying Dragon · bounded circulation';desc='Each edge transfers 2 integer quanta per frame, with each reservoir receiving and sending equally.';}
   else{title='Overextension · excess request rejected';desc='A deliberately oversized request is clipped by destination capacity and competing source inventory, without breaking conservation.';symbol='!';}
   setText('phaseTitle',title);setText('phaseDescription',desc);setText('phaseIcon',symbol);
   const s=scenario.summary;
   setText('outcomeNote','Scenario result: '+scenario.outcome.replaceAll('_',' ').toLowerCase()+'. Across 60 frames: '+s.total_accepted+' accepted quanta, '+s.total_withheld+' clipped from open-path requests, '+s.potential_demand_blocked_by_gate24+' potential quanta waiting behind Gate 24.');
   const max=Math.max(...scenario.capacities);let chart='';
   for(let k=0;k<4;k++){
     const pts=scenario.frames.map((rec,i)=>`${(42+i*(533/59)).toFixed(2)},${(145-rec.states_after[k]/max*120).toFixed(2)}`).join(' ');
     chart+=`<polyline points="${pts}" fill="none" stroke="${colors[k]}" stroke-width="2.2" stroke-linejoin="round"/>`;
   }
   g('seriesLines').innerHTML=chart;
   const cx=42+idx*(533/59);g('cursor').setAttribute('x1',cx);g('cursor').setAttribute('x2',cx);
 }
 function pause(){if(timer){clearInterval(timer);timer=null;}play.textContent='▶ Play';}
 function next(){if(idx===59){if(loopToggle.checked){idx=0}else{pause();return}}else idx++;render();}
 function toggle(){if(timer){pause();return}play.textContent='❚❚ Pause';timer=setInterval(next,Number(speed.value));}
 play.addEventListener('click',toggle);
 g('back').addEventListener('click',()=>{pause();idx=Math.max(0,idx-1);render()});
 g('forward').addEventListener('click',()=>{pause();idx=Math.min(59,idx+1);render()});
 timeline.addEventListener('input',()=>{pause();idx=Number(timeline.value);render()});
 scenarioSelect.addEventListener('change',()=>{pause();scenario=DATA.scenarios.find(s=>s.scenario_id===scenarioSelect.value);idx=0;render()});
 speed.addEventListener('change',()=>{if(timer){pause();toggle()}});
 routingToggle.addEventListener('change',render);
 document.addEventListener('keydown',(e)=>{if(e.target instanceof HTMLElement&&['SELECT','INPUT','TEXTAREA','BUTTON'].includes(e.target.tagName))return;if(e.key===' '){e.preventDefault();toggle()} else if(e.key==='ArrowRight'){pause();idx=Math.min(59,idx+1);render()}else if(e.key==='ArrowLeft'){pause();idx=Math.max(0,idx-1);render()}});
 render();
})();
</script>
</body>
</html>'''
html=html.replace('__PORTRAIT__',image_src).replace('__DATA__',js_data)
STANDALONE.write_text(html,encoding='utf-8')
print(STANDALONE, STANDALONE.stat().st_size, hashlib.sha256(STANDALONE.read_bytes()).hexdigest())
