#!/usr/bin/env python3
"""Atomic Atlas Study 008-C, frozen discrete transport model, stdlib-only.

Four reservoirs of *dimensionless integer quanta*, not physical hydraulics.
All proposals are computed from the pre-step state. A declared, fixed
priority arbiter allocates available source and destination capacity before
all accepted transfers are committed atomically.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
from math import floor

ROOT = Path(__file__).resolve().parents[1]
CONTRACT = json.loads((ROOT / "CONTRACT_FROZEN.json").read_text(encoding="utf-8"))
LINKS = CONTRACT["links"]
N = CONTRACT["frame_count"]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def scheduled_gates(scenario: dict, frame: int, pre: list[int], caps: list[int]) -> tuple[dict[str,bool], dict]:
    profile = scenario["gate_profile"]
    gates = {e["id"]: False for e in LINKS}
    details = {"kind": profile, "gate24": "CLOSED", "guard": None}
    if profile == "all_closed":
        pass
    elif profile == "onset_at_frame_5":
        gates["12"] = gates["24"] = frame >= 5
    elif profile == "all_ring_open":
        for eid in ("12","24","43","31"):
            gates[eid] = True
    elif profile == "gate24_hold_then_guarded_reopen":
        for eid in ("12","43","31"):
            gates[eid] = True
        if frame < 18:
            gates["24"] = True
            details["gate24"] = "OPEN"
        elif frame <= 35:
            gates["24"] = False
            details["gate24"] = "HELD"
        else:
            edge24 = next(e for e in LINKS if e["id"] == "24")
            req = min(edge24["rate_max"], int(floor(edge24["gradient_factor"] * max(0, pre[1]-pre[3]))))
            guards = {"receiver_capacity": caps[3] - pre[3] > 0,
                      "source_inventory": pre[1] > 0,
                      "permitted_direction_and_positive_request": req > 0,
                      "atomic_balanced_transfer_supported": True}
            gates["24"] = all(guards.values())
            details["guard"] = guards
            details["gate24"] = "OPEN_GUARDED" if gates["24"] else "REJECTED"
    elif profile == "balanced_pump_circulation":
        for eid in ("12","24","43","31"):
            gates[eid] = True
    elif profile == "stress_two_links_from_R1":
        for eid in ("12","24","43","31","14"):
            gates[eid] = True
    else:
        raise ValueError("unknown profile: " + profile)
    if profile != "gate24_hold_then_guarded_reopen":
        details["gate24"] = "OPEN" if gates["24"] else "CLOSED"
    return gates, details


def requested(e: dict, scenario: dict, pre: list[int], frame: int) -> int:
    profile = scenario["gate_profile"]
    if profile == "balanced_pump_circulation":
        return 2 if e["id"] != "14" else 0
    if profile == "stress_two_links_from_R1" and frame == 0 and e["id"] in ("12", "14"):
        return 90  # Intentional two-link contention and destination saturation.
    return min(e["rate_max"], max(0, int(floor(e["gradient_factor"] * max(0, pre[e["from"]]-pre[e["to"]])))))


def step(scenario: dict, frame: int, before: list[int], caps: list[int]) -> dict:
    before = list(before)
    gates, control = scheduled_gates(scenario, frame, before, caps)
    source_avail = before.copy()
    destination_avail = [cap - r for cap,r in zip(caps, before)]
    accepted: dict[str,int] = {}
    proposed: dict[str,int] = {}
    withheld: dict[str,int] = {}
    blocked_demand: dict[str,int] = {}
    reasons: dict[str,list[str]] = {}
    for e in LINKS:
        eid = e["id"]
        potential = requested(e, scenario, before, frame)
        desire = potential if gates[eid] else 0
        proposed[eid] = desire
        accepted[eid] = 0
        if not gates[eid]:
            withheld[eid] = 0  # No attempted flow when valve is closed.
            blocked_demand[eid] = potential if eid == "24" else 0
            reasons[eid] = ["GATE_CLOSED"] if blocked_demand[eid] else []
            continue
        blocked_demand[eid] = 0
        src, dst = e["from"], e["to"]
        quantity = min(desire, source_avail[src], destination_avail[dst])
        accepted[eid] = quantity
        source_avail[src] -= quantity
        destination_avail[dst] -= quantity
        withheld[eid] = desire - quantity
        why = []
        if quantity < desire:
            if source_avail[src] == 0:
                why.append("SOURCE_INVENTORY_LIMIT")
            if destination_avail[dst] == 0:
                why.append("DESTINATION_CAPACITY_LIMIT")
            if not why:
                why.append("PRIORITY_ALLOCATION_LIMIT")
        reasons[eid] = why
    after = before.copy()
    # One synchronous, atomic state transition; no same-frame re-spending.
    for e in LINKS:
        n = accepted[e["id"]]
        after[e["from"]] -= n
        after[e["to"]] += n
    if any(v < 0 or v > cap for v,cap in zip(after,caps)):
        raise AssertionError("model state escaped declared bounds")
    if sum(before) != sum(after):
        raise AssertionError("internal quantities not conserved")
    return {"frame":frame,"states_before":before,"states_after":after,
            "gates_open":gates,"gate24_state":control["gate24"],
            "gate24_guard":control["guard"],
            "requested":proposed,"accepted":accepted,"withheld":withheld,
            "blocked_demand":blocked_demand,
            "reasons":reasons,"total_before":sum(before),"total_after":sum(after),
            "step_balance_error":sum(after)-sum(before)}


def run_scenario(scenario: dict) -> dict:
    caps = scenario.get("capacities", CONTRACT["nominal_capacities"])
    initial = list(scenario["initial"])
    if len(initial)!=4 or any(x<0 or x>c for x,c in zip(initial,caps)):
        raise ValueError("invalid initial conditions")
    states = initial.copy()
    frames = []
    for i in range(N):
        out = step(scenario,i,states,caps)
        frames.append(out)
        states = out["states_after"]
    accepted_by_edge = {e["id"]:sum(r["accepted"][e["id"]] for r in frames) for e in LINKS}
    rejected_by_edge = {e["id"]:sum(r["withheld"][e["id"]] for r in frames) for e in LINKS}
    blocked_at_gate24 = sum(r["blocked_demand"]["24"] for r in frames)
    max_resid = max(abs(r["step_balance_error"]) for r in frames)
    return {"scenario_id":scenario["id"], "scenario_name":scenario["name"],
            "profile":scenario["gate_profile"], "capacities":caps,
            "initial":initial,"initial_total":sum(initial),"frames":frames,
            "summary":{"last_state":states,"total_accepted":sum(accepted_by_edge.values()),
                       "total_withheld":sum(rejected_by_edge.values()),
                       "potential_demand_blocked_by_gate24":blocked_at_gate24,
                       "accepted_by_edge":accepted_by_edge,"withheld_by_edge":rejected_by_edge,
                       "largest_mass_balance_residual":max_resid}}


def expectations(run: dict, scenario: dict) -> dict:
    f=run["frames"]; s=run["summary"]; p=run["profile"]
    checks={"all_60_frames":len(f)==60,
        "conserved_integer_quantity":all(x["step_balance_error"]==0 and x["total_after"]==run["initial_total"] for x in f),
        "bounded_storage":all(all(0<=y<=c for y,c in zip(x["states_after"],run["capacities"])) for x in f),
        "closed_gate_zero_transfer":all(not x["accepted"]["24"] for x in f if not x["gates_open"]["24"])}
    if p=="all_closed":
        checks.update(zero_transport=s["total_accepted"]==0, static_storage=all(x["states_after"]==run["initial"] for x in f))
    elif p=="onset_at_frame_5":
        checks.update(pre_onset_zero=all(x["accepted"]["12"]==0 for x in f[:5]),
                      active_after_onset=sum(x["accepted"]["12"] for x in f[5:])>0)
    elif p=="all_ring_open":
        checks.update(transport_exists=s["total_accepted"]>0)
    elif p=="gate24_hold_then_guarded_reopen":
        checks.update(hold_18_to_35=all(not x["gates_open"]["24"] and x["accepted"]["24"]==0 for x in f[18:36]),
                      gate_36_eligible=f[36]["gates_open"]["24"],
                      reopens_with_positive_transfer=any(x["accepted"]["24"]>0 for x in f[36:]))
    elif p=="balanced_pump_circulation":
        checks.update(every_frame_has_flow=all(sum(x["accepted"].values())>0 for x in f),
                      stable_storage=all(x["states_after"]==run["initial"] for x in f))
    elif p=="stress_two_links_from_R1":
        checks.update(oversized_request_issued=f[0]["requested"]["12"]==90 and f[0]["requested"]["14"]==90,
                      excess_explicitly_rejected=s["total_withheld"]>0,
                      not_overflowing=all(all(v<=c for v,c in zip(x["states_after"],run["capacities"])) for x in f))
    return checks


def build() -> dict:
    data = []
    for scenario in CONTRACT["scenarios"]:
        result = run_scenario(scenario)
        result["predeclared_checks"] = expectations(result,scenario)
        result["outcome"] = "PASS_PREDECLARED_CHECKS" if all(result["predeclared_checks"].values()) else "FAILED_PREDECLARED_CHECKS"
        data.append(result)
    # No VII physical simulation: G7 checks the six results independently.
    results = {"contract_id":CONTRACT["contract_id"],
               "frozen_contract_sha256":sha256(ROOT / "CONTRACT_FROZEN.json"),
               "model_note":"Computed discrete normalized transport, not empirical fluid flow",
               "model_sequential_priority":[e["id"] for e in LINKS],
               "scenarios":data,
               "gate7": {"id":"G7","kind":"AUDIT","result":"PENDING_INDEPENDENT_AUDIT"}}
    return results


if __name__ == "__main__":
    path = ROOT / "data" / "simulated_transport.json"
    path.write_text(json.dumps(build(),ensure_ascii=False,separators=(",",":")),encoding="utf-8")
    print("Wrote",path)
