#!/usr/bin/env python3
"""Independent replay-independent audit of recorded Study 008-C transition receipts.

Intentionally does not import transport.py. Uses only frozen contract and
saved before/after event records to check the bookkeeping invariants.
"""
import hashlib, json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONTRACT = json.loads((ROOT/'CONTRACT_FROZEN.json').read_text(encoding='utf-8'))
EDGES = [(x['id'], x['from'], x['to']) for x in CONTRACT['links']]


def audit_scenario(rec):
    problems=[]
    caps=rec['capacities']
    last=rec['initial']
    initial_total=sum(last)
    if len(rec['frames']) != CONTRACT['frame_count']:
        problems.append('FRAMES_MISSING_OR_EXTRA')
    for index,r in enumerate(rec['frames']):
        stem=f'{rec["scenario_id"]}:frame={index}'
        if r['frame'] != index:
            problems.append(stem+':INDEX')
        bef=r['states_before']
        aft=r['states_after']
        if last!=bef:
            problems.append(stem+':DISCONTINUOUS_STATE')
        if len(bef)!=4 or len(aft)!=4 or len(caps)!=4:
            problems.append(stem+':SHAPE')
            continue
        if any(not isinstance(v,int) or v<0 or v>c for v,c in zip(aft,caps)):
            problems.append(stem+':OUT_OF_BOUNDS')
        if sum(bef)!=initial_total or sum(aft)!=initial_total:
            problems.append(stem+':TOTAL_NOT_CONSERVED')
        expected=bef.copy()
        outbound=[0,0,0,0]
        inbound=[0,0,0,0]
        for edge,src,dst in EDGES:
            n=r['accepted'].get(edge)
            req=r['requested'].get(edge)
            rej=r['withheld'].get(edge)
            block=r['blocked_demand'].get(edge)
            op=r['gates_open'].get(edge)
            if not all(isinstance(x,int) and x>=0 for x in [n,req,rej,block]):
                problems.append(stem+':NONINTEGER_QUANTITY:'+edge)
                continue
            if n>req or rej!=req-n:
                problems.append(stem+':REQUEST_ALLOCATION_INCONSISTENT:'+edge)
            if not op and (n!=0 or req!=0):
                problems.append(stem+':CLOSED_ROUTE_CROSSED:'+edge)
            if op and block!=0:
                problems.append(stem+':BLOCKED_MARKED_WHILE_OPEN:'+edge)
            outbound[src]+=n
            inbound[dst]+=n
            expected[src]-=n
            expected[dst]+=n
        if any(outbound[i] > bef[i] for i in range(4)):
            problems.append(stem+':SPENT_UNRECEIVED_QUANTITY')
        if any(inbound[i] > caps[i]-bef[i] for i in range(4)):
            problems.append(stem+':SPENT_NONEXISTENT_DESTINATION_CAPACITY')
        if expected!=aft:
            problems.append(stem+':NOT_EQUAL_TO_LEDGER_DELTA')
        if r['total_before']!=sum(bef) or r['total_after']!=sum(aft) or r['step_balance_error']!=sum(aft)-sum(bef):
            problems.append(stem+':FALSE_STATED_BALANCE')
        if (r['gate24_state'] in ('OPEN', 'OPEN_GUARDED')) != bool(r['gates_open']['24']):
            problems.append(stem+':GATE24_DISPLAY_STATUS_CONTRADICTION')
        if rec['scenario_id']=='G4':
            if 18<=index<=35 and (r['gates_open']['24'] or r['accepted']['24']):
                problems.append(stem+':GATE24_HOLD_VIOLATION')
            if index>=36:
                g=r['gate24_guard']
                if not isinstance(g,dict):
                    problems.append(stem+':GATE24_GUARD_MISSING')
                else:
                    expected_guards={
                        'receiver_capacity':caps[3]-bef[3]>0,
                        'source_inventory':bef[1]>0,
                        'permitted_direction_and_positive_request':bef[1]-bef[3]>0 and int(.19*max(0,bef[1]-bef[3]))>0,
                        'atomic_balanced_transfer_supported':True}
                    if g!=expected_guards or r['gates_open']['24']!=all(expected_guards.values()):
                        problems.append(stem+':GUARD_INCONSISTENT')
        last=aft
    if any(v is not True for v in rec['predeclared_checks'].values()):
        problems.append(rec['scenario_id']+':PREDECLARED_EXPECTATION_FAILED')
    return {'id':rec['scenario_id'],'audited_frames':len(rec['frames']), 'outcome':'PASS' if not problems else 'FAIL', 'problems':problems}


def audit_all(raw):
    problems=[]
    expected_hash=hashlib.sha256((ROOT/'CONTRACT_FROZEN.json').read_bytes()).hexdigest()
    if raw['frozen_contract_sha256']!=expected_hash:
        problems.append('CONTRACT_HASH_MISMATCH')
    if len(raw['scenarios'])!=6:
        problems.append('EXPECTED_SIX_SCENARIOS')
    checks=[audit_scenario(x) for x in raw['scenarios']]
    for check in checks:
        if check['outcome']!='PASS':
            problems+=check['problems']
    return {'gate':'G7_USE_NINE','type':'independent cross-scenario audit',
            'contract_hash':expected_hash,'audited_frames':sum(c['audited_frames'] for c in checks),
            'scenario_reviews':checks,
            'result':'PASS_INDEPENDENT_AUDIT' if not problems else 'FAIL_INDEPENDENT_AUDIT',
            'problems':problems,
            'claim_boundary':'Machine-checkable normalized mathematical transfers, not laboratory measurements.'}


if __name__=='__main__':
    src=ROOT/'data'/'simulated_transport.json'
    raw=json.loads(src.read_text(encoding='utf-8'))
    rec=audit_all(raw)
    dst=ROOT/'data'/'independent_audit.json'
    dst.write_text(json.dumps(rec,indent=2)+'\n',encoding='utf-8')
    print(rec['result'],'audited frames',rec['audited_frames'],'problems:',len(rec['problems']))
    if rec['problems']:
        print('\n'.join(rec['problems'][:40])); raise SystemExit(1)
