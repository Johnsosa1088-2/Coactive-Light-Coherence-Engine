@echo off
setlocal
cd /d "%~dp0"
python src\transport.py || exit /b 1
python src\independent_audit.py || exit /b 1
python -m unittest discover -s tests -v || exit /b 1
python src\build_viewer.py || exit /b 1
echo.
echo Ready: Aurelia_The_Dragons_First_Motion.html
endlocal
