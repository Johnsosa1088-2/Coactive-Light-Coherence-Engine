# LIGHTBENCH LOCAL INHERITANCE 001 — v1.11

## HEIROS GAMOS · PIXEL SHAPE CONFORM

Added beneath the existing LightBench forearm workbench.

### What changed
- Pixel Shape Conform master blend.
- Seven local conform-weight stations: elbow, proximal, upper belly, mid-forearm, lower belly, distal, wrist.
- Front/Back witness evidence drives the X envelope; Side witness evidence drives Z depth.
- Elbow and wrist phase centers remain protected.
- Local asymmetry is represented as bounded envelope offset around the skeleton phase, not as skeleton displacement.
- `Fit current 3 views` resamples aligned witness edges and updates the working width/depth target profile.
- Before/after, Front/Side/Back, unfolded patch, and 3D proof displays are included in the section.
- The same conformed `buildField()` geometry flows into the existing OBJ exporter.
- Pixel Shape Conform state and fitted target arrays are preserved in proof JSON export/import.

### Evidence boundary
The current built-in target profile comes from the synthetic v1.9 witness set and remains provisional. The edge sampler is a bounded working fit, not a validated nonlinear inverse-reconstruction solver. Units remain LightBench-local/normalized until metric skeleton binding.

### Validation
- JavaScript syntax check: PASS.
- Referenced UI IDs: 0 missing.
- Front/Side envelope mapping corrected to the local frame.
- Headless Chromium could not complete in this container because its DBus endpoints are unavailable; no browser-runtime claim is made.
